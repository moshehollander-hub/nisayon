// =====================================================
//  Tfilon
//  Siddur
//  (C) 2011-2016, Ori Hollander
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  If the following code is used in your application,
//  the references are expected.
// =====================================================
package tfilon.tfilon;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;

public class TfilonStartActivity extends Activity {
	public boolean done = false;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		/*
		 * LinearLayout ll = new LinearLayout(this);
		 * ImageView iv = new ImageView(this);
		 * iv.setImageResource(R.drawable.splash);
		 * ll.addView(iv);
		 * ll.setGravity(Gravity.CENTER);
		 * ll.setBackgroundColor(Color.WHITE);
		 * setContentView(ll);
		 */
		setContentView(R.layout.activity_main);

		ImageButton button = (ImageButton) findViewById(R.id.down);

//		button.setOnClickListener(new View.OnClickListener() {
//
//			public void onClick(View v) {
//				Intent viewIntent =
//						new Intent("android.intent.action.VIEW",
//								Uri.parse("http://www.TateTime.co.il"));
//				startActivity(viewIntent);
//			}
//		});

		final int welcomeScreenDisplay = 2500;
		Thread welcomeThread = new Thread() {

			int wait = 0;

			@Override
			public void run() {
				try {
					super.run();
					while (wait < welcomeScreenDisplay) {
						sleep(100);
						wait += 100;
					}
				} catch (Exception e) {
					System.out.println("EXc=" + e);
				} finally {
					if (!done) {
						startActivity(new Intent(TfilonStartActivity.this, Tfilon.class));
					}
					finish();
				}
			}
		};
		welcomeThread.start();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent b) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			done = true;
			super.onKeyDown(keyCode, b);
		}
		return false;
	}
}