// =====================================================
//  Tfilon
//  Siddur
//  (C) 2011-2016, Ori Hollander
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  If the following code is used in your application,
//  the references are expected.
// =====================================================
package tfilon.tfilon;

import java.util.Timer;
import java.util.TimerTask;
import java.util.Vector;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.view.View;

@SuppressLint("ViewConstructor")
public class TfilaRow extends View {
	Vector<String> v;
	Vector<Colored> coloreds;
	int i;
	byte curR, curG, curB;
	Tfilon mgr;

	public TfilaRow(Context context, Vector<String> v, Vector<Colored> coloreds, int i) {
		super(context);
		this.v = v;
		this.coloreds = coloreds;
		this.i = i;
		mgr = (Tfilon) context;
		if (i != -1) {
			setMinimumHeight(mgr.letterHeight +
					(5 - mgr.font) * mgr.ratio);
            setColors();
		} else {
			setMinimumHeight(2 * (5 - mgr.font) *
                    mgr.ratio);
		}
	}

	@SuppressLint("MissingSuperCall")
	@Override
	public void draw(Canvas canvas) {
		if (i == -1) {
			canvas.drawColor(mgr.nightMode ? Color.BLACK : Color.WHITE);
		} else {
			mgr.drawString(v.elementAt(i), canvas, Math.abs(canvas.getClipBounds().width()), (3 - mgr.font) *
					mgr.ratio, curR, curG, curB);
		}
	}

    public void setColors() {
        byte R, G, B;
        int place;
        Colored colored = null;
        place = 0;
        while (place < coloreds.size() &&
                (colored = (coloreds.elementAt(place))).index < i) {
            place++;
        }
        if (place != coloreds.size()) {
            if (place % 2 != 0) {
                int index1 = (coloreds.elementAt(place - 1)).index;
                int index2 = colored.index;
                if (index1 <= i &&
                        i <= index2) {
                    R = colored.red;
                    G = colored.green;
                    B = colored.blue;
                } else {
                    R = G = B = 0;
                }
            } else {
                while (place + 1 == coloreds.size()) {
                    Timer time = new Timer();
                    time.schedule(new TimerTask() {

                        @Override
                        public void run() {
                        }
                    }, 10);
                }
                int index1 = colored.index;
                int index2 = (coloreds.elementAt(place + 1)).index;
                if (index1 <= i &&
                        i <= index2) {
                    R = colored.red;
                    G = colored.green;
                    B = colored.blue;
                } else {
                    R = G = B = 0;
                }
            }
        } else {
            R = G = B = 0;
        }
        curR = R;
        curG = G;
        curB = B;
    }
}
