package tfilon.tfilon;

public interface ScrollViewListener {

    void onScrollChanged(ObservableScrollView scrollView, int x, int y, int oldx, int oldy);

    void onScrollFinished(ObservableScrollView scrollView);

    void showBar();

}