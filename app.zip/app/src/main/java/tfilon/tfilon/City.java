// =====================================================
//  Tfilon
//  Siddur
//  (C) 2011-2016, Ori Hollander
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  If the following code is used in your application,
//  the references are expected.
// =====================================================
package tfilon.tfilon;

public class City {

	public int[] longitude;
	public int[] latitude;
	public String name;
	public int shabbatTime;
	public final int innerId;
	public boolean isInIsrael;
	public double gmtOffset;
	public int elevation;

	public City(final int innerId, int[] latitude, int[] longitude,
			String name, int shabbatTime, boolean isInIsrael, double gmtOffset,
			int elevation) {
		this.longitude = longitude;
		this.latitude = latitude;
		this.name = name;
		this.shabbatTime = shabbatTime;
		this.innerId = innerId;
		this.isInIsrael = isInIsrael;
		this.gmtOffset = gmtOffset;
		this.elevation = elevation;
	}

	@Override
	public String toString() {
		return name;
	}
}
