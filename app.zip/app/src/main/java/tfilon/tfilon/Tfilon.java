// =====================================================
//  Tfilon
//  Siddur
//  (C) 2011-2016, Ori Hollander
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  If the following code is used in your application,
//  the references are expected.
// =====================================================
package tfilon.tfilon;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;

import tfilon.tfilon.moladlib.DateData;
import tfilon.tfilon.moladlib.DateHolder;
import tfilon.tfilon.moladlib.EventData;
import tfilon.tfilon.moladlib.HebCalendar;
import tfilon.tfilon.moladlib.LocationHolder;
import tfilon.tfilon.moladlib.Sedrot;
import tfilon.tfilon.moladlib.SunRiseSet;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.ToggleButton;

public class Tfilon extends Activity {
    public enum Modes {
        MAIN, NUSACH, TFILAMENU, TFILA, HELP, ABOUT, SETTINGS, ZMANIM
    }

    public static Modes mode;
    public static Resources res;

    public final long RH = 1;
    public final long KAPARAT_PASHA = 2 * RH;
    public final long LEAP = 2 * KAPARAT_PASHA;
    public final long CHANUKA = 2 * LEAP;
    public final long PURIM = 2 * CHANUKA;
    public final long MEGILAT_ESTER = 2 * PURIM;
    public final long PURIM_MESHULASH_TACHANUN_MESSAGE = 2 * MEGILAT_ESTER;
    public final long SUCOT = 2 * PURIM_MESHULASH_TACHANUN_MESSAGE;
    public final long PESACH = 2 * SUCOT;
    public final long AYT = 2 * PESACH;
    public final long KIPUR = 2 * AYT;
    public final long TISHREI_11 = 2 * KIPUR;
    public final long SUMMER_TAL = 2 * TISHREI_11;
    public final long WINTER_TAL = 2 * SUMMER_TAL;
    public final long SUMMER_BRACHA = 2 * WINTER_TAL;
    public final long WINTER_BRACHA = 2 * SUMMER_BRACHA;
    public final long TISHAA_BEAV = 2 * WINTER_BRACHA;
    public final long TAANIT = 2 * TISHAA_BEAV;
    public final long HOSHANA_RABA = 2 * TAANIT;
    public final long OMER = 2 * HOSHANA_RABA;
    public final long LEDAVID = 2 * OMER;
    public final long SHACHARIT_TACHANUN = 2 * LEDAVID;
    public final long MINCHA_TACHANUN = 2 * SHACHARIT_TACHANUN;
    public final long MON_THU = 2 * MINCHA_TACHANUN;
    public final long NO_GEDALYA = 2 * MON_THU;
    public final long SUN = 2 * NO_GEDALYA;
    public final long MON = 2 * SUN;
    public final long TUE = 2 * MON;
    public final long WED = 2 * TUE;
    public final long THU = 2 * WED;
    public final long FRI = 2 * THU;
    public final long HALLEL = 2 * FRI;
    public final long FULL_HALLEL = 2 * HALLEL;
    public final long ATZMAUT = 2 * FULL_HALLEL;
    public final long YERUSHALAYIM = 2 * ATZMAUT;
    public final long ZIKARON = 2 * YERUSHALAYIM;
    public final long SHABBAT = 2 * ZIKARON;
    public final long MIGDOL = 2 * SHABBAT;
    public final long MUSAF = MIGDOL;
    public final long LAMNATZEACH = 2 * MUSAF;
    public final long TORA = 2 * LAMNATZEACH;
    public final long TODA = 2 * TORA;
    public final long THREE_WEEKS = 2 * TODA;
    public final long KADOSH = 2 * THREE_WEEKS;
    public final long EM_KADOSH = 2 * KADOSH;
    public final long CHONANTANU = 2 * EM_KADOSH;
    public final long HAVDALA = 2 * CHONANTANU;
    public final long SLICHOT = 2 * HAVDALA;
    public final long TAMMUZ_17 = 2 * SLICHOT;
    public final long ESTER = 2 * TAMMUZ_17;
    public final long TEVET_10 = 2 * ESTER;
    public final long GEDALYA = 2 * TEVET_10;
    public final long FIRE = 2 * GEDALYA;
    public final long TISHAA_BEAV_FIRE = 2 * FIRE;
    public final long TIKUN_RACHEL = 2 * TISHAA_BEAV_FIRE;

    public final long MINCHA_DIFF_FLAGS = RH | CHANUKA | PURIM | SUCOT | PESACH | AYT | KIPUR | SUMMER_TAL | WINTER_TAL | SUMMER_BRACHA | WINTER_BRACHA | TAANIT | LEDAVID | MINCHA_TACHANUN | FRI;
    public final long ARVIT_DIFF_FLAGS = RH | CHANUKA | PURIM | SUCOT | PESACH | AYT | SUMMER_TAL | WINTER_TAL | SUMMER_BRACHA | WINTER_BRACHA | TISHAA_BEAV | LEDAVID | OMER | SUN | ATZMAUT | YERUSHALAYIM | KADOSH | EM_KADOSH | HAVDALA | CHONANTANU;

    public long dayData;
    public long nextDayData;
    public String[] kria = new String[2];
    public String nusach;
    public boolean shatz = false;
    public boolean sunset = false;
    public boolean sunrise = false;
    public final int YD = 1;
    public final int TU = 2;
    public int purimDay;
    public boolean censor;
    public boolean vaanenu;
    public boolean doctor;
    public String doctorNames;
    public boolean avel;
    public City city;
    public City[] cities;
    public boolean summerTime;
    public boolean chul;
    public Bitmap[] letters = new Bitmap[54];
    public int[] widths = new int[54];
    public int letterHeight;
    public Hashtable<Long, Bitmap> coloredLetters;
    public int ratio;
    public int font;
    public Colored specialText;
    public Colored koteretText;
    public final Colored RED = new Colored(0, (byte) 255, (byte) 0, (byte) 0);
    public final Colored BLUE = new Colored(0, (byte) 0, (byte) 0, (byte) 255);
    public final Colored GREEN = new Colored(0, (byte) 0, (byte) 150, (byte) 0);
    public final Colored PURPLE = new Colored(0, (byte) 190, (byte) 50, (byte) 215);
    public final int NUSAHIM_NONE = 0;
    public final int NUSAHIM_A = 1;
    public final int NUSAHIM_S = 2;
    public final int NUSAHIM_EM = 3;
    public int defaultNusach;
    public boolean defaultPressed = false;
    public boolean reverse;
    public Typeface tf;
    public Typeface ezraTF;
    public Typeface hadasimTF;
    public Typeface shofarTF;
    public Typeface alefTF;
    public int locale_gravity;
    public boolean nightMode;
    public boolean autoHide;
    public Page curPage;
    public String zmanimText;
    public OnClickListener settingsSaveListener = new OnClickListener() {
        @SuppressLint("NewApi")
        public void onClick(View v) {
            SharedPreferences settings = getPreferences(MODE_PRIVATE);
            SharedPreferences.Editor editor = settings.edit();
            ToggleButton tgl = (ToggleButton) findViewById(R.id.tglVaanenu);
            vaanenu = tgl.isChecked();
            editor.putBoolean("vaanenu", vaanenu);
            tgl = (ToggleButton) findViewById(R.id.tglCensor);
            censor = tgl.isChecked();
            editor.putBoolean("censor", censor);
            tgl = (ToggleButton) findViewById(R.id.tglDoctor);
            doctor = tgl.isChecked();
            editor.putBoolean("doctor", doctor);
            tgl = (ToggleButton) findViewById(R.id.tglDST);
            summerTime = tgl.isChecked();
            editor.putBoolean("summerTime", summerTime);
            tgl = (ToggleButton) findViewById(R.id.tglNight);
            nightMode = tgl.isChecked();
            editor.putBoolean("night", nightMode);
            tgl = (ToggleButton) findViewById(R.id.tglAutoHide);
            autoHide = tgl.isChecked();
            editor.putBoolean("autoHide", autoHide);
            tgl = (ToggleButton) findViewById(R.id.tglReverse);
            reverse = tgl.isChecked();
            editor.putBoolean("reverse", reverse);

            EditText et = (EditText) findViewById(R.id.etDoctor);
            doctorNames = et.getText().toString();
            editor.putString("doctorNames", doctorNames);

            Spinner spnr = (Spinner) findViewById(R.id.spnrCity);
            city = (City) spnr.getSelectedItem();
            chul = !city.isInIsrael;
            editor.putInt("city", city.innerId - 1);
            spnr = (Spinner) findViewById(R.id.spnrPurim);
            purimDay = spnr.getSelectedItemPosition() + 1;
            editor.putInt("purimDay", purimDay);
            spnr = (Spinner) findViewById(R.id.spnrFont);
            font = spnr.getSelectedItemPosition() + 1;
            editor.putInt("font", font);
            spnr = (Spinner) findViewById(R.id.spnrSize);
            ratio = spnr.getSelectedItemPosition() + 1;
            editor.putInt("ratio", ratio);
            spnr = (Spinner) findViewById(R.id.spnrNusach);
            defaultNusach = spnr.getSelectedItemPosition();
            editor.putInt("nusach", defaultNusach);
            /*if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (defaultNusach != NUSAHIM_NONE) {
                    ShortcutManager shortcutManager = (ShortcutManager) getSystemService(SHORTCUT_SERVICE);

                    ShortcutInfo shortcut = new ShortcutInfo.Builder(Tfilon.this, "mincha")
                            .setShortLabel("תפילת מנחה")
                            .setLongLabel("פתח את תפילת מנחה")
                            .setIntent(new Intent(Intent.ACTION_VIEW,
                                    Uri.parse("https://www.google.com/")))
                            .build();

                    shortcutManager.setDynamicShortcuts(Arrays.asList(shortcut));
                } else {
                    ShortcutManager shortcutManager = getSystemService(ShortcutManager.class);

                    shortcutManager.removeAllDynamicShortcuts();
                }
            }*/
            spnr = (Spinner) findViewById(R.id.spnrSpecialColor);
            int intSpecial = spnr.getSelectedItemPosition();
            String strSpecialText;
            switch (intSpecial) {
                case 0:
                    strSpecialText = "red";
                    break;
                case 1:
                    strSpecialText = "blue";
                    break;
                case 2:
                    strSpecialText = "green";
                    break;
                case 3:
                    strSpecialText = "purple";
                    break;
                default:
                    strSpecialText = "red";
                    break;
            }
            editor.putString("specialText", strSpecialText);
            specialText = (strSpecialText.equals("red") ? RED : strSpecialText.compareTo("blue") == 0 ? BLUE : strSpecialText.compareTo("green") == 0 ? GREEN : strSpecialText.compareTo("purple") == 0 ? PURPLE : null);
            spnr = (Spinner) findViewById(R.id.spnrKoteretColor);
            int intKoteret = spnr.getSelectedItemPosition();
            String strKoteretText;
            switch (intKoteret) {
                case 0:
                    strKoteretText = "red";
                    break;
                case 1:
                    strKoteretText = "blue";
                    break;
                case 2:
                    strKoteretText = "green";
                    break;
                case 3:
                    strKoteretText = "purple";
                    break;
                default:
                    strKoteretText = "blue";
                    break;
            }
            editor.putString("koteretText", strKoteretText);
            koteretText = (strKoteretText.compareTo("red") == 0 ? RED : strKoteretText.compareTo("blue") == 0 ? BLUE : strKoteretText.compareTo("green") == 0 ? GREEN : strKoteretText.compareTo("purple") == 0 ? PURPLE : null);

            editor.commit();

            loadLetters();
            setDayData();
            showDialog(0);
            dismissDialog(0);
            Tfilon.this.showMain();
        }
    };
    public OnClickListener settingsCancelListener = new OnClickListener() {
        public void onClick(View v) {
            SharedPreferences settings = getPreferences(MODE_PRIVATE);
            censor = settings.getBoolean("censor", true);
            font = settings.getInt("font", 4);
            ratio = settings.getInt("ratio", 2);
            nightMode = settings.getBoolean("night", false);
            String strSpecialText = settings.getString("specialText", "red");
            String strKoteretText = settings.getString("koteretText", "blue");
            specialText = (strSpecialText.compareTo("red") == 0 ? RED : strSpecialText.compareTo("blue") == 0 ? BLUE : strSpecialText.compareTo("green") == 0 ? GREEN : strSpecialText.compareTo("purple") == 0 ? PURPLE : null);
            koteretText = (strKoteretText.compareTo("red") == 0 ? RED : strKoteretText.compareTo("blue") == 0 ? BLUE : strKoteretText.compareTo("green") == 0 ? GREEN : strKoteretText.compareTo("purple") == 0 ? PURPLE : null);
            loadLetters();
            showDialog(0);
            dismissDialog(0);
            Tfilon.this.showMain();
        }
    };

    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        res = getResources();
        // Change locale settings in the app.
        DisplayMetrics dm = res.getDisplayMetrics();
        android.content.res.Configuration conf = res.getConfiguration();
        conf.locale = Locale.FRENCH;
        res.updateConfiguration(conf, dm);
        locale_gravity = Gravity.RIGHT;

        cities = new City[]{
                new City(1, new int[]{32, 49, 25, 0}, new int[]{35, 45, 57, 0}, "אבני איתן, ישראל", 21, true, 2, 385),
                new City(2, new int[]{32, 17, 9, 0}, new int[]{35, 4, 20, 0}, "אבני חפץ, ישראל", 21, true, 2, 200),
                new City(3, new int[]{29, 33, 26, 0}, new int[]{34, 57, 46, 0}, "אילת, ישראל", 21, true, 2, 1),
                new City(4, new int[]{32, 14, 10, 0}, new int[]{35, 19, 54, 0}, "אלון מורה, ישראל", 21, true, 2, 635),
                new City(5, new int[]{31, 39, 17, 0}, new int[]{35, 7, 32, 0}, "אלון שבות, ישראל", 21, true, 2, 965),
                new City(6, new int[]{33, 2, 35, 0}, new int[]{35, 50, 16, 0}, "אלוני הבשן, ישראל", 21, true, 2, 960),
                new City(7, new int[]{32, 3, 0, 0}, new int[]{34, 57, 18, 0}, "אלעד, ישראל", 21, true, 2, 120),
                new City(8, new int[]{31, 39, 29, 0}, new int[]{35, 9, 11, 0}, "אפרת, ישראל", 21, true, 2, 910),
                new City(9, new int[]{32, 6, 22, 0}, new int[]{35, 11, 16, 0}, "אריאל, ישראל", 21, true, 2, 560),
                new City(10, new int[]{31, 48, 0, 0}, new int[]{34, 38, 24, 0}, "אשדוד, ישראל", 21, true, 2, 23),
                new City(11, new int[]{31, 40, 11, 0}, new int[]{34, 34, 28, 0}, "אשקלון, ישראל", 21, true, 2, 10),
                new City(12, new int[]{31, 15, 1, 0}, new int[]{34, 47, 53, 0}, "באר שבע, ישראל", 30, true, 2, 247),
                new City(13, new int[]{31, 56, 30, 0}, new int[]{35, 13, 22, 0}, "בית אל, ישראל", 21, true, 2, 860),
                new City(14, new int[]{32, 29, 48, 0}, new int[]{35, 29, 55, 0}, "בית שאן, ישראל", 21, true, 2, 0),
                new City(15, new int[]{31, 44, 49, 0}, new int[]{34, 59, 17, 0}, "בית שמש, ישראל", 21, true, 2, 219),
                new City(16, new int[]{31, 41, 52, 0}, new int[]{35, 6, 56, 0}, "ביתר עילית, ישראל", 21, true, 2, 870),
                new City(17, new int[]{32, 5, 24, 0}, new int[]{34, 51, 0, 0}, "בני ברק, ישראל", 21, true, 2, 24),
                new City(18, new int[]{32, 4, 41, 0}, new int[]{34, 50, 56, 0}, "גבעת שמואל, ישראל", 21, true, 2, 50),
                new City(19, new int[]{32, 4, 7, 0}, new int[]{34, 48, 28, 0}, "גבעתיים, ישראל", 21, true, 2, 10),
                new City(20, new int[]{31, 49, 3, 0}, new int[]{34, 47, 6, 0}, "גדרה, ישראל", 21, true, 2, 39),
                new City(21, new int[]{31, 55, 38, 0}, new int[]{34, 56, 28, 0}, "גמזו, ישראל", 21, true, 2, 161),
                new City(22, new int[]{32, 11, 34, 0}, new int[]{35, 15, 55, 0}, "הר ברכה, ישראל", 21, true, 2, 850),
                new City(23, new int[]{32, 9, 15, 0}, new int[]{34, 50, 41, 0}, "הרצליה, ישראל", 21, true, 2, 20),
                new City(24, new int[]{31, 31, 57, 0}, new int[]{35, 5, 59, 0}, "חברון, ישראל", 21, true, 2, 927),
                new City(25, new int[]{32, 26, 9, 0}, new int[]{34, 55, 12, 0}, "חדרה, ישראל", 21, true, 2, 25),
                new City(26, new int[]{32, 50, 42, 0}, new int[]{35, 47, 33, 0}, "חיספין, ישראל", 21, true, 2, 415),
                new City(27, new int[]{32, 49, 12, 0}, new int[]{34, 59, 24, 0}, "חיפה, ישראל", 30, true, 2, 290),
                new City(28, new int[]{31, 58, 54, 0}, new int[]{35, 32, 31, 0}, "חצור הגלילית, ישראל", 21, true, 2, 340),
                new City(29, new int[]{31, 55, 59, 0}, new int[]{35, 1, 29, 0}, "חשמונאים, ישראל", 21, true, 2, 190),
                new City(30, new int[]{32, 47, 20, 0}, new int[]{35, 31, 20, 0}, "טבריה, ישראל", 21, true, 2, 0),
                new City(31, new int[]{31, 55, 48, 0}, new int[]{35, 7, 12, 0}, "טלמון, ישראל", 21, true, 2, 560),
                new City(32, new int[]{31, 52, 35, 0}, new int[]{34, 44, 16, 0}, "יבנה, ישראל", 21, true, 2, 30),
                new City(33, new int[]{31, 47, 50, 0}, new int[]{34, 49, 17, 0}, "יד בנימין, ישראל", 21, true, 2, 70),
                new City(34, new int[]{30, 59, 20, 0}, new int[]{34, 56, 2, 0}, "ירוחם, ישראל", 21, true, 2, 0),
                new City(35, new int[]{31, 46, 42, 0}, new int[]{35, 14, 9, 0}, "ירושלים, ישראל", 40, true, 2, 766),
                new City(36, new int[]{31, 12, 22, 0}, new int[]{34, 19, 36, 0}, "יתד, ישראל", 21, true, 2, 82),
                new City(37, new int[]{31, 59, 23, 0}, new int[]{34, 50, 57, 0}, "כפר חב\"ד, ישראל", 21, true, 2, 57),
                new City(38, new int[]{31, 36, 31, 0}, new int[]{35, 6, 0, 0}, "כרמי צור, ישראל", 21, true, 2, 950),
                new City(39, new int[]{32, 54, 48, 0}, new int[]{35, 17, 56, 0}, "כרמיאל, ישראל", 21, true, 2, 262),
                new City(40, new int[]{31, 56, 55, 0}, new int[]{34, 53, 20, 0}, "לוד, ישראל", 21, true, 2, 0),
                new City(41, new int[]{31, 54, 18, 0}, new int[]{35, 0, 39, 0}, "מודיעין, ישראל", 21, true, 2, 262),
                new City(42, new int[]{32, 49, 40, 0}, new int[]{35, 14, 7, 0}, "מורשת, ישראל", 21, true, 2, 309),
                new City(43, new int[]{31, 46, 38, 0}, new int[]{35, 18, 9, 0}, "מעלה אדומים, ישראל", 21, true, 2, 500),
                new City(44, new int[]{31, 48, 58, 0}, new int[]{35, 23, 39, 0}, "מצפה יריחו, ישראל", 21, true, 2, 160),
                new City(45, new int[]{33, 0, 13, 0}, new int[]{35, 5, 33, 0}, "נהריה, ישראל", 21, true, 2, 15),
                new City(46, new int[]{31, 40, 43, 0}, new int[]{35, 8, 37, 0}, "נווה דניאל, ישראל", 21, true, 2, 930),
                new City(47, new int[]{31, 52, 16, 0}, new int[]{34, 59, 29, 0}, "נוף איילון, ישראל", 21, true, 2, 164),
                new City(48, new int[]{31, 37, 48, 0}, new int[]{34, 57, 16, 0}, "נחושה, ישראל", 21, true, 2, 421),
                new City(49, new int[]{31, 44, 15, 0}, new int[]{34, 37, 21, 0}, "ניצן, ישראל", 21, true, 2, 43),
                new City(50, new int[]{31, 44, 42, 0}, new int[]{35, 3, 29, 0}, "נס הרים, ישראל", 21, true, 2, 575),
                new City(51, new int[]{31, 25, 23, 0}, new int[]{34, 35, 43, 0}, "נתיבות, ישראל", 21, true, 2, 41),
                new City(52, new int[]{32, 19, 48, 0}, new int[]{34, 51, 36, 0}, "נתניה, ישראל", 21, true, 2, 60),
                new City(53, new int[]{31, 23, 32, 0}, new int[]{35, 6, 48, 0}, "סוסיא, ישראל", 21, true, 2, 800),
                new City(54, new int[]{31, 21, 43, 0}, new int[]{34, 54, 10, 0}, "סנסנה, ישראל", 21, true, 2, 526),
                new City(55, new int[]{31, 28, 13, 0}, new int[]{34, 32, 6, 0}, "סעד, ישראל", 21, true, 2, 0),
                new City(56, new int[]{32, 0, 2, 0}, new int[]{35, 10, 38, 0}, "עטרת, ישראל", 21, true, 2, 720),
                new City(57, new int[]{32, 55, 44, 0}, new int[]{35, 4, 35, 0}, "עכו, ישראל", 21, true, 2, 10),
                new City(58, new int[]{32, 4, 12, 0}, new int[]{35, 16, 12, 0}, "עלי, ישראל", 21, true, 2, 710),
                new City(59, new int[]{31, 15, 37, 0}, new int[]{35, 12, 49, 0}, "ערד, ישראל", 21, true, 2, 570),
                new City(60, new int[]{32, 36, 34, 0}, new int[]{35, 17, 27, 0}, "עפולה, ישראל", 21, true, 2, 60),
                new City(61, new int[]{32, 3, 45, 0}, new int[]{35, 3, 11, 0}, "פדואל, ישראל", 21, true, 2, 400),
                new City(62, new int[]{31, 53, 57, 0}, new int[]{35, 13, 26, 0}, "פסגות, ישראל", 21, true, 2, 860),
                new City(63, new int[]{32, 5, 24, 0}, new int[]{34, 52, 48, 0}, "פתח תקוה, ישראל", 40, true, 2, 56),
                new City(64, new int[]{32, 59, 11, 0}, new int[]{35, 29, 34, 0}, "צפת, ישראל", 21, true, 2, 642),
                new City(65, new int[]{32, 59, 32, 0}, new int[]{35, 41, 30, 0}, "קצרין, ישראל", 21, true, 2, 320),
                new City(66, new int[]{32, 3, 23, 0}, new int[]{34, 51, 38, 0}, "קריית אונו, ישראל", 21, true, 2, 65),
                new City(67, new int[]{31, 36, 22, 0}, new int[]{34, 46, 18, 0}, "קריית גת, ישראל", 21, true, 2, 125),
                new City(68, new int[]{33, 12, 30, 0}, new int[]{35, 34, 21, 0}, "קריית שמונה, ישראל", 21, true, 2, 80),
                new City(69, new int[]{32, 10, 18, 0}, new int[]{35, 5, 52, 0}, "קרני שומרון, ישראל", 21, true, 2, 340),
                new City(70, new int[]{32, 58, 44, 0}, new int[]{35, 48, 33, 0}, "קשת, ישראל", 21, true, 2, 710),
                new City(71, new int[]{32, 5, 42, 0}, new int[]{34, 57, 29, 0}, "ראש העין, ישראל", 21, true, 2, 30),
                new City(72, new int[]{31, 57, 40, 0}, new int[]{34, 48, 38, 0}, "ראשון לציון, ישראל", 21, true, 2, 40),
                new City(73, new int[]{31, 53, 34, 0}, new int[]{34, 48, 41, 0}, "רחובות, ישראל", 21, true, 2, 49),
                new City(74, new int[]{31, 55, 43, 0}, new int[]{34, 51, 52, 0}, "רמלה, ישראל", 21, true, 2, 0),
                new City(75, new int[]{31, 42, 53, 0}, new int[]{34, 59, 58, 0}, "רמת בית שמש, ישראל", 21, true, 2, 422),
                new City(76, new int[]{32, 4, 14, 0}, new int[]{34, 49, 36, 0}, "רמת גן, ישראל", 21, true, 2, 5),
                new City(77, new int[]{32, 11, 0, 0}, new int[]{34, 53, 0, 0}, "רעננה, ישראל", 21, true, 2, 49),
                new City(78, new int[]{32, 3, 15, 0}, new int[]{35, 18, 39, 0}, "שבות רחל, ישראל", 21, true, 2, 700),
                new City(79, new int[]{32, 15, 50, 0}, new int[]{35, 11, 6, 0}, "שבי שומרון, ישראל", 21, true, 2, 350),
                new City(80, new int[]{32, 26, 25, 0}, new int[]{35, 30, 54, 0}, "שדה אליהו, ישראל", 21, true, 2, 0),
                new City(81, new int[]{31, 31, 22, 0}, new int[]{34, 35, 44, 0}, "שדרות, ישראל", 21, true, 2, 103),
                new City(82, new int[]{32, 3, 14, 0}, new int[]{35, 17, 52, 0}, "שילה, ישראל", 21, true, 2, 700),
                new City(83, new int[]{32, 4, 12, 0}, new int[]{34, 46, 12, 0}, "תל אביב, ישראל", 21, true, 2, 0),
                new City(84, new int[]{33, 51, 36, 1}, new int[]{151, 12, 40, 0}, "סידני, אוסטרליה", 18, false, 10, 0),
                new City(85, new int[]{34, 52, 0, 1}, new int[]{56, 10, 0, 1}, "מונטווידאו, אורוגוואי", 18, false, -3, 43),
                new City(86, new int[]{51, 30, 26, 0}, new int[]{0, 7, 39, 1}, "לונדון, אנגליה", 18, false, 0, 24),
                new City(87, new int[]{53, 28, 0, 0}, new int[]{2, 13, 0, 1}, "מנצ'סטר, אנגליה", 18, false, 0, 38),
                new City(88, new int[]{34, 36, 13, 1}, new int[]{58, 22, 54, 1}, "בואנוס איירס, ארגנטינה", 18, false, -3, 10),
                new City(89, new int[]{30, 18, 1, 0}, new int[]{97, 44, 50, 1}, "אוסטין, ארה\"ב", 18, false, -6, 149),
                new City(90, new int[]{39, 17, 11, 0}, new int[]{76, 36, 54, 1}, "בולטימור, ארה\"ב", 18, false, -5, 10),
                new City(91, new int[]{39, 45, 3, 0}, new int[]{104, 54, 35, 1}, "דנוור, ארה\"ב", 18, false, -7, 1600),
                new City(92, new int[]{42, 19, 54, 0}, new int[]{83, 2, 51, 1}, "דטרויט, ארה\"ב", 18, false, -5, 183),
                new City(93, new int[]{38, 54, 36, 0}, new int[]{77, 1, 12, 1}, "וושינגטון די. סי., ארה\"ב", 18, false, -5, 60),
                new City(94, new int[]{34, 3, 8, 0}, new int[]{118, 14, 36, 1}, "לוס אנג'לס, ארה\"ב", 18, false, -8, 71),
                new City(95, new int[]{25, 46, 48, 0}, new int[]{80, 12, 36, 1}, "מיאמי, ארה\"ב", 18, false, -5, 2),
                new City(96, new int[]{44, 58, 48, 0}, new int[]{93, 15, 7, 1}, "מיניאפוליס, ארה\"ב", 18, false, -6, 264),
                new City(97, new int[]{35, 7, 3, 0}, new int[]{89, 58, 16, 1}, "ממפיס, ארה\"ב", 18, false, -6, 103),
                new City(98, new int[]{40, 40, 12, 0}, new int[]{73, 56, 24, 1}, "ניו יורק, ארה\"ב", 18, false, -5, 10),
                new City(99, new int[]{37, 46, 45, 0}, new int[]{122, 25, 9, 1}, "סן פרנסיסקו, ארה\"ב", 18, false, -8, 16),
                new City(100, new int[]{41, 54, 0, 0}, new int[]{87, 39, 0, 1}, "שיקגו, ארה\"ב", 18, false, -6, 182),
                new City(101, new int[]{45, 30, 0, 0}, new int[]{9, 15, 0, 0}, "מילאנו, איטליה", 18, false, 1, 120),
                new City(102, new int[]{41, 53, 44, 0}, new int[]{12, 28, 56, 0}, "רומא, איטליה", 18, false, 1, 20),
                new City(103, new int[]{51, 13, 0, 0}, new int[]{4, 24, 0, 0}, "אנטוורפן, בלגיה", 18, false, 1, 0),
                new City(104, new int[]{23, 33, 1, 1}, new int[]{46, 38, 2, 1}, "סאו פאולו, ברזיל", 18, false, -3, 760),
                new City(105, new int[]{52, 22, 29, 0}, new int[]{4, 53, 32, 0}, "אמסטרדם, הולנד", 18, false, 1, 2),
                new City(106, new int[]{29, 6, 0, 1}, new int[]{26, 13, 0, 0}, "בלומפונטיין, דרום אפריקה", 18, false, 2, 1395),
                new City(107, new int[]{29, 51, 0, 1}, new int[]{31, 1, 0, 0}, "דרבן, דרום אפריקה", 18, false, 2, 0),
                new City(108, new int[]{26, 12, 16, 1}, new int[]{28, 2, 44, 0}, "יוהנסבורג, דרום אפריקה", 18, false, 1, 1753),
                new City(109, new int[]{33, 55, 0, 1}, new int[]{18, 25, 0, 0}, "קייפטאון, דרום אפריקה", 18, false, 2, 0),
                new City(110, new int[]{42, 9, 18, 0}, new int[]{19, 7, 15, 0}, "זאבליאק, מונטנגרו", 18, false, 1, 1435),
                new City(111, new int[]{55, 51, 29, 0}, new int[]{4, 15, 32, 1}, "גלאזגו, סקוטלנד", 18, false, 0, 0),
                new City(112, new int[]{52, 13, 47, 0}, new int[]{21, 0, 44, 0}, "ורשה, פולין", 18, false, 1, 100),
                new City(113, new int[]{50, 3, 53, 0}, new int[]{19, 56, 42, 0}, "קראקוב, פולין", 18, false, 1, 219),
                new City(114, new int[]{8, 59, 0, 0}, new int[]{79, 31, 0, 1}, "פנמה סיטי, פנמה", 18, false, -5, 2),
                new City(115, new int[]{43, 17, 51, 0}, new int[]{5, 22, 38, 0}, "מרסיי, צרפת", 18, false, 1, 0),
                new City(116, new int[]{48, 51, 36, 0}, new int[]{2, 20, 24, 0}, "פריז, צרפת", 18, false, 1, 100),
                new City(117, new int[]{43, 39, 0, 0}, new int[]{79, 23, 0, 1}, "טורונטו, קנדה", 18, false, -5, 76),
                new City(118, new int[]{45, 30, 32, 0}, new int[]{73, 33, 15, 1}, "מונטריאול, קנדה", 18, false, -5, 0),
                new City(119, new int[]{42, 38, 27, 0}, new int[]{18, 6, 32, 0}, "דוברובניק, קרואטיה", 18, false, 1, 21),
                new City(120, new int[]{47, 22, 48, 0}, new int[]{8, 32, 24, 0}, "ציריך, שווייץ", 18, false, 1, 408)
        };
        SharedPreferences settings = getPreferences(MODE_PRIVATE);
        purimDay = settings.getInt("purimDay", YD);
        censor = settings.getBoolean("censor", true);
        vaanenu = settings.getBoolean("vaanenu", false);
        doctor = settings.getBoolean("doctor", false);
        doctorNames = settings.getString("doctorNames", "");
        city = cities[settings.getInt("city", 34)];
        chul = !city.isInIsrael;
        summerTime = settings.getBoolean("summerTime", false);
        font = settings.getInt("font", 4);
        ratio = settings.getInt("ratio", 2);
        defaultNusach = settings.getInt("nusach", 0);
        nightMode = settings.getBoolean("night", false);
        autoHide = settings.getBoolean("autoHide", true);
        reverse = settings.getBoolean("reverse", false);
        String strSpecialText = settings.getString("specialText", "red");
        String strKoteretText = settings.getString("koteretText", "blue");
        specialText = (strSpecialText.compareTo("red") == 0 ? RED : strSpecialText.compareTo("blue") == 0 ? BLUE : strSpecialText.compareTo("green") == 0 ? GREEN : strSpecialText.compareTo("purple") == 0 ? PURPLE : null);
        koteretText = (strKoteretText.compareTo("red") == 0 ? RED : strKoteretText.compareTo("blue") == 0 ? BLUE : strKoteretText.compareTo("green") == 0 ? GREEN : strKoteretText.compareTo("purple") == 0 ? PURPLE : null);
        loadLetters();
        setDayData();
        ezraTF = tf = Typeface.createFromAsset(getAssets(), /* "HadasimCLM-Regular.ttf" */"SILEOTSR.ttf"/* "SILEOT.ttf" *//* "ShofarRegular.ttf" */);
        hadasimTF = Typeface.createFromAsset(getAssets(), "HadasimCLM-Regular.ttf");
        shofarTF = Typeface.createFromAsset(getAssets(), "ShofarRegular.ttf");
        alefTF = Typeface.createFromAsset(getAssets(), "Alef-Regular.ttf");
        showMain();
    }

    private void loadLetters() {
        try {
            if (font < 3) {
                for (int i = 0; i < 54; i++) {
                    letters[i] =
                            getImageByRatio(BitmapFactory.decodeStream(getAssets().open("letters" +
                                    font +
                                    "/" +
                                    (i + 1) + ".PNG")), ratio);
                    if (nightMode) {
                        letters[i] = negativeImage(letters[i]);
                    }
                    widths[i] = letters[i].getWidth();
                }
                letterHeight = letters[0].getHeight();
            }
        } catch (Exception localException) {
            localException.printStackTrace();
        }
        coloredLetters = null;
        System.gc();
    }

    public void showMain() {
        mode = Modes.MAIN;
        View v = getLayoutInflater().inflate(R.layout.main, null, false);
        Button button = (Button) v.findViewById(R.id.nusach);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.defaultPressed = false;
                Tfilon.this.showNusach();
            }
        });
        button = (Button) v.findViewById(R.id.defaultNusach);
        if (defaultNusach != NUSAHIM_NONE) {
            button.setVisibility(View.VISIBLE);
            button.setTypeface(tf);
            button.setTextSize(30);
            switch (defaultNusach) {
                case NUSAHIM_A:
                    button.setText(String.format("%s %s", getString(R.string.nusach), getString(R.string.ashkenaz)));
                    button.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            Tfilon.this.nusach = "a";
                            Tfilon.this.defaultPressed = true;
                            Tfilon.this.showTfilaMenu();
                        }
                    });
                    break;
                case NUSAHIM_S:
                    button.setText(String.format("%s %s", getString(R.string.nusach), getString(R.string.sfard)));
                    button.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            Tfilon.this.nusach = "s";
                            Tfilon.this.defaultPressed = true;
                            Tfilon.this.showTfilaMenu();
                        }
                    });
                    break;
                case NUSAHIM_EM:
                    button.setText(String.format("%s %s", getString(R.string.nusach), getString(R.string.edot_mizrach)));
                    button.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View v) {
                            Tfilon.this.nusach = "em";
                            Tfilon.this.defaultPressed = true;
                            Tfilon.this.showTfilaMenu();
                        }
                    });
                    break;
            }
        } else {
            button.setVisibility(View.GONE);
        }
        button = (Button) v.findViewById(R.id.help);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showHelp();
            }
        });
        button = (Button) v.findViewById(R.id.about);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showAbout();
            }
        });
        button = (Button) v.findViewById(R.id.zmanim);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showZmanim();
            }
        });
        button = (Button) v.findViewById(R.id.settings);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showSettings();
            }
        });
//        button = (Button) v.findViewById(R.id.korona);
//        button.setTypeface(tf);
//        button.setTextSize(30);
//        button.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                Tfilon.this.showKorona();
//            }
//        });
        button = (Button) v.findViewById(R.id.tzahal);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTzahal();
            }
        });

        showViewWithBar(v, getString(R.string.app_name), false);
    }

    public void showNusach() {
        View v = getLayoutInflater().inflate(R.layout.nusach, null, false);
        Button button =
                (Button) v.findViewById(R.id.ashkenaz);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.nusach = "a";
                Tfilon.this.showTfilaMenu();
            }
        });
        button = (Button) v.findViewById(R.id.sfard);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.nusach = "s";
                Tfilon.this.showTfilaMenu();
            }
        });
        button = (Button) v.findViewById(R.id.em);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.nusach = "em";
                Tfilon.this.showTfilaMenu();
            }
        });
        showViewWithBar(v, getString(R.string.nusach_selection_button), false);
        Tfilon.mode = Modes.NUSACH;
    }

    public void showTfilaMenu() {
        long dd = (sunset ? this.nextDayData : this.dayData);

        mode = Modes.TFILAMENU;
        View v = getLayoutInflater().inflate(R.layout.tfilamenu, null, false);

        Button button = (Button) v.findViewById(R.id.shacharit);
        final String shacharitButtonText;
        if ((dd & MUSAF) == 0) {
            shacharitButtonText = getString(R.string.shacharit);
        } else {
            shacharitButtonText = getString(R.string.shacharit_musaf);
        }
        button.setText(shacharitButtonText);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("shacharit", shacharitButtonText, 0);
            }
        });
        button = (Button) v.findViewById(R.id.mincha);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showMincha();
            }
        });
        button = (Button) v.findViewById(R.id.arvit);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                showArvit();
            }
        });
        button = (Button) v.findViewById(R.id.mita);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("mita", getString(R.string.mita), 0);
            }
        });
        button = (Button) v.findViewById(R.id.chatzot);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showChatzot();
            }
        });
        button = (Button) v.findViewById(R.id.mazon);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("mazon", getString(R.string.mazon), 0);
            }
        });
        button = (Button) v.findViewById(R.id.shalosh);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("shalosh", getString(R.string.shalosh), 0);
            }
        });
        button = (Button) v.findViewById(R.id.shevaBrachot);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("shevaBrachot", getString(R.string.sheva_brachot), 0);
            }
        });
        button = (Button) v.findViewById(R.id.brit);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("brit", getString(R.string.brit), 0);
            }
        });
        button = (Button) v.findViewById(R.id.nefashot);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("nefashot", getString(R.string.nefashot), 0);
            }
        });
        button = (Button) v.findViewById(R.id.yatzar);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("yatzar", getString(R.string.yatzar), 0);
            }
        });
        button = (Button) v.findViewById(R.id.derech);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("derech", getString(R.string.derech), 0);
            }
        });
        button = (Button) v.findViewById(R.id.levana);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Tfilon.this.showTfila("levana", getString(R.string.levana), 0);
            }
        });
        button = (Button) v.findViewById(R.id.omer);
        if ((dd & OMER) == 0) {
            button.setVisibility(View.GONE);
            button.setEnabled(false);
        } else {
            button.setTypeface(tf);
            button.setTextSize(30);
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Tfilon.this.showTfila("omer", getString(R.string.omer), 0);
                }
            });
        }
        button = (Button) v.findViewById(R.id.nerot);
        if ((this.nextDayData & CHANUKA) == 0 &&
                (this.dayData & CHANUKA) == 0) {
            button.setVisibility(View.GONE);
            button.setEnabled(false);
        } else {
            button.setTypeface(tf);
            button.setTextSize(30);
            button.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Tfilon.this.showTfila("nerot", getString(R.string.nerot), 0);
                }
            });
        }

        String title = String.format("%s ", getString(R.string.nusach));
        if (nusach.equals("a")) {
            title += getString(R.string.ashkenaz);
        } else if (nusach.equals("s")) {
            title += getString(R.string.sfard);
        } else if (nusach.equals("em")) {
            title += getString(R.string.edot_mizrach);
        }

        showViewWithBar(v, title, false);
    }

    public void showMincha() {
        if (sunset) {
            showDialog(1);
        }
        else {
            Tfilon.this.showTfila("mincha", getString(R.string.mincha), 0);
        }
    }

    public void showArvit() {
        if (!sunset && sunrise) {
            showDialog(2);
        } else {
            Tfilon.this.showTfila("arvit", getString(R.string.arvit), 0);
        }
    }

    public void showViewWithBar(View view, String title, boolean showMenu) {
        final ScrollView innerScroll = new ScrollView(this) {
            public boolean onTouchEvent(MotionEvent ev) {
                return false;
            }
        };

        ViewGroup outView = null;

        if (view instanceof ObservableScrollView && autoHide) {
            outView = new FrameLayout(this);
        } else {
            outView = new LinearLayout(this);
            ((LinearLayout) outView).setOrientation(LinearLayout.VERTICAL);
        }

        final ViewGroup outLayout = outView;

        final LinearLayout inLayout = new LinearLayout(this);
        inLayout.setOrientation(LinearLayout.HORIZONTAL);
        inLayout.setLayoutParams(new ViewGroup.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        int pixels = (int) (10 * res.getDisplayMetrics().density);

        ImageView ivBack = new ImageView(this);
        ivBack.setImageResource(R.drawable.ic_back);
        ivBack.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0.1f));
        ivBack.setPadding(pixels, pixels, pixels / 2, pixels);
        ivBack.setOnClickListener(new OnClickListener() {
            public void onClick(View view) {
                goBack();
            }
        });
        inLayout.addView(ivBack);

        AutoResizeTextView tv = new AutoResizeTextView(this);
        tv.setText(title);
        tv.setPadding(pixels, tv.getPaddingTop(), pixels, tv.getPaddingBottom());
        tv.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT, 0.9f));
        tv.setTypeface(tf);
        tv.setSingleLine();
        tv.setGravity(Gravity.CENTER_VERTICAL | locale_gravity);
        inLayout.addView(tv);

        if (showMenu) {
            ImageView ivMenu = new ImageView(this);
            ivMenu.setImageResource(R.drawable.ic_skips_light);
            ivMenu.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0.1f));
            ivMenu.setPadding(pixels / 2, pixels, pixels, pixels);
            ivMenu.setOnClickListener(new OnClickListener() {
                public void onClick(View view) {
                    curPage.showContextMenu();
                }
            });
            inLayout.addView(ivMenu);
            ivMenu.setBackgroundColor(Color.BLACK);
        }

        inLayout.setBackgroundColor(Color.BLACK);
        ivBack.setBackgroundColor(Color.BLACK);
        tv.setBackgroundColor(Color.BLACK);

        if (view instanceof ObservableScrollView && autoHide) {
            final ObservableScrollView s = (ObservableScrollView) view;

            s.setScrollViewListener(new ScrollViewListener() {

                public void onScrollChanged(ObservableScrollView scrollView, int x, int y, int oldx, int oldy) {
                    if (scrollView.showBarAtFinish) {
                        innerScroll.smoothScrollTo(0, 0);
                    } else {
                        innerScroll.smoothScrollBy(x - oldx, y - oldy);
                    }
                }

                public void onScrollFinished(ObservableScrollView scrollView) {
                    if (scrollView.showBarAtFinish) {
                        showBar();
                        scrollView.showBarAtFinish = false;
                        return;
                    }
                    View child = innerScroll.getChildAt(0);
                    int totalHeight = child.getHeight() - innerScroll.getHeight();
                    int y = innerScroll.getScrollY();
                    float p = ((float) y) / ((float) totalHeight);
                    ScrollViewListener listener;
                    if (p <= 0.5) {
                        innerScroll.smoothScrollBy(0, -y);
                        listener = scrollView.getScrollViewListener();
                        scrollView.setScrollViewListener(null);
                        scrollView.smoothScrollBy(0, -y);
                        scrollView.setScrollViewListener(listener);
                    } else {
                        innerScroll.smoothScrollBy(0, totalHeight - y);
                        listener = scrollView.getScrollViewListener();
                        scrollView.setScrollViewListener(null);
                        scrollView.smoothScrollBy(0, totalHeight - y);
                        scrollView.setScrollViewListener(listener);
                    }
                }

                public void showBar() {
                    innerScroll.scrollTo(0, 0);
                }
            });
        }

        if (!(view instanceof ObservableScrollView && autoHide)) {
            outLayout.addView(inLayout);
        }
        outLayout.addView(view);
        if (view instanceof ObservableScrollView && autoHide) {
            LinearLayout inVerticalLayout = new LinearLayout(this);
            inVerticalLayout.setOrientation(LinearLayout.VERTICAL);
            LinearLayout inVerticalLayout2 = new LinearLayout(this);
            inVerticalLayout2.setOrientation(LinearLayout.VERTICAL);
            View stub = new View(this);
            inLayout.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            int inHeight = inLayout.getMeasuredHeight();
            stub.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, inHeight, 0.5f));
            inLayout.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT, 0.5f));
            inVerticalLayout.addView(inLayout);
            inVerticalLayout.addView(stub);
            inVerticalLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            innerScroll.addView(inVerticalLayout);
            inVerticalLayout2.addView(innerScroll);
            inVerticalLayout2.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, inHeight));
            innerScroll.setVerticalScrollBarEnabled(false);
            innerScroll.scrollTo(0, 0);
            innerScroll.setEnabled(false);
            if (view instanceof Page) {
                ((Page)view).addStub(inHeight);
            }
            outLayout.addView(inVerticalLayout2);
        }

        tv.setTextSize(60);

        setContentView(outLayout);
        outLayout.invalidate();
    }

    public void showPage(String name, String title, int forceDay) {
        if (title.equals("")) {
            title = name;
        }

        curPage = new Page(name, this, forceDay);
        curPage.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT));
        showViewWithBar(curPage, title, true);

        registerForContextMenu(curPage);
    }

    public void showTfila(String tfila, String title, int forceDay) {
        mode = Modes.TFILA;
        setDayData();
        this.showPage(nusach + "_" + tfila, title, forceDay);
    }

    public void showChatzot() {
        mode = Modes.TFILA;
        setDayData();
        this.showPage("tikun_chatzot", getString(R.string.chatzot), 0);
    }

    public void showHelp() {
        mode = Modes.HELP;
        this.showPage("help", getString(R.string.help_button), 0);
    }

    public void showTzahal() {
        mode = Modes.HELP;
        this.showPage("tzahal", "תפילה לעת צרה", 0);
    }

    public void showKorona() {
        mode = Modes.HELP;
        this.showPage("korona", "תפילה לתקופת הקורונה", 0);
    }

    public void showAbout() {
        ScrollView sv = new ScrollView(this);
        TextView about = new TextView(this);
        String str = String.format("<h1>%s</h1>", getString(R.string.about_title));
        try {
            str += String.format("<h5>%s %s</h5>", getString(R.string.version_title), this.getPackageManager().getPackageInfo("tfilon.tfilon", PackageManager.GET_ACTIVITIES).versionName);
        } catch (NameNotFoundException e) {
            e.printStackTrace();
        }
        str += "<h5>© כל הזכויות שמורות לאורי הולנדר</h5>"
                + "<h5><a href='mailto:ori.hollander@gmail.com'>ori.hollander@gmail.com</a></h5>"
                + "<h5><a href='http://tfilon.com'>tfilon.com</a></h5>"
                + "<p>ניתן להפיץ תוכנה זו באופן חופשי, כל עוד לא נגבית כל עמלה שהיא בעבורה. התוכנה היא חינמית ואיני דורש שום כסף עבורה. אם הרגשת שתוכנה זו הייתה שימושית, אתה יכול לשלוח לי סכום כסף שאתה מרגיש שהוא הוגן.</p>"
                + "<p><h5>התוכנה מוקדשת לעילוי נשמת</h5>עמוס בן משעדה ז\"ל לבית סבן, נפטר כ\"ד באלול תשנ\"ט.<br>ומחדייה בת ששונה ז\"ל לבית סבן, נפטרה ט\"ו בטבת תש\"ס.<h4>ת.נ.צ.ב.ה</h4></p>"
                + "<h2>תודות</h2>"
                + "<h4>תודה רבה לחברת OpenApp (<a href='http://www.openapp.co.il'>http://www.openapp.co.il</a>) המאפשרת את קיום אתר תפילון.</h4>"
                + "יועד פריד<br>שלמה מוייאל<br>יהושע מתוק<br>מיכאל גליקמן<br>דפנה גולדרייך<br>אתר דעת<br>eBirkon<br>מכון ממרא"
                + "<p>ליוצר התוכנה אין קשר למודעה של שירות טאטע טיים (Tate Time) המופיע בפתיחת התוכנה.</p>";
        about.setText(Html.fromHtml(str));
        about.setTypeface(tf);
        about.setGravity(locale_gravity);
        about.setMovementMethod(LinkMovementMethod.getInstance());
        about.setBackgroundColor(nightMode ? Color.BLACK : Color.WHITE);
        about.setTextColor(nightMode ? Color.WHITE : Color.BLACK);
        sv.setBackgroundColor(nightMode ? Color.BLACK : Color.WHITE);
        sv.addView(about);
        sv.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_INSET);
        sv.setPadding(0, 0, 0, 0);
        showViewWithBar(sv, getString(R.string.about_button), false);
        mode = Modes.ABOUT;
    }

    public void showSettings() {
        final View v = getLayoutInflater().inflate(R.layout.settings, null, false);
        ToggleButton tgl = (ToggleButton) v.findViewById(R.id.tglVaanenu);
        tgl.setChecked(vaanenu);
        tgl.setTypeface(tf);
        tgl = (ToggleButton) v.findViewById(R.id.tglCensor);
        tgl.setChecked(censor);
        tgl.setTypeface(tf);
        tgl.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                censor = isChecked;
                refreshExamplePage(v);
            }
        });
        tgl = (ToggleButton) v.findViewById(R.id.tglDoctor);
        tgl.setChecked(doctor);
        tgl.setTypeface(tf);
        tgl = (ToggleButton) v.findViewById(R.id.tglDST);
        tgl.setChecked(summerTime);
        tgl.setTypeface(tf);
        tgl = (ToggleButton) v.findViewById(R.id.tglNight);
        tgl.setChecked(nightMode);
        tgl.setTypeface(tf);
        tgl.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                nightMode = isChecked;
                if (font == 1 || font == 2) {
                    loadLetters();
                }
                refreshExamplePage(v);
            }
        });
        tgl = (ToggleButton) v.findViewById(R.id.tglAutoHide);
        tgl.setChecked(autoHide);
        tgl.setTypeface(tf);
        tgl = (ToggleButton) v.findViewById(R.id.tglReverse);
        tgl.setChecked(reverse);
        tgl.setTypeface(tf);

        Spinner spnr = (Spinner) v.findViewById(R.id.spnrCity);
        ArrayAdapter<Object> adapter = getArrayAdapter(cities, Gravity.RIGHT);
        spnr.setAdapter(adapter);
        spnr.setSelection(city.innerId - 1);

        spnr = (Spinner) v.findViewById(R.id.spnrPurim);
        String[] items = res.getStringArray(R.array.purim_options);
        adapter = getArrayAdapter(items, locale_gravity);
        spnr.setAdapter(adapter);
        spnr.setSelection(purimDay - 1);

        spnr = (Spinner) v.findViewById(R.id.spnrFont);
        items = new String[]{"System", "Tahoma", "Ezra SIL", "Hadasim", "Shofar", "Alef"};
        adapter = getArrayAdapter(items, Gravity.LEFT);
        spnr.setAdapter(adapter);
        spnr.setSelection(font - 1);
        spnr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                font = position + 1;
                if (font == 1 || font == 2) {
                    loadLetters();
                }
                refreshExamplePage(v);
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnr = (Spinner) v.findViewById(R.id.spnrSize);
        items = res.getStringArray(R.array.font_sizes);
        adapter = getArrayAdapter(items, locale_gravity);
        spnr.setAdapter(adapter);
        spnr.setSelection(ratio - 1);
        spnr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                ratio = position + 1;
                if (font == 1 || font == 2) {
                    loadLetters();
                }
                refreshExamplePage(v);
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnr = (Spinner) v.findViewById(R.id.spnrNusach);
        items = res.getStringArray(R.array.nusachim);
        adapter = getArrayAdapter(items, locale_gravity);
        spnr.setAdapter(adapter);
        spnr.setSelection(defaultNusach);

        spnr = (Spinner) v.findViewById(R.id.spnrSpecialColor);
        items = res.getStringArray(R.array.colors);
        adapter = getArrayAdapter(items, locale_gravity);
        spnr.setAdapter(adapter);
        if (specialText == RED) {
            spnr.setSelection(0);
        } else if (specialText == BLUE) {
            spnr.setSelection(1);
        } else if (specialText == GREEN) {
            spnr.setSelection(2);
        } else if (specialText == PURPLE) {
            spnr.setSelection(3);
        }
        spnr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                specialText = (position == 0 ? RED : position == 1 ? BLUE : position == 2 ? GREEN : position == 3 ? PURPLE : null);
                refreshExamplePage(v);
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        spnr = (Spinner) v.findViewById(R.id.spnrKoteretColor);
        items = res.getStringArray(R.array.colors);
        adapter = getArrayAdapter(items, locale_gravity);
        spnr.setAdapter(adapter);
        if (koteretText == RED) {
            spnr.setSelection(0);
        } else if (koteretText == BLUE) {
            spnr.setSelection(1);
        } else if (koteretText == GREEN) {
            spnr.setSelection(2);
        } else if (koteretText == PURPLE) {
            spnr.setSelection(3);
        }
        spnr.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                koteretText = (position == 0 ? RED : position == 1 ? BLUE : position == 2 ? GREEN : position == 3 ? PURPLE : null);
                refreshExamplePage(v);
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        EditText et = (EditText) v.findViewById(R.id.etDoctor);
        et.setTypeface(tf);
        et.setGravity(Gravity.RIGHT);
        et.setText(doctorNames);

        TextView tv;
        tv = (TextView) v.findViewById(R.id.tv1);
        tv.setTypeface(tf);
        tv.setText(Html.fromHtml(getString(R.string.city_explain)));
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tvNusach);
        tv.setTypeface(tf);
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.vaanenu_title);
        tv.setTypeface(tf);
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.doctor_title);
        tv.setTypeface(tf);
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tv4);
        tv.setTypeface(tf);
        tv.setText("שמות ליה\"ר לחולים (עברית בלבד):");
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tv5);
        tv.setTypeface(tf);
        tv.setText(String.format("%s:", getString(R.string.purim_day_explain)));
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.dst_explain);
        tv.setTypeface(tf);
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.dst_title);
        tv.setTypeface(tf);
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tv7);
        tv.setTypeface(tf);
        tv.setText(String.format("%s:", getString(R.string.font_name)));
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tv8);
        tv.setTypeface(tf);
        tv.setText(String.format("%s:", getString(R.string.font_size)));
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tv9);
        tv.setTypeface(tf);
        tv.setText(String.format("%s:", getString(R.string.special_text)));
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tv10);
        tv.setTypeface(tf);
        tv.setText(String.format("%s:", getString(R.string.koteret_text)));
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.tv11);
        tv.setTypeface(tf);
        tv.setText("אם חלק מהטקסטים, כגון זמני היום ועוד מוצגים על מכשירך הפוכים סמן \"הפוך טקסט\":");
        tv.setGravity(locale_gravity);
        tv = (TextView) v.findViewById(R.id.night_mode_explain);
        tv.setTypeface(tf);
        tv = (TextView) v.findViewById(R.id.auto_hide_explain);
        tv.setTypeface(tf);

        Button button = (Button) v.findViewById(R.id.ok);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(settingsSaveListener);
        button = (Button) v.findViewById(R.id.cancel);
        button.setTypeface(tf);
        button.setTextSize(30);
        button.setOnClickListener(settingsCancelListener);

        refreshExamplePage(v);

        showViewWithBar(v, getString(R.string.settings_button), false);
        mode = Modes.SETTINGS;
    }

    public void refreshExamplePage(View v) {
        LinearLayout ll = (LinearLayout) v.findViewById(R.id.pageLinearLayout);
        ll.removeAllViews();
        Page p;
        ll.addView(p = new Page("settings_example", this, 0), new LinearLayout.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT, 1));
        p.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View __v, MotionEvent __event) {
                if (__event.getAction() == MotionEvent.ACTION_DOWN) {
                    //  Disallow the touch request for parent scroll on touch of child view
                    requestDisallowParentInterceptTouchEvent(__v, true);
                } else if (__event.getAction() == MotionEvent.ACTION_UP || __event.getAction() == MotionEvent.ACTION_CANCEL) {
                    // Re-allows parent events
                    requestDisallowParentInterceptTouchEvent(__v, false);
                }
                return false;
            }

            private void requestDisallowParentInterceptTouchEvent(View __v, Boolean __disallowIntercept) {
                while (__v.getParent() != null && __v.getParent() instanceof View) {
                    if (__v.getParent() instanceof ScrollView) {
                        __v.getParent().requestDisallowInterceptTouchEvent(__disallowIntercept);
                    }
                    __v = (View) __v.getParent();
                }
            }
        });
    }

    public ArrayAdapter<Object> getArrayAdapter(final Object[] items, final int gravity) {
        ArrayAdapter<Object> ret = new ArrayAdapter<Object>(this, android.R.layout.simple_spinner_item, items) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTypeface(tf);
                ((TextView) v).setTextSize(20);
                ((TextView) v).setGravity(gravity | Gravity.CENTER_VERTICAL);
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                CheckedTextView v = (CheckedTextView)super.getDropDownView(position, convertView, parent);
                v.setTypeface(tf);
                v.setTextSize(20);
                v.setGravity(gravity | Gravity.CENTER_VERTICAL);
                v.setSingleLine(false);
                v.setMaxLines(2);
                v.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                return v;
            }
        };
        ret.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        return ret;
    }

    public void showZmanim() {
        ScrollView sv = new ScrollView(this);
        TextView zmanimTV = new TextView(this);
        zmanimTV.setText(Html.fromHtml(zmanimText));
        zmanimTV.setTypeface(tf);
        zmanimTV.setGravity(locale_gravity);
        zmanimTV.setBackgroundColor(nightMode ? Color.BLACK : Color.WHITE);
        zmanimTV.setTextColor(nightMode ? Color.WHITE : Color.BLACK);
        sv.setBackgroundColor(nightMode ? Color.BLACK : Color.WHITE);
        sv.addView(zmanimTV);
        sv.setScrollBarStyle(View.SCROLLBARS_OUTSIDE_INSET);
        sv.setPadding(0, 0, 0, 0);
        showViewWithBar(sv, getString(R.string.zmanim_button), false);
        mode = Modes.ZMANIM;
    }

    public String readFile(String fname) {
        InputStream inputStream;
        String errorStr = "([\r\nשגיאה: בעיה בקריאה מקובץ.\r\n])\r\n";
        try {
            inputStream = getAssets().open(fname);
        } catch (Exception e) {
            e.printStackTrace();
            return errorStr;
        }
        ByteArrayOutputStream outputStream =
                new ByteArrayOutputStream();
        byte buf[] = new byte[1024];
        int len;
        try {
            while ((len = inputStream.read(buf)) != -1) {
                outputStream.write(buf, 0, len);
            }
            outputStream.close();
            inputStream.close();
        } catch (Exception e) {
            e.printStackTrace();
            return errorStr;
        }
        String line;
        try {
            line = outputStream.toString("UTF-8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return errorStr;
        }
        line = line.substring(1);
        return line;
    }

    public long getNowDayData(int forceDay) {
        long nowDayData;
        if ((sunset && forceDay == 0) || forceDay == 2) {
            nowDayData = nextDayData;
        } else {
            nowDayData = dayData;
        }
        return nowDayData;
    }

    public String getNowKria() {
        String nowKria;
        if (sunset) {
            nowKria = kria[1];
        } else {
            nowKria = kria[0];
        }
        return nowKria;
    }

    public long getDayData(int offset) {
        long dayData = 0;

        EventData.resetDisplaySettings();

        LocationHolder lh = new LocationHolder();
        if (city.isInIsrael) {
            chul = false;
            lh.holidayStyle = LocationHolder.HSTYLE_ISRAEL;
        } else {
            chul = true;
            lh.holidayStyle = LocationHolder.HSTYLE_DIASPORA;
        }
        DateHolder dh = new DateHolder();
        dh.acceptCurrentDate();
        dh.incrementDay(offset);
        int sedra = Sedrot.getSedraIndex(dh, lh);
        final String sedrotNames[] = {"bereshit", "noach", "lech_lecha", "vayera", "chayei_sara",
                "toledot", "vayetze", "vayishlach", "vayeshev", "miketz",
                "vayigash", "vaychi", "shemot", "vaera", "bo",
                "beshalach", "yitro", "mishpatim", "teruma", "tetzave",
                "ki_tisa", "vayakhel", "pekudei", "vayikra", "tzav",
                "shemini", "tazria", "metzora", "acharei_mot", "kedoshim",
                "emor", "behar", "bechukotai", "bemidbar", "naso",
                "behaalotecha", "shelach_lecha", "korach", "chukat", "balak",
                "pinechas", "matot", "masei", "devarim", "vaetchanan",
                "ekev", "ree", "shofetim", "ki_tetze", "ki_tavo",
                "nitzavim", "vayelech", "haazinu", "vezot_haberacha"
        };
        if (sedra != -1) {
            kria[offset] = sedrotNames[sedra];
        }
        DateData dd = dh.dateHebrew;
        int day = dd.day;
        int month = dd.month;
        int year = dd.year;
        boolean leap = HebCalendar.isLeapYear(year);
        if (leap) {
            dayData |= LEAP;
        }
        int dayOfWeek = HebCalendar.getDayOfWeek(dh.dateAbsolute);

        if (dayOfWeek == 1) {
            dayData |= MON | MON_THU | TORA;
        }

        if (dayOfWeek == 2) {
            dayData |= TUE;
        }

        if (dayOfWeek == 3) {
            dayData |= WED;
        }

        if (dayOfWeek == 4) {
            dayData |= THU | MON_THU | TORA;
        }

        if (dayOfWeek == 5) {
            dayData |= FRI;
        }

        if (//
                (month == 0 && (day == 16 || day == 22 || (chul && (day == 17 || day == 23))))//
                        ||
                        (month == 2 && (day == 7 || (chul && day == 8)))//
                        ||
                        (month == 6 && (day == 3 || day == 11 ||
                                day == 16 || day == 23 || (chul && (day == 17 || day == 24))))//
                ) {
            dayData |= CHONANTANU | HAVDALA;
        }

        if (day == 1 || day == 30) {
            dayData |= RH | TORA;
            kria[offset] = "rh";
            if (leap && month >= 6) {
                dayData |= KAPARAT_PASHA;
            }
        }

        if (month == 6 && (day >= 16 && day <= 21)) {
            dayData |= SUCOT | TORA;
            if (day == 21) {
                dayData |= HOSHANA_RABA | SHABBAT;
            }
            kria[offset] = "sucot" + (day - 15);
            if (chul) {
                kria[offset] += "_chul";
            }
        }

        if (month == 6 && day >= 23 || month >= 7 ||
                month == 0 && day <= 14) {
            dayData |= WINTER_TAL;
        } else {
            dayData |= SUMMER_TAL;
        }

        if (chul) {
            DateData gdd = dh.dateSecular;
            int gday = gdd.day;
            int gmonth = gdd.month;
            int gyear = gdd.year;
            if ((gmonth == 11 && gday >= (gyear % 4 == 3 ? 6 : 5)) ||
                    gmonth == 0 ||
                    gmonth == 1 || month >= 10 ||
                    month == 0 && day <= 14) {
                dayData |= WINTER_BRACHA;
            } else {
                dayData |= SUMMER_BRACHA;
            }
        } else {
            if (month == 7 && day >= 7 || month >= 8 ||
                    month == 0 && day <= 14) {
                dayData |= WINTER_BRACHA;
            } else {
                dayData |= SUMMER_BRACHA;
            }
        }

        if (leap) {
            if (month == 12 && ((day == 14 && (purimDay & YD) != 0) || (day == 15 && (purimDay & TU) != 0))) {
                dayData |= PURIM | MEGILAT_ESTER | TORA;
                kria[offset] = "purim";
            }

            if (month == 12 && ((day == 13) || (day == 11 && dayOfWeek == 4))) {
                dayData |= TAANIT | ESTER | TORA | SLICHOT;
                kria[offset] = "taanit";
            }

            if (month == 12 && day == 14 && dayOfWeek == 5) {
                dayData |= MEGILAT_ESTER;
            }

            if (month == 12 && day == 16 && dayOfWeek == 0 && (purimDay & TU) == 0) {
                dayData |= PURIM_MESHULASH_TACHANUN_MESSAGE;
            }

        } else {
            if (month == 11 && ((day == 14 && (purimDay & YD) != 0) || (day == 15 && (purimDay & TU) != 0))) {
                dayData |= PURIM | MEGILAT_ESTER | TORA;
                kria[offset] = "purim";
            }

            if (month == 11 && ((day == 13) || (day == 11 && dayOfWeek == 4))) {
                dayData |= TAANIT | ESTER | TORA | SLICHOT;
                kria[offset] = "taanit";
            }

            if (month == 11 && day == 14 && dayOfWeek == 5) {
                dayData |= MEGILAT_ESTER;
            }

            if (month == 11 && day == 16 && dayOfWeek == 0 && (purimDay & TU) == 0) {
                dayData |= PURIM_MESHULASH_TACHANUN_MESSAGE;
            }
        }

        if (month == 0 && day >= 15 && day <= 21) {
            dayData |= PESACH | TORA;
            kria[offset] = "pesach" + (day - 15);
            if (day == 18 && dayOfWeek == 0) {
                kria[offset] = "pesach2";
            }
            if (day == 19 && dayOfWeek == 1) {
                kria[offset] = "pesach3";
            }
        }

        if (month == 1) {
            if ((day == 4 && dayOfWeek == 2) ||
                    (day == 5 && dayOfWeek == 1) ||
                    ((day == 3 || day == 2) && dayOfWeek == 3)) {
                dayData |= ZIKARON;
            }

            if ((day == 5 && dayOfWeek == 3) ||
                    (day == 6 && dayOfWeek == 2) ||
                    ((day == 4 || day == 3) && dayOfWeek == 4)) {
                dayData |= ATZMAUT | SHABBAT;
            }

            if (day == 28) {
                dayData |= YERUSHALAYIM | SHABBAT;
            }
        }

        if (month == 6 && day >= 1 && day <= 10) {
            dayData |= AYT | SLICHOT;
            if (day == 9) {
                dayData |= KIPUR;
            }
        }

        if (month == 6 && day == 11) {
            dayData |= FIRE | TISHREI_11;
        }

        if (month == 4 &&
                (day == 9 || (day == 10 && dayOfWeek == 0))) {
            dayData |= TISHAA_BEAV | TAANIT | TORA;
            kria[offset] = "tishaa_beav";
        }

        if (month == 4 && (day == 10 || day == 11) && dayOfWeek == 1) {
            dayData |= HAVDALA;
        }

        if (dayOfWeek == 0) {
            dayData |= SUN | FIRE | CHONANTANU;
            if (!(//
                    (month == 0 && (day >= 10 && day <= 21))//לפני פסח
                            || (month == 2 && day <= 6)//לפני שבועות
                            || (month == 5 && day >= 25)//לפני ראש השנה
                            || (month == 6 && ((day >= 5 && day < 10) || (day >= 10 && day <= 22 && day != 16)))//לפני חגי תשרי
                            || ((dayData & TISHAA_BEAV) == TISHAA_BEAV) //תשעה באב
                            || ((dayData & PURIM) == PURIM) //פורים
            )) {
                dayData |= KADOSH;
            }
            if ((dayData & TISHAA_BEAV) == 0) {
                dayData |= HAVDALA;
            } else {
                dayData |= TISHAA_BEAV_FIRE;
            }
            if (((dayData & PURIM) == 0) && ((dayData & TISHAA_BEAV) == 0)) {
                dayData |= EM_KADOSH;
            }
        }

        if (month == 1 || (month == 0 && day >= 16) ||
                (month == 2) && day <= 5) {
            dayData |= OMER;
        }

        if ((month == 6 && (day == 3 || (day == 4 && dayOfWeek == 0))) ||
                (month == 9 && day == 10) ||
                (month == 3 && (day == 17 || day == 18 &&
                        dayOfWeek == 0))) {
            dayData |= TAANIT | TORA | SLICHOT;
            if (month == 3) {
                dayData |= TAMMUZ_17;
            } else if (month == 6) {
                dayData |= GEDALYA;
            } else if (month == 9) {
                dayData |= TEVET_10;
            }
            kria[offset] = "taanit";
        }

        if (month == 8 && day >= 25) {
            dayData |= CHANUKA | TORA;
            kria[offset] = "chanuka" + (day - 24);
            if (day == 30) {
                kria[offset] = "rhTevet6";
            }
        }

        if (month == 9) {
            DateData DD = new DateData(30, 8, year);
            DateHolder DH = new DateHolder();
            DH.acceptHebrewDate(DD, true);
            if (DH.dateHebrew.day == 30) {
                if (day <= 2) {
                    dayData |= CHANUKA | TORA;
                    kria[offset] = "chanuka" + (day + 6);
                    if (day == 1) {
                        kria[offset] = "rhTevet7";
                    }
                }
            } else {
                if (day <= 3) {
                    dayData |= CHANUKA | TORA;
                    kria[offset] = "chanuka" + (day + 5);
                    if (day == 1) {
                        kria[offset] = "rhTevet6";
                    }
                }
            }
        }

        if (month == 5 || (month == 6 && day <= 21)) {
            dayData |= LEDAVID;
        }

        if (!((day == 1 || day == 30)// ראש חודש
                ||
                (month == 0)// ניסן
                ||
                (month == 1 && (day == 5 || day == 18 || day == 14))// ה' באייר,
                // ל"ג
                // בעומר,
                // פסח שני
                ||
                ((dayData & ATZMAUT) == ATZMAUT) // יום העצמאות
                ||
                ((dayData & YERUSHALAYIM) == YERUSHALAYIM) // יום שחרור ירושלים
                ||
                (month == 2 && day <= 12)// א-יב סיון
                ||
                (month == 4 && (day == 9 ||
                        (day == 10 && dayOfWeek == 0) || day == 15))// ט וטו באב
                ||
                (month == 5 && day == 29)// ערב ר"ה
                ||
                (month == 6 && day >= 9)// ערב יוה"כ עד חשוון
                ||
                ((dayData & CHANUKA) == CHANUKA)// חנוכה
                ||
                (month == 10 && day == 15)// טו בשבט
                ||
                (month == 11 && (day == 14 || day == 15))// פורים
                || (month == 12 && (day == 14 || day == 15))// פורים בשנה מעוברת
                || (!leap && month == 11 && day == 16 && dayOfWeek == 0 && (purimDay & TU) != 0)// פורים משולש
                || (leap && month == 12 && day == 16 && dayOfWeek == 0 && (purimDay & TU) != 0)// פורים משולש בשנה מעוברת
        )) {
            dayData |= SHACHARIT_TACHANUN;
        }

        if (((dayData & SHACHARIT_TACHANUN) == SHACHARIT_TACHANUN) //
            && ((dayData & AYT) == 0) //
            && ((dayData & OMER) == 0) //
            && (chul || (!chul && (year % 7 != 0)))) {
            dayData |= TIKUN_RACHEL;
        }

        if (!((day == 1 || day == 30 || day == 29)//
                ||
                (month == 0)//
                ||
                (month == 1 && (day == 18 || day == 17 ||
                        day == 27 || day == 14))//
                ||
                ((dayData & ATZMAUT) == ATZMAUT)//
                ||
                ((dayData & YERUSHALAYIM) == YERUSHALAYIM)//
                ||
                ((dayData & ZIKARON) == ZIKARON)//
                ||
                (month == 2 && day <= 12)//
                ||
                (month == 4 && (day == 9 ||
                        (day == 10 && dayOfWeek == 0) ||
                        day == 8 || day == 15 || day == 14))//
                ||
                (month == 6 && day >= 9)//
                ||
                ((dayData & CHANUKA) == CHANUKA)//
                ||
                (month == 8 && day == 24)// ערב חנוכה
                ||
                (month == 10 && (day == 15 || day == 14))//
                || (month == 11 && (day == 14 || day == 13 || day == 15))//
                || (month == 12 && (day == 14 || day == 13 || day == 15))//
                || (!leap && month == 11 && day == 16 && dayOfWeek == 0 && (purimDay & TU) != 0)// פורים משולש
                || (leap && month == 12 && day == 16 && dayOfWeek == 0 && (purimDay & TU) != 0)// פורים משולש בשנה מעוברת
                || dayOfWeek == 5)) {
            dayData |= MINCHA_TACHANUN;
        }

        if (((dayData & RH) == RH && (dayData & CHANUKA) != CHANUKA)//
                ||
                ((dayData & PESACH) == PESACH)) {
            dayData |= HALLEL;
        }

        if (((dayData & CHANUKA) == CHANUKA)//
                ||
                ((dayData & ATZMAUT) == ATZMAUT)//
                ||
                ((dayData & SUCOT) == SUCOT)//
                ||
                ((dayData & YERUSHALAYIM) == YERUSHALAYIM)) {
            dayData |= FULL_HALLEL;
            dayData |= HALLEL;
        }

        if (((dayData & SUCOT) == SUCOT)//
                ||
                ((dayData & RH) == RH) ||
                ((dayData & PESACH) == PESACH)) {
            dayData |= MUSAF;
        }

        if ((dayData & TAANIT) == TAANIT &&
                !(month == 6)) {
            dayData |= NO_GEDALYA;
        }

        if (!(//
                ((dayData & CHANUKA) == CHANUKA)//
                        ||
                        (month == 4 && (day == 9 ||
                                (day == 10 && dayOfWeek == 0) || day == 15))//
                        ||
                        ((dayData & MUSAF) == MUSAF)//
                        ||
                        (month == 1 && day == 18)//
                        ||
                        ((dayData & ATZMAUT) == ATZMAUT)//
                        ||
                        ((dayData & YERUSHALAYIM) == YERUSHALAYIM)//
                        ||
                        (month == 11 && (day == 14 || day == 15))//
                        ||
                        (month == 12 && (day == 14 || day == 15))//
                        ||
                        (month == 10 && day == 15)//
                        ||
                        (month == 5 && day == 29)//
                        ||
                        (month == 6 && (day == 9 || day == 14 ||
                                day == 21 || day == 23 || (chul && day == 24)))//
                        ||
                        (month == 2 && (day == 5 || day == 7 || (chul && day == 8)))//
                        || (month == 0 && (day == 14 || day == 22 || (chul && day == 23)))//
                        || (!leap && month == 11 && day == 16 && dayOfWeek == 0 && (purimDay & TU) != 0)// פורים משולש
                        || (leap && month == 12 && day == 16 && dayOfWeek == 0 && (purimDay & TU) != 0)// פורים משולש בשנה מעוברת
        )) {
            dayData |= LAMNATZEACH;
        }

        if (!(//
                (month == 0 && (day >= 14 && day <= 21))//
                        || (month == 6 && day == 9))) {
            dayData |= TODA;
        }

        if (month == 3 && day >= 17 || month == 4 &&
                day <= 9) {
            dayData |= THREE_WEEKS;
        }

        return dayData;
    }

    public long getDayData() {
        return getDayData(0);
    }

    public int getWeekDay() {
        EventData.resetDisplaySettings();

        DateHolder dh = new DateHolder();
        dh.acceptCurrentDate();
        if (sunset) {
            dh.incrementDay(1);
        }

        return HebCalendar.getDayOfWeek(dh.dateAbsolute);
    }

    public int getOmerDay(int forceDay) {
        EventData.resetDisplaySettings();

        DateHolder dh = new DateHolder();
        dh.acceptCurrentDate();
        if ((sunset && forceDay == 0) || forceDay == 2) {
            dh.incrementDay(1);
        }

        return HebCalendar.getOmerDay(dh);
    }

    public int getSucotDay() {
        EventData.resetDisplaySettings();

        DateHolder dh = new DateHolder();
        dh.acceptCurrentDate();
        if (sunset) {
            dh.incrementDay(1);
        }
        DateData dd = dh.dateHebrew;

        if (dd.month == 6 && dd.day >= 15 &&
                dd.day <= 21) {
            return dd.day - 14;
        }
        return 0;
    }

    public int getChanukaDay() {
        EventData.resetDisplaySettings();

        DateHolder dh = new DateHolder();
        dh.acceptCurrentDate();
        if (sunset) {
            dh.incrementDay(1);
        }
        DateData dd = dh.dateHebrew;

        if (dd.month == 8 && dd.day >= 24) {
            return dd.day - 24;
        } else if (dd.month == 9) {
            DateData DD = new DateData(30, 8, dd.year);
            DateHolder DH = new DateHolder();
            DH.acceptHebrewDate(DD, true);
            if (DH.dateHebrew.day == 30) {
                if (dd.day <= 2) {
                    return 6 + dd.day;
                }
            } else {
                if (dd.day <= 3) {
                    return 5 + dd.day;
                }
            }
        }
        return -1;
    }

    public String readFile(String fname, String when, int forceDay) {
        String str = "";
        long nowDayData = getNowDayData(forceDay);

        if (when.toUpperCase().equals("SUN") &&
                (nowDayData & SUN) == SUN) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOSUN") &&
                (nowDayData & SUN) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("MON") &&
                (nowDayData & MON) == MON) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("TUE") &&
                (nowDayData & TUE) == TUE) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("WED") &&
                (nowDayData & WED) == WED) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("THU") &&
                (nowDayData & THU) == THU) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("FRI") &&
                (nowDayData & FRI) == FRI) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOFRI") &&
                (nowDayData & FRI) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("EM_KADOSH") &&
                (nowDayData & EM_KADOSH) == EM_KADOSH) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("KADOSH") &&
                (nowDayData & KADOSH) == KADOSH) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOKADOSH") &&
                (nowDayData & KADOSH) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("CHONANTANU") &&
                (nowDayData & CHONANTANU) == CHONANTANU) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOCHONANTANU") &&
                (nowDayData & CHONANTANU) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("HAVDALA") &&
                (nowDayData & HAVDALA) == HAVDALA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("FIRE") &&
                (nowDayData & FIRE) == FIRE) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("TISHAABEAVFIRE") &&
                (nowDayData & TISHAA_BEAV_FIRE) == TISHAA_BEAV_FIRE) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("MONTHU") &&
                (nowDayData & MON_THU) == MON_THU) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOMONTHU") &&
                (nowDayData & MON_THU) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("MONTHUTACHANUN") &&
                (nowDayData & MON_THU) == MON_THU &&
                (nowDayData & SHACHARIT_TACHANUN) == SHACHARIT_TACHANUN) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("RH") &&
                (nowDayData & RH) == RH) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NORH") &&
                (nowDayData & RH) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("KAPARATPASHA") &&
                (nowDayData & KAPARAT_PASHA) == KAPARAT_PASHA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOKAPARATPASHA") &&
                (nowDayData & KAPARAT_PASHA) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("LEAP") == 0 &&
                (nowDayData & LEAP) == LEAP) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("NOLEAP") == 0 &&
                (nowDayData & LEAP) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("TFILIN") == 0 &&
                ((nowDayData & TISHAA_BEAV) == 0 &&
                        (nowDayData & SUCOT) == 0 && (nowDayData & PESACH) == 0)) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("NOTFILIN") == 0 &&
                ((nowDayData & TISHAA_BEAV) == TISHAA_BEAV ||
                        (nowDayData & SUCOT) == SUCOT || (nowDayData & PESACH) == PESACH)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SUCOT") &&
                (nowDayData & SUCOT) == SUCOT) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("LULAV_SHEHECHEYANU") &&
                (nowDayData & SUCOT) == SUCOT &&
                getSucotDay() == 2 &&
                (nowDayData & SUN) == SUN) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("PESACH") &&
                (nowDayData & PESACH) == PESACH) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("CHANUKA") &&
                (nowDayData & CHANUKA) == CHANUKA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("PURIM") &&
                (nowDayData & PURIM) == PURIM) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("MEGILATESTER") == 0 && (nowDayData & MEGILAT_ESTER) == MEGILAT_ESTER) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("PURIM_MESHULASH_TACHANUN_MESSAGE") == 0 && (nowDayData & PURIM_MESHULASH_TACHANUN_MESSAGE) == PURIM_MESHULASH_TACHANUN_MESSAGE) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("AYT") &&
                (nowDayData & AYT) == AYT) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOAYT") &&
                (nowDayData & AYT) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SUMMERTAL") &&
                (nowDayData & SUMMER_TAL) == SUMMER_TAL) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("WINTERTAL") &&
                (nowDayData & WINTER_TAL) == WINTER_TAL) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SUMMERBRACHA") &&
                (nowDayData & SUMMER_BRACHA) == SUMMER_BRACHA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("WINTERBRACHA") &&
                (nowDayData & WINTER_BRACHA) == WINTER_BRACHA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("TISHAABEAV") &&
                (nowDayData & TISHAA_BEAV) == TISHAA_BEAV) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOTISHAABEAV") &&
                (nowDayData & TISHAA_BEAV) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("TAANIT") &&
                (nowDayData & TAANIT) == TAANIT) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOTAANIT") &&
                (nowDayData & TAANIT) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOGEDALYA") &&
                (nowDayData & NO_GEDALYA) == NO_GEDALYA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("HOSHANARABA") &&
                (nowDayData & HOSHANA_RABA) == HOSHANA_RABA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOHOSHANARABA") &&
                (nowDayData & HOSHANA_RABA) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("ATZMAUT") &&
                (nowDayData & ATZMAUT) == ATZMAUT) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOATZMAUT") &&
                (nowDayData & ATZMAUT) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("YERUSHALAYIM") &&
                (nowDayData & YERUSHALAYIM) == YERUSHALAYIM) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOYERUSHALAYIM") &&
                (nowDayData & YERUSHALAYIM) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("ZIKARON") &&
                (nowDayData & ZIKARON) == ZIKARON) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOZIKARON") &&
                (nowDayData & ZIKARON) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SHABBAT") &&
                (nowDayData & SHABBAT) == SHABBAT) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOSHABBAT") &&
                (nowDayData & SHABBAT) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("OMER") &&
                (nowDayData & OMER) == OMER) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("CHANUKA1") &&
                (getChanukaDay() == 1 || getChanukaDay() == 0)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("LEDAVID") &&
                (nowDayData & LEDAVID) == LEDAVID) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SHACHARITTACHANUN") &&
                (nowDayData & SHACHARIT_TACHANUN) == SHACHARIT_TACHANUN) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOSHACHARITTACHANUN") &&
                ((nowDayData & SHACHARIT_TACHANUN) == 0)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("MINCHATACHANUN") &&
                (nowDayData & MINCHA_TACHANUN) == MINCHA_TACHANUN) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOMINCHATACHANUN") &&
                ((nowDayData & MINCHA_TACHANUN) == 0)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("HALLEL") &&
                (nowDayData & HALLEL) == HALLEL) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("FULLHALLEL") &&
                (nowDayData & FULL_HALLEL) == FULL_HALLEL) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("VAANENU") &&
                (vaanenu && (nowDayData & WINTER_BRACHA) == WINTER_BRACHA)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("DOCTOR") &&
                doctor) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SHATZ") &&
                shatz) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOSHATZ") &&
                !shatz) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("MAGDIL") &&
                (nowDayData & MIGDOL) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("MIGDOL") &&
                (nowDayData & MIGDOL) == MIGDOL) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("LAMNATZEACH") &&
                (nowDayData & LAMNATZEACH) == LAMNATZEACH) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOLAMNATZEACH") &&
                (nowDayData & LAMNATZEACH) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("LERECHAPAYIM") &&
                (nowDayData & LAMNATZEACH) == LAMNATZEACH && (nowDayData & MON_THU) == MON_THU) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SHIRSHELYOMATEND") &&
                ((nowDayData & TISHAA_BEAV) == 0 && (nowDayData & MUSAF) == 0)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SHIROPEND") &&
                ((nowDayData & MUSAF) == 0 &&
                        (nowDayData & CHANUKA) == 0 && (nowDayData & PURIM) == 0)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SHIROPENND") &&
                ((nowDayData & MUSAF) == MUSAF ||
                        (nowDayData & CHANUKA) == CHANUKA || (nowDayData & PURIM) == PURIM)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("TORA") &&
                (nowDayData & TORA) == TORA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOTORA") &&
                (nowDayData & TORA) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("TODA") &&
                (nowDayData & TODA) == TODA) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOTODA") &&
                (nowDayData & TODA) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOMUSAF") &&
                (nowDayData & MUSAF) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("MUSAF") &&
                (nowDayData & MUSAF) == MUSAF) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("SLICHOT") &&
                (nowDayData & SLICHOT) == SLICHOT) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOSLICHOT") &&
                (nowDayData & SLICHOT) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("17TAMMUZ") == 0 &&
                (nowDayData & TAMMUZ_17) == TAMMUZ_17) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("GEDALYA") == 0 &&
                (nowDayData & GEDALYA) == GEDALYA) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("10TEVET") == 0 &&
                (nowDayData & TEVET_10) == TEVET_10) {
            str = readFile(fname);
        } else if (when.toUpperCase().compareTo("ESTER") == 0 &&
                (nowDayData & ESTER) == ESTER) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("AVEL") &&
                avel && (nowDayData & PESACH) == 0 && (nowDayData & SUCOT) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NOAVEL") &&
                (!avel || (nowDayData & PESACH) == PESACH || (nowDayData & SUCOT) == SUCOT)) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("CHUL") &&
                chul) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("ISRAEL") &&
                !chul) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("KIPUR") &&
                (nowDayData & KIPUR) == KIPUR) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("11TISHREI") &&
                (nowDayData & TISHREI_11) == TISHREI_11) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("AVINU_MALKENU_KIPUR") &&
                (nowDayData & KIPUR) == KIPUR &&
                (nowDayData & FRI) == FRI) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("RACHEL") &&
                (nowDayData & TIKUN_RACHEL) == TIKUN_RACHEL) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("NORACHEL") &&
                (nowDayData & TIKUN_RACHEL) == 0) {
            str = readFile(fname);
        } else if (when.toUpperCase().equals("THREEWEEKS") &&
                (nowDayData & THREE_WEEKS) == THREE_WEEKS) {
            str = readFile(fname);
        }

        return str;
    }

    public void setTickerAndSun() {
        boolean fri = false;
        boolean thu = false;
        boolean wed = false;
        boolean yot = false;
        boolean doubleYot = false;
        boolean tripleYot = false;
        boolean motzashYot = false;
        boolean endOnWeek = false;
        long dayData = this.dayData;

        EventData.resetDisplaySettings();
        DateHolder dh = new DateHolder();
        dh.acceptCurrentDate();
        LocationHolder lh = new LocationHolder();
        lh.acceptLatitude(city.latitude);
        lh.acceptLongitude(city.longitude);
        lh.acceptElevation(city.elevation);
        int[] tmeZone = new int[3];
        double off = city.gmtOffset;
        int direction = 0;
        if (off < 0) {
            off = -off;
            direction = 1;
        }

        tmeZone[0] = (int) off;
        tmeZone[1] = (int) (60 * (off - (int) off));
        tmeZone[2] = (direction);
        if (summerTime) {
            lh.dstMode = LocationHolder.DST_MODE_ON;
        } else {
            lh.dstMode = LocationHolder.DST_MODE_OFF;
        }

        lh.acceptTimeZone(tmeZone);
        int setElev = lh.getSunSetTime(dh);
        int hourOfSS = toHour(setElev);
        int minuteOfSS = toMinute(setElev);
        int riseElev = lh.getSunRiseTime(dh);
        int hourOfSR = toHour(riseElev);
        int minuteOfSR = toMinute(riseElev);
        lh.acceptElevation(0);
        int set = lh.getSunSetTime(dh);
        int rise = lh.getSunRiseTime(dh);
        Calendar myCalendar = Calendar.getInstance();
        int hourNow = myCalendar.get(Calendar.HOUR_OF_DAY);
        int minuteNow = myCalendar.get(Calendar.MINUTE);

        if (HebCalendar.getDayOfWeek(dh.dateAbsolute) == 5) {
            fri = true;
        } else if (HebCalendar.getDayOfWeek(dh.dateAbsolute) == 4) {
            thu = true;
        } else if (HebCalendar.getDayOfWeek(dh.dateAbsolute) == 3) {
            wed = true;
        }

        zmanimText = "<font color=\"white\">" +
                "<h1>זמני היום ל" +
                city +
                "</h1><h3>שים לב!</h3><h4>אסור להשתמש בזמנים אלו הלכה למעשה וצריך לקחת בחשבון סטייה אפשרית של כמה דקות.</h4><h4>הזמנים מוצגים על פי שעון " +
                (summerTime ? "קיץ" : "חורף") +
                ". אם עכשיו במדינתך נהוג כיום שעון " +
                (summerTime ? "חורף" : "קיץ") +
                " אנא היכנס להגדרות ובחר באפשרות זו.</h4><h5>אם הזמנים מוצגים הפוך, היכנס למסך ההגדרות וסמן את התיבה \"הפוך טקסט\".</h5>";
        if (hourNow > hourOfSS ||
                (hourNow == hourOfSS && minuteNow >= minuteOfSS)) {
            sunset = true;
            dh.incrementDay(1);
            dayData = nextDayData;
        } else {
            sunset = false;
        }

        if (hourNow > hourOfSR ||
                (hourNow == hourOfSR && minuteNow >= minuteOfSR)) {
            sunrise = true;
        } else {
            sunset = false;
        }

        float tempHour = temporaryHour(rise, set);
        String[] hebLetters =
                {"א'", "ב'", "ג'", "ד'", "ה'", "ו'", "ז'", "ח'", "ט'", "י'", "י\"א", "י\"ב", "י\"ג", "י\"ד", "ט\"ו", "ט\"ז", "י\"ז", "י\"ח", "י\"ט", "כ'", "כ\"א", "כ\"ב", "כ\"ג", "כ\"ד", "כ\"ה", "כ\"ו", "כ\"ז", "כ\"ח", "כ\"ט", "ל'"};
        String[] hebMonths = res.getStringArray(R.array.hebmonths);
        DateData dd = dh.dateHebrew;
        int hday = dd.day;
        int hmonth = dd.month;
        int hyear = dd.year;
        boolean leap = HebCalendar.isLeapYear(hyear);
        String strDay = hebLetters[hday - 1];
        String strMonth =
                hmonth == 12 ? "אדר ב'" : (leap &&
                        hmonth == 11 ? "אדר א'" : hebMonths[hmonth]);
        if (sunset) {
            dh.incrementDay(-1);
            hday = dd.day;
            hmonth = dd.month;
            hyear = dd.year;
        }

        if (city.isInIsrael) {
            chul = false;
            lh.holidayStyle = LocationHolder.HSTYLE_ISRAEL;
        } else {
            chul = true;
            lh.holidayStyle =
                    LocationHolder.HSTYLE_DIASPORA;
        }

        zmanimText += "<h4>" + (sunset ? "אור ל" : "") +
                strDay + " ב" +
                strMonth + "</h4>";

        if ((dayData & OMER) == OMER) {
            zmanimText += "<h4>" + getOmerDay(0) +
                    " ימים לעומר</h4>";
        }

        if ((dayData & THREE_WEEKS) == THREE_WEEKS) {
            zmanimText +=
                    "<h4>שלושת השבועות (בין המצרים)</h4>";
        }

        if ((dayData & AYT) == AYT) {
            zmanimText += "<h4>עשרת ימי תשובה</h4>";
        }

        if ((dayData & RH) == RH ||
                (dayData & SUCOT) == SUCOT ||
                (dayData & PESACH) == PESACH) {
            if ((dayData & RH) == RH) {
                zmanimText += "<h4>ראש חודש</h4>";
            } else if ((dayData & SUCOT) == SUCOT) {
                zmanimText += "<h4>סוכות</h4>";
                if ((dayData & HOSHANA_RABA) == HOSHANA_RABA) {
                    zmanimText += "<h4>הושענה רבה</h4>";
                }
            } else {
                zmanimText += "<h4>פסח</h4>";
            }
            zmanimText += "<h4>יעלה ויבא</h4>";
        }

        if ((dayData & CHANUKA) == CHANUKA ||
                (dayData & PURIM) == PURIM) {
            if ((dayData & CHANUKA) == CHANUKA) {
                zmanimText += "<h4>חנוכה נר " +
                        getChanukaDay() + "</h4>";
                if (getChanukaDay() == 8) {
                    zmanimText += "<h4>זאת חנוכת</h4>";
                }
            } else {
                zmanimText += "<h4>פורים</h4>";
            }
            zmanimText += "<h4>על הניסים</h4>";
        }
        if (hmonth == 0 &&
                ((hday == 27 && ((dayData & TUE) == TUE || (dayData & THU) == THU)) ||
                        (hday == 28 && (dayData & MON) == MON) || (hday == 26 && (dayData & THU) == THU))) {
            zmanimText += "<h4>יום הזכרון לשואה ולגבורה</h4>";
        }

        if ((dayData & ZIKARON) == ZIKARON) {
            zmanimText += "<h4>יום הזכרון לחללי מערכות ישראל ולנפגעי פעולות האיבה</h4>";
        }

        if ((dayData & ATZMAUT) == ATZMAUT) {
            zmanimText += "<h4>יום העצמאות</h4>";
        }

        if ((dayData & YERUSHALAYIM) == YERUSHALAYIM) {
            zmanimText += "<h4>יום שחרור ירושלים</h4>";
        }

        if ((dayData & TAANIT) == TAANIT) {
            if ((dayData & TISHAA_BEAV) == TISHAA_BEAV) {
                zmanimText += "<h4>תשעה באב</h4>";
            } else if (!sunset) {
                zmanimText += "<h4>תענית</h4>";
            }
        }

        if ((dayData & SHACHARIT_TACHANUN) == 0) {
            zmanimText += "<h4>א\"א תחנון</h4>";
        }

        if (!sunset) {
            if ((dayData & SHACHARIT_TACHANUN) == SHACHARIT_TACHANUN
                    &&
                    (dayData & MINCHA_TACHANUN) == 0) {
                zmanimText += "<h4>א\"א תחנון במנחה</h4>";
            }
        }

        if ((dayData & WINTER_TAL) == WINTER_TAL) {
            zmanimText += "<h4>משיב הרוח ומוריד הגשם</h4>";
        }

        if ((dayData & SUMMER_TAL) == SUMMER_TAL) {
            zmanimText += "<h4>מוריד הטל</h4>";
        }

        if ((dayData & WINTER_BRACHA) == WINTER_BRACHA) {
            zmanimText += "<h4>ותן טל ומטר</h4>";
        }

        if ((dayData & SUMMER_BRACHA) == SUMMER_BRACHA) {
            zmanimText += "<h4>ותן ברכה</h4>";
        }

        DateHolder startRound = new DateHolder();
        startRound.acceptHebrewDate(new DateData(21, 11, 5765), true);
        Shas.setLengthOfShas();
        zmanimText += "<h4>דף יומי: " +
                Shas.getDaf(dh.dateAbsolute -
                        startRound.dateAbsolute) +
                "</h4>";

        if (!sunset) {
            // ימים טובים - המצבים האפשריים:
            //
            // ראש השנה שחל בחמישי - ערב יו"ט - 3 ימים רצופים - מוצ"ש
            // ראש השנה שחל בשבת - ערב שבת ויו"ט - 2 ימים רצופים - מוציו"ט
            // ראש השנה שחל בכל יום אחר - ערב יו"ט - 2 ימים רצופים - מוציו"ט
            // יום כיפור שחל בשבת - ערב שבת ויו"ט - מוצשויו"ט
            // יום כיפור שחל בכל יום אחר - ערב יו"ט - מוציו"ט
            //
            // בארץ ישראל
            // יום טוב שחל בשני-חמישי - ערב יו"ט - מוציו"ט
            // יום טוב שחל בראשון - הודעה כבר ביום שישי - ערב שבת (+פרשה אם זה
            // לא חוה"מ) - 2 ימים רצופים - מוציו"ט
            // יום טוב שחל בשישי - ערב יו"ט - 2 ימים רצופים - מוצ"ש
            // יום טוב שחל בשבת - ערב שבת ויו"ט - מוצשויו"ט
            //
            // בחו"ל
            // יום טוב שחל שני-רביעי - ערב יו"ט - מוציו"ט
            // יום טוב שחל בראשון - הודעה כבר ביום שישי - ערב שבת (+פרשה אם לא
            // חול המועד) - 3 ימים רצופים - מוציו"ט
            // יום טוב שחל בחמישי - ערב יו"ט - 3 ימים רצופים - מוצ"ש
            // יום טוב שחל בשישי - ערב יו"ט - 2 ימים רצופים - מוצשיו"ט
            // יום טוב שחל בשבת - ערב שבת ויו"ט - 2 ימים רצופים - מוציו"ט
            if (hday == 29 && hmonth == 5) {
                if (wed) {
                    tripleYot = true;
                } else {
                    doubleYot = true;
                    if (thu) {
                        motzashYot = true;
                    } else {
                        endOnWeek = true;
                    }

                }
            } else if ((hmonth == 6 && (hday == 9 ||
                    hday == 14 || hday == 21)) ||
                    (hmonth == 0 && (hday == 14 || hday == 20)) ||
                    (hmonth == 2 && hday == 5)) {
                if (!chul || (hmonth == 6 && hday == 9)) {
                    if (thu) {
                        doubleYot = true;
                    } else {
                        yot = true;
                        if (fri) {
                            motzashYot = true;
                        } else {
                            endOnWeek = true;
                        }
                    }
                } else {
                    if (wed) {
                        tripleYot = true;
                    } else {
                        doubleYot = true;
                        if (thu) {
                            motzashYot = true;
                        } else {
                            endOnWeek = true;
                        }
                    }
                }
            } else if (fri &&
                    ((hmonth == 0 && (hday == 13)) || (hmonth == 2 && hday == 4))) {
                if (!chul) {
                    doubleYot = true;
                    endOnWeek = true;
                } else {
                    tripleYot = true;
                    endOnWeek = true;
                }
            }
        }

        if (fri || yot || doubleYot || tripleYot) {
            String[] sedrot = Sedrot.getSedrotNames(dh, lh);
            if (sedrot != null && fri) {
                String shabbat = "<h4>ערב שבת " +
                        sedrot[0] +
                        (sedrot.length == 2 ? "-" +
                                sedrot[1] : "");
                zmanimText += shabbat + "</h4>";
            } else if (fri) {
                if (yot) {
                    zmanimText += "<h4>ערב שבת ויו\"ט</h4>";
                } else {
                    zmanimText += "<h4>ערב שבת חוה\"מ</h4>";
                }
            } else {
                zmanimText += "<h4>ערב יו\"ט</h4>";
            }

            if (doubleYot) {
                zmanimText += "<h4>2 ימים רצופים</h4>";
            } else if (tripleYot) {
                zmanimText += "<h4>3 ימים רצופים</h4>";
            }

            zmanimText += "<h4>הדלקת נרות: " +
                    toTime(setElev - city.shabbatTime *
                            60) +
                    "</h4>";
            DateHolder dh2 = new DateHolder();
            dh2.acceptCurrentDate();
            dh2.incrementDay(doubleYot ? 2 : (tripleYot ? 3 : 1));
            lh.acceptElevation(city.elevation);
            int set2 = lh.getSunSetTime(dh2);
            lh.acceptElevation(0);
            zmanimText += "<h4>" +
                    (endOnWeek ? "מוציו\"ט" : (motzashYot ? "מוצשויו\"ט" : "מוצ\"ש")) +
                    ": " +
                    toTime(lh.timeUTCtoLocal(SunRiseSet.recalcZenithAngleUTC(354600))) +
                    "</h4>";
            zmanimText += "<h4>" +
                    (endOnWeek ? "מוציו\"ט" : (motzashYot ? "מוצשויו\"ט" : "מוצ\"ש")) +
                    " (רבינו תם): " +
                    toTime(set2 + 72 * 60) + "</h4>";
            lh.getSunSetTime(dh);
        }

        int alot, tzet;
        alot = lh.timeUTCtoLocal(SunRiseSet.recalcZenithAngleUTC(-395280));
        tzet = lh.timeUTCtoLocal(SunRiseSet.recalcZenithAngleUTC(345420));
        float tempHourMGA = temporaryHour(alot, lh.timeUTCtoLocal(SunRiseSet.recalcZenithAngleUTC(395280)));

        zmanimText += "<h4>עלות השחר: " + toTime(alot) +
                "</h4>";
        zmanimText += "<h4>משיכיר: " +
                toTime(lh.timeUTCtoLocal(SunRiseSet.recalcZenithAngleUTC(-363600))) +
                "</h4>";
        zmanimText += "<h4>הנץ החמה: " +
                toTime(riseElev) +
                "</h4>";
        zmanimText += "<h4>סזק\"ש (מג\"א): " +
                toTime(alot + (int) (3 * tempHourMGA)) +
                "</h4>";
        zmanimText += "<h4>סזק\"ש (גר\"א): " +
                toTime(rise + (int) (3 * tempHour)) +
                "</h4>";
        zmanimText += "<h4>סזת\"פ (מג\"א): " +
                toTime(alot + (int) (4 * tempHourMGA)) +
                "</h4>";
        zmanimText += "<h4>סזת\"פ (גר\"א): " +
                toTime(rise + (int) (4 * tempHour)) +
                "</h4>";
        zmanimText += "<h4>חצות היום: " +
                toTime(rise + (int) (6 * tempHour)) +
                "</h4>";
        zmanimText += "<h4>מנחה גדולה: " +
                toTime(rise +
                        (tempHour < 3600 ? (int) (6 * tempHour) + 1800 : (int) (6.5 * tempHour))) +
                "</h4>";
        zmanimText += "<h4>מנחה קטנה: " +
                toTime(rise + (int) (9.5 * tempHour)) +
                "</h4>";
        zmanimText += "<h4>פלג המנחה: " +
                toTime(rise + (int) (10.75 * tempHour)) +
                "</h4>";
        zmanimText += "<h4>שקיעה: " + toTime(setElev) +
                "</h4>";
        zmanimText += "<h4>צאה\"כ: " + toTime(tzet) +
                "</h4></font>";
        this.dayData = getDayData();
        this.nextDayData = getDayData(1);
    }

    public void setDayData() {
        this.dayData = getDayData();
        this.nextDayData = getDayData(1);
        setTickerAndSun();
    }

    public String toTwoDigits(int num) {
        return (num < 10 ? "0" + num : "" + num);
    }

    public float temporaryHour(int rise, int set) {
        if (set < rise) {
            set += 24 * 3600;
        }
        return (float) (set - rise) / 12;
    }

    public int toHour(int num) {
        return num / 3600;
    }

    public int toMinute(int num) {
        return num % 3600 / 60;
    }

    public String toTime(int time) {
        StringBuffer sb;
        String hour, minute;
        sb = new StringBuffer(Integer.toString(toHour(time)));
        if (!reverse) {
            hour = sb.toString();
        } else {
            hour = sb.reverse().toString();
        }
        sb = new StringBuffer(toTwoDigits(toMinute(time)));
        if (!reverse) {
            minute = sb.toString();
        } else {
            minute = sb.reverse().toString();
        }
        if (!reverse) {
            return hour + ":" + minute;
        } else {
            return minute + ":" + hour;
        }
    }

    private Bitmap getImageByRatio(Bitmap bitmapOrg, int ratio) {
        int width = bitmapOrg.getWidth() * ratio;
        int height = bitmapOrg.getHeight() * ratio;
        return Bitmap.createScaledBitmap(bitmapOrg, width, height, false);
    }

    final void drawString(String str, Canvas g, int x, int y, byte curR, byte curG, byte curB) {
        char prevLetter = 0;
        x -= 2;
        char[] chars = str.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == '~') {
                if (censor) {
                    chars[i] = '-';
                } else {
                    continue;
                }
            }
            if (chars[i] == ' ') {
                x -= 4 * ratio;
            } else if (!isNikud(chars[i])) {
                Bitmap img = getDifferentColor(chars[i], curR, curG, curB);
                if (img == null) {
                    Log.d("" + str, "" + str);
                    continue;
                }
                g.drawBitmap(img, x -
                        getWidthOfChar(chars[i]), y, null);
                x -= getWidthOfChar(chars[i]) +
                        (3 - font) * ratio;
                prevLetter = chars[i];
            } else {
                Bitmap img = getDifferentColor(chars[i], curR, curG, curB);
                if (img == null) {
                    Log.d("" + str, "" + str);
                    continue;
                }
                g.drawBitmap(img, x -
                        getWidthOfChar(chars[i]) -
                        getWidthOfNikud(chars[i], prevLetter) +
                        (3 - font) * ratio, y +
                        getHeightOfNikud(chars[i], prevLetter), null);
            }
        }
    }

    private int getWidthOfString(String str) {
        char[] chars = str.toCharArray();
        int ret = 2;
        for (char c : chars) {
            if (c == ' ') {
                ret += 4 * ratio;
            } else {
                if (c == '\r') {
                    continue;
                }
                if (isNikud(c)) {
                    continue;
                }
                ret += getWidthOfChar(c) +
                        (3 - font) * ratio;
            }
        }
        return ret;
    }

    private boolean isNikud(char chr) {
        int index = getIndexOfChar(chr);
        return index >= 37 && index <= 51;
    }

    private int getWidthOfChar(char chr) {
        int index = getIndexOfChar(chr);
        if (index != -1) {
            return widths[getIndexOfChar(chr)];
        }
        if (chr == '~') {
            if (censor) {
                return getWidthOfChar('-');
            } else {
                return 0;
            }
        }
        return 0;
    }

    private int getWidthOfNikud(char nikud, char prevLetter) {
        int ret = 0;
        if (font == 1) {// SYSTEM
            switch (nikud) {
                case 'ְ':
                case 'ֱ':
                case 'ֲ':
                case 'ֳ':
                case 'ִ':
                case 'ֵ':
                case 'ֶ':
                case 'ַ':
                case 'ָ':
                case 'ֻ':
                case 'K':
                    ret = -(getWidthOfChar(prevLetter) / 2 + widths[getIndexOfChar(nikud)] / 2);
                    break;
                case 'ּ':
                    switch (prevLetter) {
                        case 'ש':
                            ret = -8 * ratio;
                            break;
                        case 'ת':
                            ret = -7 * ratio;
                            break;
                        case 'א':
                        case 'ה':
                        case 'ט':
                        case 'מ':
                        case 'ס':
                        case 'פ':
                        case 'ק':
                            ret = -5 * ratio;
                            break;
                        case 'ב':
                        case 'ך':
                        case 'כ':
                        case 'ר':
                            ret = -4 * ratio;
                            break;
                        case 'ד':
                        case 'ל':
                            ret = -3 * ratio;
                            break;
                        case 'ג':
                        case 'נ':
                        case 'צ':
                            ret = -2 * ratio;
                            break;
                        case 'ו':
                        case 'ז':
                        case 'י':
                            ret = -ratio;
                            break;
                        case 'ח':
                        case 'ם':
                        case 'ן':
                        case 'ע':
                        case 'ף':
                        case 'ץ':
                        default:
                            break;
                    }
                    break;
                case 'ׂ':
                    if (prevLetter == 'ש') {
                        ret = -2 * ratio;
                        break;
                    }
                    ret = 0;
                    break;
                case 'ׁ':
                    ret = -10 * ratio;
                    break;
                case 'ֹ':
                    if (prevLetter == 'ו') {
                        ret = -3 * ratio;
                        break;
                    }
                    ret = 0;
                    break;
                default:
                    ret = -(getWidthOfChar(prevLetter) / 2 - widths[getIndexOfChar(nikud)] / 2);
            }
        } else {// TAHOMA
            switch (nikud) {
                case 'ְ':
                case 'ֱ':
                case 'ֲ':
                case 'ֳ':
                case 'ִ':
                case 'ֵ':
                case 'ֶ':
                case 'ַ':
                case 'ָ':
                case 'ֻ':
                case 'K':
                    ret = -(getWidthOfChar(prevLetter) / 2 + widths[getIndexOfChar(nikud)] / 2);
                    break;
                case 'ּ':
                    switch (prevLetter) {
                        case 'ס':
                        case 'פ':
                        case 'ש':
                        case 'ת':
                            ret = -6 * ratio;
                            break;
                        case 'ט':
                        case 'מ':
                            ret = -5 * ratio;
                            break;
                        case 'א':
                        case 'ב':
                        case 'ה':
                        case 'ך':
                        case 'כ':
                        case 'ק':
                        case 'ר':
                            ret = -4 * ratio;
                            break;
                        case 'ל':
                            ret = -3 * ratio;
                            break;
                        case 'ג':
                        case 'ד':
                        case 'נ':
                            ret = -2 * ratio;
                            break;
                        case 'ו':
                        case 'ז':
                        case 'י':
                        case 'צ':
                            ret = -ratio;
                            break;
                        case 'ח':
                        case 'ם':
                        case 'ן':
                        case 'ע':
                        case 'ף':
                        case 'ץ':
                        default:
                            break;
                    }
                    break;
                case 'ׂ':
                    if (prevLetter == 'ש') {
                        ret = -ratio;
                        break;
                    }
                    ret = 0;
                    break;
                case 'ׁ':
                    ret = -10 * ratio;
                    break;
                case 'ֹ':
                    if (prevLetter == 'ו') {
                        ret = -2 * ratio;
                        break;
                    }
                    ret = 0;
                    break;
                default:
                    ret = -(getWidthOfChar(prevLetter) / 2 - widths[getIndexOfChar(nikud)] / 2);
            }
        }
        return ret;
    }

    private int getHeightOfNikud(char nikud, char prevLetter) {
        int ret = 0;
        if (font == 1) {// SYSTEM
            switch (nikud) {
                case 'ְ':
                case 'ֱ':
                case 'ֲ':
                case 'ֳ':
                case 'ִ':
                case 'ֵ':
                case 'ֶ':
                case 'ַ':
                case 'ָ':
                case 'ֻ':
                case 'K':
                    ret = letterHeight - 3 * ratio;
                    break;
                case 'ּ':
                    switch (prevLetter) {
                        case 'ג':
                        case 'י':
                        case 'פ':
                            ret = letterHeight - 13 * ratio;
                            break;
                        case 'ל':
                        case 'ק':
                            ret = letterHeight - 12 * ratio;
                            break;
                        case 'ב':
                        case 'ד':
                        case 'ה':
                        case 'ו':
                        case 'ז':
                        case 'כ':
                        case 'נ':
                        case 'ס':
                        case 'ר':
                        case 'ת':
                        case 'ך':
                            ret = letterHeight - 11 * ratio;
                            break;
                        case 'ט':
                        case 'מ':
                        case 'צ':
                        case 'ש':
                            ret = letterHeight - 10 * ratio;
                            break;
                        case 'א':
                            ret = letterHeight - 7 * ratio;
                            break;
                        case 'ח':
                        case 'ם':
                        case 'ן':
                        case 'ע':
                        case 'ף':
                        case 'ץ':
                        default:
                            break;
                    }
                    break;
                case 'ׂ':
                case 'ׁ':
                    ret = -2 * ratio;
                    break;
                case 'ֹ':
                    if (prevLetter == 'ל') {
                        ret = -4 * ratio;
                        break;
                    }
                    ret = -2 * ratio;
                    break;
                default:
                    ret = letterHeight - 1000;
            }
        } else { // TAHOMA
            switch (nikud) {
                case 'ְ':
                case 'ֱ':
                case 'ֲ':
                case 'ֳ':
                case 'ִ':
                case 'ֵ':
                case 'ֶ':
                case 'ַ':
                case 'ָ':
                case 'ֻ':
                case 'K':
                    ret = letterHeight - 3 * ratio;
                    break;
                case 'ּ':
                    switch (prevLetter) {
                        case 'י':
                            ret = letterHeight - 11 * ratio;
                            break;
                        case 'ב':
                        case 'ג':
                        case 'ד':
                        case 'ה':
                        case 'ו':
                        case 'ז':
                        case 'ט':
                        case 'כ':
                        case 'ל':
                        case 'מ':
                        case 'נ':
                        case 'ס':
                        case 'ק':
                        case 'ר':
                        case 'ת':
                        case 'ך':
                            ret = letterHeight - 10 * ratio;
                            break;
                        case 'פ':
                        case 'צ':
                        case 'ש':
                            ret = letterHeight - 9 * ratio;
                            break;
                        case 'א':
                            ret = letterHeight - 7 * ratio;
                            break;
                        case 'ח':
                        case 'ם':
                        case 'ן':
                        case 'ע':
                        case 'ף':
                        case 'ץ':
                        default:
                            break;
                    }
                    break;
                case 'ׂ':
                case 'ׁ':
                    ret = -ratio;
                    break;
                case 'ֹ':
                    if (prevLetter == 'ל') {
                        ret = -2 * ratio;
                        break;
                    }
                    ret = -ratio;
                    break;
                default:
                    ret = letterHeight - 1000;
            }
        }
        return ret;
    }

    public int getIndexOfChar(char chr) {
        return "אבגדהוזחטיכלמנסעפצקרשתךםןףץ.,:'()[]-\"ְֱֲֳִֵֶַָֹֻּׁׂK?;".indexOf(chr);
    }

    String m_txt;
    int m_length;
    int m_width;
    int m_position;
    int m_start;

    public Vector<String> split(String txt, int width) {
        m_txt = txt;
        m_length = txt.length();
        m_width = width;
        // reseting
        m_position = 0;
        m_start = 0;
        Vector<String> ret = new Vector<String>();
        String s;

        while (hasMoreLines()) {
            s = nextLine().trim();
            ret.addElement(s);
        }
        return ret;
    }

    private boolean hasMoreLines() {
        return (m_position < (m_length - 1));
    }

    private String nextLine() {
        int maxLength = m_txt.length();
        int next = next();
        if (m_start >= maxLength || next > maxLength) {
            return null;
        }

        String s = m_txt.substring(m_start, next);
        m_start = next;
        if ((m_txt.length() - 1 > m_start) &&
                ((m_txt.charAt(m_start) == '\n') || (m_txt.charAt(m_start) == ' '))) {
            m_position++;
            m_start++;
        }
        return s;
    }

    private int next() {
        int i = getNextWord(m_position);
        int lastBreak = -1;
        String line;
        line = m_txt.substring(m_position, i);
        int lineWidth = getWidthOfString(line);
        while (i < m_length && lineWidth <= m_width) {
            if (m_txt.charAt(i) == ' ') {
                lastBreak = i;
            } else if (m_txt.charAt(i) == '\n') {
                lastBreak = i;
                break;
            }

            if (++i < m_length) {
                i = getNextWord(i);
                line = m_txt.substring(m_position, i);
                lineWidth = getWidthOfString(line);
            }
        }
        if (i == m_length && lineWidth <= m_width) {
            m_position = i;
        } else if (lastBreak == m_position) {
            m_position++;
        } else if (lastBreak < m_position) {
            m_position = i;
        } else {
            m_position = lastBreak;
        }
        return m_position;
    }

    private int getNextWord(int startIndex) {
        int space = m_txt.indexOf(' ', startIndex);
        int newLine = m_txt.indexOf('\n', startIndex);
        if (space == -1) {
            space = m_length;
        }

        if (newLine == -1) {
            newLine = m_length;
        }

        if (space < newLine) {
            return space;
        } else {
            return newLine;
        }
    }

    private Bitmap getDifferentColor(char chr, byte R, byte G, byte B) {
        int index = getIndexOfChar(chr);

        long hash = font << 32;
        hash += index << 24;
        hash += R << 16;
        hash += G << 8;
        hash += B;

        if (coloredLetters == null) {
            coloredLetters = new Hashtable<Long, Bitmap>();
        } else if (coloredLetters.get(hash) != null) {
            return coloredLetters.get(hash);
        }

        Bitmap ret;
        if ((R == 0) && (G == 0) && (B == 0)) {
            try {
                ret = letters[index];
            } catch (Exception e) {
                Log.d("" + chr, ""+chr);
                return null;
            }
        } else {
            int p;
            int to = Color.rgb(R & 0xFF, G & 0xFF, B & 0xFF);
            Bitmap src;
            try {
                src = letters[index];
            } catch (Exception e) {
                Log.d("" + chr, "" + chr);
                return null;
            }
            Bitmap bitmap = src.copy(Bitmap.Config.ARGB_8888, true);
            for (int x = 0; x < bitmap.getWidth(); x++) {
                for (int y = 0; y < bitmap.getHeight(); y++) {
                    p = bitmap.getPixel(x, y);
                    if (nightMode) {
                        if (((p >> 16) & 0xFF) == 255 ||
                                ((p >> 8 & 0xFF) == 255) ||
                                ((p & 0xFF) == 255)) {
                            bitmap.setPixel(x, y, to);
                        }
                    } else {
                        if (((p >> 16) & 0xFF) != 255 ||
                                ((p >> 8 & 0xFF) != 255) ||
                                ((p & 0xFF) != 255)) {
                            bitmap.setPixel(x, y, to);
                        }
                    }
                }
            }
            ret = bitmap;
        }
        coloredLetters.put(hash, ret);
        return ret;
    }

    public Bitmap negativeImage(Bitmap original) {
        ColorMatrix negativeMatrix = new ColorMatrix();
        float[] negMat = {-1, 0, 0, 0, 255, 0, -1, 0, 0, 255, 0, 0, -1, 0, 255, 0, 0, 0, 1, 0};
        negativeMatrix.set(negMat);
        final ColorMatrixColorFilter colorFilter = new ColorMatrixColorFilter(negativeMatrix);
        Bitmap rBitmap = original.copy(Bitmap.Config.ARGB_8888, true);
        Paint paint = new Paint();
        paint.setColorFilter(colorFilter);
        Canvas myCanvas = new Canvas(rBitmap);
        myCanvas.drawBitmap(rBitmap, 0, 0, paint);
        return rBitmap;
    }

    public Boolean goBack() {
        switch (mode) {
            case SETTINGS:
                showDialog(0);
                return true;
            case HELP:
            case ABOUT:
            case ZMANIM:
            case NUSACH:
                showMain();
                return true;
            case TFILAMENU:
                if (defaultPressed) {
                    showMain();
                } else {
                    showNusach();
                }
                return true;
            case TFILA:
                showTfilaMenu();
                return true;
            case MAIN:
                finish();
                return true;
            default:
                break;
        }
        return null;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent b) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Boolean x = goBack();
            if (x != null) return x;
        } else if ((keyCode == KeyEvent.KEYCODE_DPAD_UP ||
                keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
                keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) &&
                (mode == Modes.TFILA || mode == Modes.HELP) &&
                font != 3) {
            return curPage.onKeyDown(keyCode, b);
        } else if (keyCode == KeyEvent.KEYCODE_MENU &&
                (mode == Modes.TFILA || mode == Modes.HELP)) {
            return curPage.onKeyDown(keyCode, b);
        }
        super.onKeyDown(keyCode, b);
        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        curPage.createContext(menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        curPage.contextSelect(item);
        return true;
    }

    public OnClickListener minchaNextDayListener = new OnClickListener() {
        public void onClick(View v) {
            dismissDialog(1);
            Tfilon.this.showTfila("mincha", getString(R.string.mincha), 2);
        }
    };

    public OnClickListener minchaPrevDayListener = new OnClickListener() {
        public void onClick (View v){
            dismissDialog(1);
            Tfilon.this.showTfila("mincha", getString(R.string.mincha), 1);
        }
    };

    public OnClickListener arvitNextDayListener = new OnClickListener() {
        public void onClick(View v) {
            dismissDialog(2);
            Tfilon.this.showTfila("arvit", getString(R.string.arvit), 2);
        }
    };

    public OnClickListener arvitPrevDayListener = new OnClickListener() {
        public void onClick(View v) {
            dismissDialog(2);
            Tfilon.this.showTfila("arvit", getString(R.string.arvit), 1);
        }
    };

    @Override
    protected Dialog onCreateDialog(int id) {
        if (id == 0) {
            AlertDialog.Builder builder;

            Context mContext = getApplicationContext();
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.dialog, (ViewGroup) findViewById(R.id.dialog_root));

            TextView text = (TextView) layout.findViewById(R.id.tvDialog);
            text.setTypeface(tf);
            Button button = (Button) layout.findViewById(R.id.dialogSave);
            button.setTypeface(tf);
            button.setOnClickListener(settingsSaveListener);
            button = (Button) layout.findViewById(R.id.dialogDontSave);
            button.setTypeface(tf);
            button.setOnClickListener(settingsCancelListener);
            button = (Button) layout.findViewById(R.id.dialogCancel);
            button.setTypeface(tf);
            button.setOnClickListener(new OnClickListener() {
                public void onClick(View arg0) {
                    dismissDialog(0);
                }
            });
            builder = new AlertDialog.Builder(this);
            Dialog d = builder.setView(layout).create();
            d.show();
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(d.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.FILL_PARENT;
            d.getWindow().setAttributes(lp);
            return d;
        } else if (id == 1) {
            AlertDialog.Builder builder;

            Context mContext = getApplicationContext();
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.late_mincha, (ViewGroup) findViewById(R.id.dialog_root));

            TextView text = (TextView) layout.findViewById(R.id.minchaTvDialog);
            text.setTypeface(tf);
            Button button = (Button) layout.findViewById(R.id.dialogMinchaNextDay);
            button.setTypeface(tf);
            button.setOnClickListener(minchaNextDayListener);
            button = (Button) layout.findViewById(R.id.dialogMinchaPrevDay);
            button.setTypeface(tf);
            button.setOnClickListener(minchaPrevDayListener);
            button = (Button) layout.findViewById(R.id.dialogMinchaCancel);
            button.setTypeface(tf);
            button.setOnClickListener(new OnClickListener() {
                public void onClick(View arg0) {
                    dismissDialog(1);
                }
            });
            builder = new AlertDialog.Builder(this);
            Dialog d = builder.setView(layout).create();
            d.show();
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(d.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.FILL_PARENT;
            d.getWindow().setAttributes(lp);
            return d;
        } else if (id == 2) {
            AlertDialog.Builder builder;

            Context mContext = getApplicationContext();
            LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
            View layout = inflater.inflate(R.layout.early_arvit, (ViewGroup) findViewById(R.id.dialog_root));

            TextView text = (TextView) layout.findViewById(R.id.arvitTvDialog);
            text.setTypeface(tf);
            Button button = (Button) layout.findViewById(R.id.dialogArvitNextDay);
            button.setTypeface(tf);
            button.setOnClickListener(arvitNextDayListener);
            button = (Button) layout.findViewById(R.id.dialogArvitPrevDay);
            button.setTypeface(tf);
            button.setOnClickListener(arvitPrevDayListener);
            button = (Button) layout.findViewById(R.id.dialogArvitCancel);
            button.setTypeface(tf);
            button.setOnClickListener(new OnClickListener() {
                public void onClick(View arg0) {
                    dismissDialog(2);
                }
            });
            builder = new AlertDialog.Builder(this);
            Dialog d = builder.setView(layout).create();
            d.show();
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(d.getWindow().getAttributes());
            lp.width = WindowManager.LayoutParams.FILL_PARENT;
            d.getWindow().setAttributes(lp);
            return d;
        }

        return null;
    }
}