// =====================================================
//  Tfilon
//  Siddur
//  (C) 2011-2016, Ori Hollander
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  If the following code is used in your application,
//  the references are expected.
// =====================================================
package tfilon.tfilon;

public class Colored {

	public int index;
	public byte red;
	public byte green;
	public byte blue;

	public Colored(int index, byte red, byte green, byte blue) {
		this.index = index;
		this.red = red;
		this.green = green;
		this.blue = blue;
	}

	public Colored(int index, Colored other) {
		this.index = index;
		this.red = other.red;
		this.green = other.green;
		this.blue = other.blue;
	}

	public String toHex() {
		String R, G, B;
		R = (red < 16 ? "0" : "") +
				Integer.toHexString(red & 0xFF);
		G = (green < 16 ? "0" : "") +
				Integer.toHexString(green & 0xFF);
		B = (blue < 16 ? "0" : "") +
				Integer.toHexString(blue & 0xFF);
		return R + G + B;
	}
}
