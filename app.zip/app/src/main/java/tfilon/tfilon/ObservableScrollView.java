package tfilon.tfilon;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.AbsListView;
import android.widget.ScrollView;

public class ObservableScrollView extends ScrollView {

    private ScrollViewListener scrollViewListener = null;
    private boolean mIsScrolling = false;
    private boolean mIsFling = false;
    public boolean showBarAtFinish = false;
    boolean waitingForSmooth = false;
    int endX;
    int endY;

    private Runnable mScrollChecker = new Runnable() {
        public void run() {
            int position = getScrollY();
            if (mPreviousPosition - position == 0) {
                mIsFling = false;
                if (scrollViewListener != null) {
                    scrollViewListener.onScrollFinished(ObservableScrollView.this);
                }
                removeCallbacks(mScrollChecker);
            } else {
                mPreviousPosition = getScrollY();
                postDelayed(mScrollChecker, 100);
            }
        }
    };
    private int mPreviousPosition;

    public ObservableScrollView(Context context) {
        super(context);
    }

    public ObservableScrollView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public ObservableScrollView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public void setScrollViewListener(ScrollViewListener scrollViewListener) {
        this.scrollViewListener = scrollViewListener;
    }

    public ScrollViewListener getScrollViewListener() {
        return this.scrollViewListener;
    }

    @Override
    protected void onScrollChanged(int x, int y, int oldx, int oldy) {
        super.onScrollChanged(x, y, oldx, oldy);
        mIsScrolling = true;
        if (scrollViewListener != null) {
            scrollViewListener.onScrollChanged(this, x, y, oldx, oldy);
        }
        if (waitingForSmooth && x == endX && y == endY) {
            if (scrollViewListener != null) {
                scrollViewListener.onScrollFinished(this);
            }
            waitingForSmooth = false;
            endX = 0;
            endY = 0;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean ret = super.onTouchEvent(event);

        if (event.getAction() == MotionEvent.ACTION_UP) {
            if (mIsScrolling && !mIsFling) {
                mIsScrolling = false;
                if (scrollViewListener != null) {
                    scrollViewListener.onScrollFinished(this);
                }
            }
        }

        return ret;
    }

    public void showBar() {
        scrollViewListener.showBar();
    }

    @Override
    public void fling(int velocityY) {
        super.fling(velocityY);

        mIsFling = true;
        if (scrollViewListener != null) {
            post(mScrollChecker);
        }
    }

    public void mySmoothScrollTo(int x, int y) {
        endX = x;
        endY = y;
        waitingForSmooth = true;
        smoothScrollTo(x, y);
    }

}