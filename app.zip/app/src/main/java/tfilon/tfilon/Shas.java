// =====================================================
//  Tfilon
//  Siddur
//  (C) 2011-2016, Ori Hollander
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  If the following code is used in your application,
//  the references are expected.
// =====================================================
package tfilon.tfilon;

public class Shas {

	private static String sedrot[] = { "ברכות", "שבת", "עירובין", "פסחים",
		"שקלים", "יומא", "סוכה", "ביצה", "ראש השנה", "תענית", "מגילה",
		"מועד קטן", "חגיגה", "יבמות", "כתובות", "נדרים", "נזיר", "סוטה",
		"גיטין", "קידושין", "בבא קמא", "בבא מציעא", "בבא בתרא", "סנהדרין",
		"מכות", "שבועות", "עבודה זרה", "הוריות", "זבחים", "מנחות", "חולין",
		"בכורות", "ערכין", "תמורה", "כריתות", "מעילה", "נידה" };
	private static int lengths[] = { 63, 156, 104, 120, 21, 87, 55, 39, 34, 30,
		31, 28, 26, 121, 111, 90, 65, 48, 89, 81, 118, 118, 175, 112, 23,
		48, 75, 13, 119, 109, 141, 60, 33, 33, 27, 36, 72 };
	public static int lengthOfShas;

	public static void setLengthOfShas() {
		lengthOfShas = 0;
		for (int i = 0; i < lengths.length; i++) {
			lengthOfShas += lengths[i];
		}
	}

	public static String getDaf(int day) {
		day %= lengthOfShas;
		int i;
		for (i = 0; i < lengths.length; i++) {
			if (day < 0) {
				break;
			}
			day -= lengths[i];
		}
		i--;
		day += lengths[i] + 2;
		String daf = sedrot[i] + " " + gymatria(day);
		return daf;
	}

	public static String gymatria(int num) {
		String ones[] = { "א", "ב", "ג", "ד", "ה", "ו", "ז", "ח", "ט" };
		String tens[] = { "י", "כ", "ל", "מ", "נ", "ס", "ע", "פ", "צ", "ק",
				"קי", "קכ", "קל", "קמ", "קנ", "קס", "קע" };
		if (num < 10) {
			return ones[num - 1];
		}
		if (num == 15) {
			return "טו";
		}
		if (num == 16) {
			return "טז";
		}
		if (num == 115) {
			return "קטו";
		}
		if (num == 116) {
			return "קטז";
		}
		return tens[num / 10 - 1] +
				(num % 10 != 0 ? ones[num % 10 - 1] : "");
	}
}
