//==========================================================
//	Molad
//  Hebrew(Jewish) calendar
//  (C) 2003, Michael Glickman
//	--------------------------------------------------------
//	SecularCalendar.java - Secular (common) calendar support
//  The code is influenced by the following sources:
//  Hebcal (C) 1994-1999 Danny Sadinoff:
//       http://www.sadinoff.com/hebcal
//  Chelm.org (C) 1999 Steven Ross Weintraub: 
//       http://chelm.org/jewish/calendar/explain.html
//  --------------------------------------------------------
//  If the following code is used in your application, the
//  references are expected.
//  --------------------------------------------------------
//  Started	08 November 2003
//==========================================================

package tfilon.tfilon.moladlib;

public class SecularCalendar
{
	public static final int MIN_YEAR_GREGORIAN = 400;	   // Gregorean calendar cannot start before 400 C.E.
//	public static final int MIN_YEAR_SECULAR_DEFAULT = -3762;		
	public static final int MIN_YEAR_SECULAR = -3762;		
	private static final int MAX_YEAR_SECULAR = 4999999;
//	private static final int MAX_DATE_ABSOLUTE = 1826233929;    //  1 Nissan  5000001
	private static final int MAX_DATE_ABSOLUTE = 1826234106;	//  1 Tishrei 5000001   2-Nov-4996299

	// 20/6/5764
	final static int BASE_YEAR = 4000; 
	final static int BASE_ABSOLUTE = 87573; // 87938; 
	final static int DAYS_IN_YEAR = 365; 
	final static int DAYS_IN_LEAP_YEAR = DAYS_IN_YEAR+1; 
	final static int YEARS_IN_LEAP_CYCLE = 4; 

	final public static int MONTHS_IN_YEAR = 12; 
	final public static int INDEX_SUNDAY = 0; 
	final public static int INDEX_SATURDAY = 6; 

	final static int YEARS_IN_CENTURY_CYCLE = 100;
	final static int YEARS_IN_HUGE_CYCLE = 400;
	final static int GREGORIAN_ADJUSTMENT = 32;

	// We have exactly one leap year in a cycle
	final static int DAYS_IN_LEAP_CYCLE = DAYS_IN_YEAR*YEARS_IN_LEAP_CYCLE + 1;		// 1461

	// We have one less day, because the end of cycle is devisible by 100 and not devisible by 4
	final static int DAYS_IN_CENTURY_CYCLE = (DAYS_IN_YEAR*YEARS_IN_CENTURY_CYCLE)+(YEARS_IN_CENTURY_CYCLE/YEARS_IN_LEAP_CYCLE)-1; // 36524

	// We have one extra day, because the end of cycle is divisible by 400
	final static int DAYS_IN_HUGE_CYCLE = DAYS_IN_CENTURY_CYCLE*(YEARS_IN_HUGE_CYCLE/YEARS_IN_CENTURY_CYCLE) + 1;  // 146097
	

	public static int DayInMonths[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

	public final static int JANUARY=0;
	public final static int FEBRUARY=1;
	public final static int MARCH=2;
	public final static int APRIL=3;
	public final static int MAY=4;
	public final static int JUNE=5;
	public final static int JULY=6;
	public final static int AUGUST=7;
	public final static int SEPTEMBER=8;
	public final static int OCTOBER=9;
	public final static int NOVEMBER=10;
	public final static int DECEMBER=11;
	


	// day is 1-based, month is 0-based	
	static boolean toAbsolute (DateHolder pdate, final DateData fromDate)
	{
		
		return toAbsolute(pdate, fromDate, 
				pdate.alwaysJulian == false &&
				fromDate.compare(EventData.gregorianStart.dateSecular) > 0);	
	
	}

	static boolean toAbsolute (DateHolder pdate, DateData fromDate, boolean pisGregorian)
	{
		int pyear = fromDate.year;


		//if (pyear > MAX_YEAR_SECULAR || pyear < pdate.minYearSecular) return false;
		if (pyear > MAX_YEAR_SECULAR || pyear < MIN_YEAR_SECULAR) return false;
		pyear += BASE_YEAR;	

		int pday = fromDate.day;
		int pmonth = fromDate.month;
		if (pmonth < 0 || pday <= 0) return false;
				
		evaluateYear(pyear, pisGregorian);
		
		fromDate.day = pday = Math.min(pday, DayInMonths[pmonth]);
		
		int yearStart = getNewYearAbsolute(pyear, pisGregorian);

		pday--;
		pday += yearStart;
		while (--pmonth >= 0) pday += DayInMonths[pmonth]; 

		pday -= BASE_ABSOLUTE;
		
		if (pday < 0 || pday >= MAX_DATE_ABSOLUTE) return false;

		pdate.dateSecular = fromDate;		
		pdate.secNewYearAbsolute = yearStart-BASE_ABSOLUTE;
		pdate.dateAbsolute = pday;
		pdate.isGregorian = pisGregorian;
		return true;		
	}


	// Returns DateData (day, month, year) 
	static boolean fromAbsolute (DateHolder pdate, int pabs)
	{
		boolean pisGregorian = (pdate.alwaysJulian == false) &&
		                       (pabs > EventData.gregorianStart.dateAbsolute);
		int pyear = 0;		
		int pday;
		
		// Rough evaluation
		pabs += BASE_ABSOLUTE;
		
		pday = pabs;

		if (pisGregorian)  {			
			pday -= GREGORIAN_ADJUSTMENT;

			pyear += (pday / DAYS_IN_HUGE_CYCLE) * YEARS_IN_HUGE_CYCLE;
			pday %= DAYS_IN_HUGE_CYCLE;

			pyear += (pday / DAYS_IN_CENTURY_CYCLE) * YEARS_IN_CENTURY_CYCLE;
			pday %= DAYS_IN_CENTURY_CYCLE;
		}


		pyear += (pday / DAYS_IN_LEAP_CYCLE) * YEARS_IN_LEAP_CYCLE ;
		pday %=  DAYS_IN_LEAP_CYCLE;


		pyear += (pday / DAYS_IN_YEAR) * DAYS_IN_YEAR;


		// Now get it precicely
		int yearStart = getNewYearAbsolute(pyear, pisGregorian);
		int yearDayCount;


		while(yearStart > pabs) {
			yearStart -= evaluateYear(--pyear, pisGregorian);	;
		}	

		for (;;) {
			yearDayCount = evaluateYear(pyear, pisGregorian);	
			pday = pabs - yearStart;
			if (pday < yearDayCount) break; 
			pyear++;
			yearStart += yearDayCount;
		}

		pyear -= BASE_YEAR;
		//if (pyear > MAX_YEAR_SECULAR || pyear < pdate.minYearSecular) return false;
		if (pyear > MAX_YEAR_SECULAR || pyear < MIN_YEAR_SECULAR) return false;

		// Now we get the day within the year
		int pmonth = 0, mdays;
		while (pday >= (mdays = DayInMonths[pmonth])) {
			pday -= mdays;
			pmonth++;
		}


		pdate.dateAbsolute = pabs-BASE_ABSOLUTE;
		pdate.secNewYearAbsolute = yearStart-BASE_ABSOLUTE;	
		pdate.dateSecular = new DateData(pday+1, pmonth, pyear);
		pdate.isGregorian = pisGregorian;
		return true;
	}

	

	private static int getNewYearAbsolute(int pyear, boolean pisGregorian)
	{
		pyear--;
	
		int pday = pyear*DAYS_IN_YEAR + pyear/YEARS_IN_LEAP_CYCLE;

		if (pisGregorian) 
			pday += pyear/YEARS_IN_HUGE_CYCLE - 
			        pyear/YEARS_IN_CENTURY_CYCLE + GREGORIAN_ADJUSTMENT;
					
		return pday;			
				
	}

	
	private static int evaluateYear(int pyear, boolean pisGregorian) 
	{
		int daysInYear = DAYS_IN_YEAR;
		if (isLeapYear(pyear, pisGregorian)) {
			DayInMonths[FEBRUARY] = 29;	
			daysInYear++;
		} else
			DayInMonths[FEBRUARY] = 28;	
		
		return daysInYear;	
	}

	public static boolean isLeapYear(int pyear, boolean pisGregorian) 
	{
		boolean isLeap = ((pyear % YEARS_IN_LEAP_CYCLE) == 0);

		if (pisGregorian) {
			if ((pyear % YEARS_IN_CENTURY_CYCLE) == 0 && 
			    (pyear % YEARS_IN_HUGE_CYCLE) != 0 ) isLeap = false;
		}		
		
		return isLeap;
	}

	public static int monthMaxDuration(int month)
	{
		if (month == FEBRUARY)	return 29;
		return DayInMonths[month];
	}			

	
	public static String getDayOfWeekName(int dayOfWeek)
	{
		return MText.DowNamesCommon[dayOfWeek];

	}
	public static String getMonthName(int monthNumber)
	{
		return MText.MonthNamesSecular[monthNumber];

	}

	public static String getMonthNameShort(int monthNumber)
	{
		int len = MText.MonthNamesSecularShortLength[monthNumber];
		String text = MText.MonthNamesSecular[monthNumber];
		if (len > 0) text = text.substring(0, len);
		return text;
	}

	public static String dateToTextShort(final DateData fromDate)
	{
		return String.valueOf(fromDate.day) + 
			   getMonthNameShort(fromDate.month) +
			   String.valueOf(fromDate.year);
	}

	public static String dateToTextTruncated(final DateData fromDate)
	{
		String yearText = String.valueOf(Math.abs(fromDate.year) % 100);
		if (yearText.length() < 2) yearText = "0" + yearText;
		return String.valueOf(fromDate.day) + 
			   getMonthNameShort(fromDate.month) + yearText;
			
	}

}