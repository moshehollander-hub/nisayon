//		SecularCalendar.toAbsolute(gregorianStart, new DateData(1, 0, 1763), false);		
//=====================================================
//	Molad
//  Hebrew(Jewish) calendar
//  (C) 2003, Michael Glickman
//	--------------------------------------------------
//	Sedrot.java - Sedrot support
//  The information for sedrot is obtained from
//  HebCalendar code:
//  Danny Sadinoff, http://www.sadinoff.com/hebcal
//  ---------------------------------------------------
//  If the following code is used in your application, 
//  the references are expected.
//  ---------------------------------------------------
//  Started	nearly 20 November 2003
//=====================================================
// Modified by Ori Hollander
// (c) 2011
package tfilon.tfilon.moladlib;

public class Sedrot {

	private static final int YEAR_TYPE_INCOMPLETE = 0;
	private static final int YEAR_TYPE_REGULAR = 1;
	private static final int YEAR_TYPE_COMPLETE = 2;
	//===============================================================
	// The sedrot tables are just copied from HebCal with 
	// some minor accomodations.
	//===============================================================
	//***************************************************************
	//  --  The non-leap year types -- 
	// Hebrew year that starts on Monday, is `incomplete' (Heshvan and
	//   Kislev each have 29 days), and has Passover start on Tuesday. 
	private static final byte[] NonleapMondayIncomplete = { 51, 52, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, -21, 23, 24, -1, 25, -26,
			-28, 30, -31, 33, 34, 35, 36, 37, 38, 39,
			40, -41, 43, 44, 45, 46, 47, 48, 49, -50, 52 };
	// Hebrew year that starts on Monday, is `complete' (Heshvan and
	// Kislev each have 30 days), and has Passover start on Tuesday.
	private static final byte[] NonleapMondayCompleteDiaspora = { 51, 52, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, -21, 23, 24, -1, 25, -26,
			-28, 30, -31, 33, -1, 34, 35, 36, 37, -38,
			40, -41, 43, 44, 45, 46, 47, 48, 49, -50, 52 };
	private static final byte[] NonleapMondayCompleteIsrael = NonleapMondayIncomplete;
	// Hebrew year that starts on Tuesday, is `regular' (Heshvan has 29
	// days and Kislev has 30 days), and has Passover start on Thursday. 
	private static final byte[] NonleapTuesdayRegularDiaspora = NonleapMondayCompleteDiaspora;
	private static final byte[] NonleapTuesdayRegularIsrael = NonleapMondayIncomplete;
	// Hebrew year that starts on Thursday, is `regular' (Heshvan has 29
	// days and Kislev has 30 days), and has Passover start on Saturday. */
	private static final byte[] NonleapThursdayRegularDiaspora = { 52, 53, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, -21, 23, 24, -1, -1, 25,
			-26, -28, 30, -31, 33, 34, 35, 36, 37, 38,
			39, 40, -41, 43, 44, 45, 46, 47, 48, 49,
			50, 51 };
	private static final byte[] NonleapThursdayRegularIsrael = { 52, 53, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, -21, 23, 24, -1, 25, -26,
			-28, 30, 31, 32, 33, 34, 35, 36, 37, 38,
			39, 40, -41, 43, 44, 45, 46, 47, 48, 49,
			50, 51 };
	// Hebrew year that starts on Thursday, is `complete'
	// (Heshvan and Kislev each have 30 days),
	// and has Passover start on Sunday. 
	private static final byte[] NonleapThursdayComplete = { 52, 53, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, 21, 22, 23, 24, -1, 25,
			-26, -28, 30, -31, 33, 34, 35, 36, 37, 38,
			39, 40, -41, 43, 44, 45, 46, 47, 48, 49,
			50, 51 };
	// Hebrew year that starts on Saturday, is `incomplete'
	//  (Heshvan and Kislev each have 29 days),
	// and has Passover start on Sunday. 
	private static final byte[] NonleapSaturdayIncomplete = { -1, 52, 53, 53, 0, 1, 2, 3, 4, 5,
			6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
			16, 17, 18, 19, 20, -21, 23, 24, -1, 25,
			-26, -28, 30, -31, 33, 34, 35, 36, 37, 38,
			39, 40, -41, 43, 44, 45, 46, 47, 48, 49,
			50, 51 };
	// Hebrew year that starts on Saturday, is `complete' (Heshvan and
	// Kislev each have 30 days), and has Passover start on Tuesday. */
	private static final byte[] NonleapSaturdayComplete = { -1, 52, 53, 53, 0, 1, 2, 3, 4, 5,
			6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
			16, 17, 18, 19, 20, -21, 23, 24, -1, 25,
			-26, -28, 30, -31, 33, 34, 35, 36, 37, 38,
			39, 40, -41, 43, 44, 45, 46, 47, 48, 49,
			-50, 52 };
	//***************************************************************
	//  --  The leap year types (keviot) -- 
	// Hebrew year that starts on Monday, is `incomplete' (Heshvan and
	// Kislev each have 29 days), and has Passover start on Thursday. 
	private static final byte[] LeapMondayIncompleteDiaspora = { 51, 52, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
			27, -1, 28, 29, 30, 31, 32, 33, -1, 34,
			35, 36, 37, -38, 40, -41, 43, 44, 45, 46,
			47, 48, 49, -50, 52 };
	private static final byte[] LeapMondayIncompleteIsrael = { 51, 52, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
			27, -1, 28, 29, 30, 31, 32, 33, 34, 35,
			36, 37, 38, 39, 40, -41, 43, 44, 45, 46,
			47, 48, 49, -50, 52 };
	// Hebrew year that starts on Monday, is `complete' (Heshvan and
	// Kislev each have 30 days), and has Passover start on Saturday. */
	private static final byte[] LeapMondayCompleteDiaspora = { 51, 52, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
			27, -1, -1, 28, 29, 30, 31, 32, 33, 34,
			35, 36, 37, 38, 39, 40, -41, 43, 44, 45,
			46, 47, 48, 49, 50, 51 };
	private static final byte[] LeapMondayCompleteIsrael = { 51, 52, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
			27, -1, 28, 29, 30, 31, 32, 33, 34, 35,
			36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46,
			47, 48, 49, 50, 51 };
	// Hebrew year that starts on Tuesday, is `regular' (Heshvan has 29
	// days and Kislev has 30 days), and has Passover start on Saturday. */
	private static final byte[] LeapTuesdayRegularDiaspora = LeapMondayCompleteDiaspora;
	private static final byte[] LeapTuesdayRegularIsrael = LeapMondayCompleteIsrael;
	// Hebrew year that starts on Thursday, is `incomplete' (Heshvan and
	// Kislev both have 29 days), and has Passover start on Sunday. */
	private static final byte[] LeapThursdayIncomplete = { 52, 53, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
			27, 28, -1, 29, 30, 31, 32, 33, 34, 35,
			36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
			46, 47, 48, 49, 50, 51 };
	// Hebrew year that starts on Thursday, is `complete' (Heshvan and
	// Kislev both have 30 days), and has Passover start on Tuesday. */
	private static final byte[] LeapThursdayComplete = { 52, 53, 53, 0, 1, 2, 3, 4, 5, 6,
			7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
			17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
			27, 28, -1, 29, 30, 31, 32, 33, 34, 35,
			36, 37, 38, 39, 40, 41, 42, 43, 44, 45,
			46, 47, 48, 49, -50, 52 };
	// Hebrew year that starts on Saturday, is `incomplete' (Heshvan and
	// Kislev each have 29 days), and has Passover start on Tuesday. */
	private static final byte[] LeapSaturdayIncomplete = { -1, 52, 53, 53, 0, 1, 2, 3, 4, 5,
			6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
			16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
			26, 27, -1, 28, 29, 30, 31, 32, 33, 34,
			35, 36, 37, 38, 39, 40, -41, 43, 44, 45,
			46, 47, 48, 49, -50, 52 };
	// Hebrew year that starts on Saturday, is `complete' (Heshvan and
	// Kislev each have 30 days), and has Passover start on Thursday.
	private static final byte[] LeapSaturdayCompleteDiaspora = { -1, 52, 53, 53, 0, 1, 2, 3, 4, 5,
			6, 7, 8, 9, 10, 11, 12, 13, 14, 15,
			16, 17, 18, 19, 20, 21, 22, 23, 24, 25,
			26, 27, -1, 28, 29, 30, 31, 32, 33, -1,
			34, 35, 36, 37, -38, 40, 41, 43, 44, 45,
			46, 47, 48, 49, 50, 52 };
	private static final byte[] LeapSaturdayCompleteIsrael = LeapSaturdayIncomplete;
	//***************************************************************
	// I believe the following scheme is more readable than Danny's
	// 4D array. BTW, with Java "just" 4D could be insufficient...
	// sedra_years_array[leap][rosh_day][type][israel/diaspora] 
	// Year starts on Monday
	private static final byte[][][] SedraYearsMonday = {
			// Incomplete                  Regular       Complete
			{ NonleapMondayIncomplete, null, NonleapMondayCompleteIsrael }, // Nonleap Israel
			{ NonleapMondayIncomplete, null, NonleapMondayCompleteDiaspora }, // Nonleap Diaspora
			{ LeapMondayIncompleteIsrael, null, LeapMondayCompleteIsrael }, // Leap Israel
			{ LeapMondayIncompleteDiaspora, null, LeapMondayCompleteDiaspora }, // Leap Diaspora
	};
	// Year starts on Tuesday
	private static final byte[][][] SedraYearsTuesday = {
			// Incomplete              Regular       Complete
			{ null, NonleapTuesdayRegularIsrael, null }, // Nonleap Israel
			{ null, NonleapTuesdayRegularDiaspora, null }, // Nonleap Disapora
			{ null, LeapTuesdayRegularIsrael, null }, // Leap Israel
			{ null, LeapTuesdayRegularDiaspora, null }, // Leap Diaspora
	};
	// Year starts on Thursday
	private static final byte[][][] SedraYearsThursday = {
			// Incomplete              Regular       Complete
			{ null, NonleapThursdayRegularIsrael, NonleapThursdayComplete }, // Nonleap Israel
			{ null, NonleapThursdayRegularDiaspora, NonleapThursdayComplete }, // Nonleap Disapora
			{ LeapThursdayIncomplete, null, LeapThursdayComplete }, // Leap Israel  
			{ LeapThursdayIncomplete, null, LeapThursdayComplete } // Leap Diaspora
	};
	// Year starts on Saturday
	private static final byte[][][] SedraYearsSaturday = {
			// Incomplete              Regular       Complete
			{ NonleapSaturdayIncomplete, null, NonleapSaturdayComplete }, // Nonleap Israel
			{ NonleapSaturdayIncomplete, null, NonleapSaturdayComplete }, // Nonleap Disapora
			{ LeapSaturdayIncomplete, null, LeapSaturdayCompleteIsrael }, // Leap Israel  
			{ LeapSaturdayIncomplete, null, LeapSaturdayCompleteDiaspora } // Leap Diaspora
	};

	/*
	 * private static final byte[][][][] SedraYearsReference = {
	 * SedraYearsMonday, SedraYearsMonday, // Sunday(-), Monday
	 * SedraYearsTuesday, SedraYearsTuesday, // Tuesday, Wednesday(?)
	 * SedraYearsThursday, SedraYearsThursday, // Thursday, Friday
	 * SedraYearsSaturday // Thursday, Friday }
	 */
	// We can squeeze the above (commented out table) assuming that	
	// day of the week is merely deleted by 2 to get the index:
	private static final byte[][][][] SedraYearsReference = {
			SedraYearsMonday, SedraYearsTuesday, SedraYearsThursday, SedraYearsSaturday
	};

	public static String[] getSedrotNames(DateHolder dateH, LocationHolder locationH) {
		String[] result = null;

		// When the year starts ?	
		int absNewYear = dateH.hebNewYearAbsolute;
		// At waht day of week the year starts ?	
		int dowNewYear = HebCalendar.getDayOfWeek(absNewYear);
		// First saturday in the year
		int absFirstSaturday = absNewYear +
				(HebCalendar.DOW_SHABBAT - dowNewYear);

		byte[][][] sedraYears = SedraYearsReference[dowNewYear >> 1];

		// Evaluate type
		int type = YEAR_TYPE_REGULAR;
		int[] monthDurations = dateH.hebMonthDurations;
		boolean longKislev = monthDurations[HebCalendar.KISLEV] >= 30;
		boolean longCheshvan = monthDurations[HebCalendar.CHESHVAN] >= 30;

		if (longKislev) {
			if (longCheshvan) {
				type = YEAR_TYPE_COMPLETE;
			}
		} else {
			if (!longCheshvan) {
				type = YEAR_TYPE_INCOMPLETE;
			}
		}

		// Evaluate index (leap/nonleap and Israel/Diaspora)				
		int index = (monthDurations.length >= HebCalendar.MONTHS_PER_LEAP_YEAR) ? 2 : 0;
		index += locationH.holidayStyle; // For Diaspora get the next entry

		byte[] sedraArray = sedraYears[index][type];
		if (sedraArray == null) {
			return result;
		}

		int curDate = dateH.dateAbsolute;
		int absNextSaturday = curDate +
				(HebCalendar.DOW_SHABBAT - HebCalendar.getDayOfWeek(curDate));
		int weekInYear = (absNextSaturday - absFirstSaturday) /
				HebCalendar.DAYS_PER_WEEK;

		if (weekInYear >= sedraArray.length) {
			return result;
		}

		index = sedraArray[weekInYear];
		if (index == 53) {
			index = -1;
		}

		if (index >= 0) {
			result = new String[1];
			result[0] = MText.SedrotNames[index];
		} else if (index != -1) {
			// Double parashat
			index = -index;
			result = new String[2];
			result[0] = MText.SedrotNames[index];
			result[1] = MText.SedrotNames[index + 1];
		}
		return result;

	}

	// Added by Ori Hollander
	// (c) 2010
	public static int getSedraIndex(DateHolder dateH, LocationHolder locationH) {
		// When the year starts ?	
		int absNewYear = dateH.hebNewYearAbsolute;
		// At waht day of week the year starts ?	
		int dowNewYear = HebCalendar.getDayOfWeek(absNewYear);
		// First saturday in the year
		int absFirstSaturday = absNewYear +
				(HebCalendar.DOW_SHABBAT - dowNewYear);

		byte[][][] sedraYears = SedraYearsReference[dowNewYear >> 1];

		// Evaluate type
		int type = YEAR_TYPE_REGULAR;
		int[] monthDurations = dateH.hebMonthDurations;
		boolean longKislev = monthDurations[HebCalendar.KISLEV] >= 30;
		boolean longCheshvan = monthDurations[HebCalendar.CHESHVAN] >= 30;

		if (longKislev) {
			if (longCheshvan) {
				type = YEAR_TYPE_COMPLETE;
			}
		} else {
			if (!longCheshvan) {
				type = YEAR_TYPE_INCOMPLETE;
			}
		}

		// Evaluate index (leap/nonleap and Israel/Diaspora)				
		int index = (monthDurations.length >= HebCalendar.MONTHS_PER_LEAP_YEAR) ? 2 : 0;
		index += locationH.holidayStyle; // For Diaspora get the next entry

		byte[] sedraArray = sedraYears[index][type];
		if (sedraArray == null) {
			return -1;
		}

		int curDate = dateH.dateAbsolute;
		int absNextSaturday = curDate +
				(HebCalendar.DOW_SHABBAT - HebCalendar.getDayOfWeek(curDate));
		int weekInYear = (absNextSaturday - absFirstSaturday) /
				HebCalendar.DAYS_PER_WEEK;

		if (weekInYear >= sedraArray.length) {
			return -1;
		}

		while ((index = sedraArray[weekInYear++]) == -1) {
			;
		}

		if (index < 0) {
			index = -index;
		}
		return index;
	}
}