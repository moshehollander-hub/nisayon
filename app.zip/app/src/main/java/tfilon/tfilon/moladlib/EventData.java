// =====================================================
//  Molad
//  Hebrew(Jewish) calendar
//  (C) 2003-2006, Michael Glickman
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  LocationHolder class 
//  Constains lacation details
//  ----------------------------------------------------
//  If the following code is used in your application, 
//  the references are expected.
//  ----------------------------------------------------
//	Event data (holidays and custom events)
//	11 November 2003
// =====================================================


package tfilon.tfilon.moladlib;
import java.util.*;



public class EventData
{
	public final DateHolder eventDate;
	public final byte[]     eventData;
	public boolean isKatan;
	public byte    candleLightSettings;

	public static DateHolder gregorianStart;
	public static final DateData
	        gregorianStartDefault = new DateData(4, SecularCalendar.OCTOBER, 1582);		

//	public static int location;
	
	public static final byte EVENT_LISTED = 1;
	public static final byte EVENT_DISPLAYED = 2;
	public static final byte EVENT_HIGHLIGHTED = 4;
	public static final byte EVENT_EREV = 8;
	public static final byte EVENT_KATAN = 16;
	//static final byte EVENT_KATANLIST = 16;
	//static final byte EVENT_KATANDISP = 32;
	public static final byte EVENT_REMINDER = 64;

	public static final byte CANDLES_NONE = 0;
	public static final byte CANDLES_NORMAL = 1;
	public static final byte CANDLES_CONTINUOUS = 2;
	public static final byte CANDLE_MODE_MASK = CANDLES_NORMAL | CANDLES_CONTINUOUS;
	public static final byte CANDLES_FRAME = 4;
	

	public static final byte EVENT_FLAGS_DEFAULT = EVENT_LISTED | EVENT_DISPLAYED;

	public static final byte CUSTOM_FLAG = (byte) 0x80;
	public static final byte ROSH_CHODESH_INDEX = 0;
	public static final int  REGULAR_HOLIDAYS_START = 1;	// Bypassing Rosh Chodesh
	
	public static final int  MAX_CUSTOM_EVENTS = 128;	
	public static final int  LONG_NAME_SIZE = 20;
	public static final int  SHORT_NAME_SIZE = 12;
	
	
	//********************************************************************************************
	//  Holidays: name index, day, month, duration(or abscent if 1)
	private static final byte[] DefaultFlags =
	{
		EVENT_DISPLAYED,                                                	 // Rosh Chodesh				
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_EREV,				 // Ta'anit Bachorot
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED |
			       EVENT_REMINDER | EVENT_EREV,	 // Passover
		EVENT_LISTED | EVENT_DISPLAYED,					         // Yom HaShoa
		EVENT_LISTED | EVENT_DISPLAYED,						 // Yom HaZikaron
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED  |
		               EVENT_REMINDER | EVENT_EREV,	 			 // Yom HaAtzmaut
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_EREV,		                 // Lag BaOmer
		EVENT_LISTED | EVENT_DISPLAYED,						 // Yom Yerushalaim
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED |
			       EVENT_REMINDER | EVENT_EREV,	 			 // Shavuot 
		EVENT_LISTED | EVENT_DISPLAYED,					         // 17 Tammuz
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_EREV,		  		 // Tisha B'Av
		EVENT_DISPLAYED,						         // 15 B'Av
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED 
			     | EVENT_REMINDER | EVENT_EREV,	 			 // Rosh HaShana
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_EREV,				 // Tzom Gedaliah
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED |
			       EVENT_REMINDER | EVENT_EREV,	 			 // Yom Kippur
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED |
			       EVENT_REMINDER | EVENT_EREV,				 // Sukkot
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED,	                 // Hosha'anah Rabah
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED,            		 // Shmini Atzeret
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED,			 // Simhat Torah
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_REMINDER | EVENT_EREV,		 // Chanukah
		EVENT_LISTED | EVENT_DISPLAYED,				                 // Asarah B'Tevet
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED,	       		 // Tu B'Shevat
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_EREV,				 // Ta'aniot Esther
		EVENT_LISTED | EVENT_DISPLAYED | EVENT_HIGHLIGHTED |
			       EVENT_REMINDER | EVENT_EREV | EVENT_KATAN, 		 // Purim
		EVENT_DISPLAYED 							 // Shushah Purim
	};

	private static final byte[] DefaultCandleLight =
	{
		CANDLES_NONE,            // Rosh Chodesh				
		CANDLES_NONE,		 // Ta'anit Bachorot
		CANDLES_NORMAL | CANDLES_FRAME,	 // Passover
		CANDLES_NONE,          	 // Yom HaShoa
		CANDLES_NONE,            // Yom HaZikaron
		CANDLES_NONE,		 // Yom HaAtzmaut
		CANDLES_NONE,  		 // Lag BaOmer
		CANDLES_NONE,            // Yom Yerushalaim
		CANDLES_NORMAL,		 // Shavuot 
		CANDLES_NONE,         	 // 17 Tammuz
		CANDLES_NONE,            // Tisha B'Av
		CANDLES_NONE,	         // 15 B'Av
		CANDLES_NORMAL,		 // Rosh HaShana
		CANDLES_NONE,		 // Tzom Gedaliah
		CANDLES_NORMAL,		 // Yom Kippur
		CANDLES_NORMAL,		 // Sukkot
		CANDLES_NONE,            // Hosha'anah Rabah
		CANDLES_NORMAL,		 // Shmini Atzeret
		CANDLES_NONE,		 // Simhat Torah
		CANDLES_CONTINUOUS,	 // Chanukah
		CANDLES_NONE,            // Asarah B'Tevet
		CANDLES_NONE, 		 // Tu B'Shevat
		CANDLES_NONE,		 // Ta'aniot Esther
		CANDLES_NONE,		 // Purim
		CANDLES_NONE             // Shushah Purim
	};

	private static final int PESACH_INDEX = 2;
	private static final int TISHABAV_INDEX = 10;
	private static final int ROSHSHANA_INDEX = 12;

	static final int VAR_SHAB_FORWARD = 1;		// Replace Shabbath by next day
	// static final int OPT_SHAB_BACK = 2;
	static final int VAR_WEND_BACK = 3;		// Replace weekend thursday
	static final int VAR_PRE_WEND_BACK = 4;		// Next day has WEND_BACK

	
	public static final int INDEX_NAMEIND = 0;
	public static final int INDEX_DAY = 1;
	public static final int INDEX_MONTH = 2;
	public static final int INDEX_DURATION = 3;
	public static final int INDEX_CANDLELIGHT = 4;	
	public static final int INDEX_VAR = 5;		// Only with holidays
//	public static final int INDEX_COUNT = 5;
	public static final int INDEX_COUNT_CUSTOM = 5;    // Number of indices for custom events



	private static final byte[][] HolidaysDiaspora =
	{
		{  0, 1,  HebCalendar.ANYMONTH},        // Rosh Chodesh
		{  1, 14, HebCalendar.NISSAN, 1, 0, VAR_WEND_BACK},	   // Ta'anit Bechorot
		{  2, 15, HebCalendar.NISSAN, 8, 2},     // Passover
		{  3, 27, HebCalendar.NISSAN},    	   // Yom HaShoah
		{  4,  4, HebCalendar.IYAR,   1, 0, VAR_PRE_WEND_BACK},   // Yom Hazikaron
		{  5,  5, HebCalendar.IYAR,   1, 0, VAR_WEND_BACK}, 	   // Yom HaAtzmaut
		{  6, 18, HebCalendar.IYAR},      	   // Lag BaOmer
		{  7, 28, HebCalendar.IYAR},     	   // Yom Yerushalayim
		{  8,  6, HebCalendar.SIVAN,  2},   	   // Shavuot
		{  9, 17, HebCalendar.TAMMUZ, 1, 0, VAR_SHAB_FORWARD},      // Shiva Asar B'Tammuz
		{ 10,  9, HebCalendar.AV,     1, 0, VAR_SHAB_FORWARD}, 	    // Tisha B'Av
		{ 11, 15, HebCalendar.AV}, 			   // Tu B'Av
		{ 12,  1, HebCalendar.TISHRI, 2}, 	   // Rosh HaShanah
		{ 13,  3, HebCalendar.TISHRI, 1, 0, VAR_SHAB_FORWARD},   // Tzom Gedaliah
		{ 14, 10, HebCalendar.TISHRI},	 	   // Yom Kippur
		{ 15, 15, HebCalendar.TISHRI, 6, 2},	   // Sukkot
		{ 16, 21, HebCalendar.TISHRI},	  	   // Hosha'anah Rabah
		{ 17, 22, HebCalendar.TISHRI, 1, 2}, 	   // Shmini Atzeret  (candle light continues to Simhat Torah)
		{ 18, 23, HebCalendar.TISHRI}, 	  	   // Simchat Torah
		{ 19, 25, HebCalendar.KISLEV, 8},	   // Chanukah
		{ 20, 10, HebCalendar.TEVET,  1, 0, VAR_WEND_BACK},		   // Asarah B'Tevet
		{ 21, 15, HebCalendar.SHEVAT},	     	   // Tu B'Shevat
		{ 22, 13, HebCalendar.ADAR2,  1, 0, VAR_WEND_BACK},	 // Fast of Esther
		{ 23, 14, HebCalendar.ADAR2},		   // Purim
		{ 24, 15, HebCalendar.ADAR2,  1, 0, VAR_SHAB_FORWARD}	// Shushah Purim
	};	


	private static final byte[][] HolidaysIsrael =
	{
		{  0, 1,  HebCalendar.ANYMONTH},        // Rosh Chodesh
		{  1, 14, HebCalendar.NISSAN, 1, 0, VAR_WEND_BACK},	   // Ta'anit Bechorot
		{  2, 15, HebCalendar.NISSAN, 7, 1},		// Passover
		{  3, 27, HebCalendar.NISSAN},    		// Yom HaShoah
		{  4,  4, HebCalendar.IYAR,   1, 0, VAR_PRE_WEND_BACK},   // Yom Hazikaron
		{  5,  5, HebCalendar.IYAR,   1, 0, VAR_WEND_BACK}, 	   // Yom HaAtzmaut
		{  6, 18, HebCalendar.IYAR},      		// Lag BaOmer
		{  7, 28, HebCalendar.IYAR},     		// Yom Yerushalayim
		{  8,  6, HebCalendar.SIVAN},   		// Shavuot
		{  9, 17, HebCalendar.TAMMUZ, 1, 0, VAR_SHAB_FORWARD},  // Shiva Asar B'Tammuz
		{ 10,  9, HebCalendar.AV,     1, 0, VAR_SHAB_FORWARD}, 	// Tisha B'Av
		{ 11, 15, HebCalendar.AV}, 		  		// Tu B'Av
		{ 12,  1, HebCalendar.TISHRI, 2}, 	 	// Rosh HaShanah
		{ 13,  3, HebCalendar.TISHRI, 1, 0, VAR_SHAB_FORWARD},	 	// Tzom Gedaliah
		{ 14, 10, HebCalendar.TISHRI},	 	 	// Yom Kippur
		{ 15, 15, HebCalendar.TISHRI, 6, 1},	  	// Sukkot
		{ 16, 21, HebCalendar.TISHRI},		  	// Hosha'anah Rabah
		{ 17, 22, HebCalendar.TISHRI},		  	// Shmini Atzeret
		{ 18, 22, HebCalendar.TISHRI},		  	// Simchat Torah
		{ 19, 25, HebCalendar.KISLEV, 8},		// Chanukah
		{ 20, 10, HebCalendar.TEVET,  1, 0, VAR_WEND_BACK},	// Asarah B'Tevet
		{ 21, 15, HebCalendar.SHEVAT},			// Tu B'Tevet
		{ 22, 13, HebCalendar.ADAR2,  1, 0, VAR_WEND_BACK},	// Fast of Esther
		{ 23, 14, HebCalendar.ADAR2},			// Purim
		{ 24, 15, HebCalendar.ADAR2, 1, VAR_SHAB_FORWARD}	    	// Shushah Purim
	};	



	public static byte[] HolidaySettings;
	public static byte[] HolidayCandleLight;		// byte

	public static Vector CustomEventNames;		// String[]
	public static byte[] CustomEventSettings; 	// byte
	public static byte[] CustomEventCandleLight;	// byte
	public static Vector CustomEvents;		// byte[]


	// Has all active holidays to be listed
	// Each event has: 
	//  	index (0x80 for holiday)
	//      day, month, d+uration
	
	//===================================================================================

	EventData(final DateHolder _eventDate, final byte[] _eventData,
	          byte _candleLightSettings, boolean _isKatan)
	{ 
		eventDate = _eventDate;
		eventData = _eventData;
		candleLightSettings = _candleLightSettings;
		isKatan = _isKatan;
	}
	
	public static void resetDisplaySettings()
	{
		int len = getHolidayCount();
		HolidaySettings = new byte[len];
		HolidayCandleLight = new byte[len];
		
		resetHolidaySettings();
		
		CustomEventNames = new Vector();
		CustomEvents = new Vector();
		CustomEventSettings = new byte[MAX_CUSTOM_EVENTS];
		CustomEventCandleLight = new byte[MAX_CUSTOM_EVENTS];

		// Start of Greg+orian calendar
		gregorianStart = new DateHolder();
		gregorianStart.alwaysJulian = true;
	//	gregorianStart.minYearSecular = SecularCalendar.MIN_YEAR_GREGORIAN;
		gregorianStart.acceptSecularDate(gregorianStartDefault);		
	}


	public static void resetHolidaySettings()
	{
		int len = getHolidayCount();
		
		System.arraycopy(EventData.DefaultFlags, 0, EventData.HolidaySettings, 0, len);
		System.arraycopy(EventData.DefaultCandleLight, 0, EventData.HolidayCandleLight, 0, len);

//		for (int i=0; i<len; i++) {
//			HolidaySettings[i] = DefaultFlags[i];
//			HolidayCandleLight[i] = DefaultCandleLight[i];
//		}	
	}

	//===================================================================================
	public static Vector getListOfEvents(final DateHolder targetDateHolder, 
	                                     final LocationHolder targetLocation, boolean isPast)
	{
		EventProcessor processor;
//			isPast ? (EventProcessor) (new PastEventsProcessor(targetDateHolder))
//			       : (EventProcessor) (new ComingEventsProcessor(targetDateHolder));

		if (isPast) 
			processor = new PastEventsProcessor(targetDateHolder, targetLocation);
		else 
			processor = new ComingEventsProcessor(targetDateHolder, targetLocation);

		return getEvents(processor, EVENT_LISTED, false); 
	}

	public static String getReminderForDate(final DateHolder targetDate, 
	                                        final LocationHolder targetLocation, int period)
	{
		if (period <= 0) return null;
		
		EventProcessor processor = new ComingEventsProcessor(targetDate, targetLocation);
		
		Vector v = getEvents(processor, EVENT_REMINDER, false); 
		if (v == null || v.size() == 0) return null;
		
		EventData  evntData;
		DateHolder evntDate;
		int i=0, diff;
		
		do {
			evntData = (EventData) v.elementAt(i);
			evntDate =  evntData.eventDate;
			diff = evntDate.dateAbsolute - targetDate.dateAbsolute - 1;
			if (diff > period) return null;	
			i++;
		} while (diff <= 0);

		int evntIndex = (int) evntData.eventData[EventData.INDEX_NAMEIND];
		String eventName = EventData.getEventName(evntIndex, evntDate, 1);
		if (evntData.isKatan) eventName += MText.TitleKatan[1];
	/*
		if (evntData.isKatan) 
			// "Small" event
			eventName = EventData.getEventName(evntIndex, evntDate, 1) + MText.TitleKatan[1];
		else					
			// "Full" event
			eventName = EventData.getEventName(evntIndex, evntDate, 0);
	*/
		return eventName + ' ' +  MText.getInNightsText(diff);
	}	                                        


	public static Vector getEventNamesForDate(final DateHolder targetDateHolder,
	                                          final LocationHolder targetLocation,  boolean evalLightCandle)
	{
		int mask = EVENT_DISPLAYED | EVENT_HIGHLIGHTED | EVENT_EREV;
		DateEventsProcessor processor = new DateEventsProcessor(targetDateHolder, targetLocation, evalLightCandle);
		Vector result = getEvents(processor, mask, false);
		if (evalLightCandle) {
			if (processor.lightCandle)
				result.addElement ("ZL");  // candle light
			else
			if ((HebCalendar.getDayOfWeek(targetDateHolder.dateAbsolute) == HebCalendar.DOW_SHABBAT)
				|| checkHavdalahForDate(targetDateHolder, targetLocation, mask))	
				result.addElement("ZH");  // havdalah;
			 
		}	 
		return result;
		
	}

	private static boolean checkHavdalahForDate(final DateHolder targetDateHolder, 
						    final LocationHolder targetLocation, int mask)
	{
		
		DateHolder dh = new DateHolder(targetDateHolder);

		dh.incrementDay(1);
		
		Vector events = getEvents(new PastEventsProcessor(dh, targetLocation), mask, true);
		int eventCount = events.size();
		int index;
		int eventDuration, eventDurCandles, diff;
		byte candleFlags;
		byte[] eventData;
		
		EventData listElement;
		
		for (index = 0; index < eventCount; index++)
		{
			listElement = (EventData) events.elementAt(index);
			candleFlags = listElement.candleLightSettings;
			if ((candleFlags & CANDLE_MODE_MASK) == CANDLES_NONE) continue;      // Redundant, just a safeguard !
			
			eventDuration = 1;
			eventData = listElement.eventData;
			if (eventData.length > EventData.INDEX_DURATION)
				eventDuration = (int)eventData[EventData.INDEX_DURATION];
			eventDurCandles = 0;				
			if (eventData.length > EventData.INDEX_CANDLELIGHT) 
				eventDurCandles = (int)eventData[EventData.INDEX_CANDLELIGHT];
			if (eventDurCandles == 0)
				eventDurCandles = eventDuration;
	
			// Use base 1 for difference (so that day 0 is one 1 day difference from Erev)
			diff = targetDateHolder.dateAbsolute - listElement.eventDate.dateAbsolute+1;					

			if (diff > 0) {
				if ((diff == eventDurCandles) ||
				     ( ((candleFlags & CANDLES_FRAME) != 0)  && (diff == eventDuration))
				   ) return true;
					
			}	
		}
		
		return false;	
	}	


	private static Vector getEvents(EventProcessor processor, int mask, boolean candleLightOnly)
	{
		// Get year
		byte flags, candleFlags;
		int i, len, len1;
		byte[] curEventData;

		// Holidays
		byte[][] holidayData = getHolidayData(processor.targetLocation);
		len = holidayData.length;
		for (i=REGULAR_HOLIDAYS_START; i<len; i++) {
			flags = HolidaySettings[i];
			candleFlags = HolidayCandleLight[i];
			curEventData = holidayData[i];

			if ((flags & mask) != 0 &&
			    ((candleLightOnly == false) || ((candleFlags & CANDLE_MODE_MASK) != CANDLES_NONE))) {
				processor.processEvent(curEventData, flags, candleFlags, true, false);

				if (curEventData[INDEX_MONTH] == HebCalendar.ADAR2 && (flags & EventData.EVENT_KATAN) != 0)
					processor.processEvent(curEventData, flags, candleFlags, false, true);
			}		
		}

		// Rosh Chodesh		
		flags = HolidaySettings[ROSH_CHODESH_INDEX];
		candleFlags = HolidayCandleLight[ROSH_CHODESH_INDEX];
		if ((flags & mask) != 0 &&
		    ((candleLightOnly == false) || ((candleFlags& CANDLE_MODE_MASK) != CANDLES_NONE))) {
			curEventData = new byte[INDEX_DURATION];
			curEventData[INDEX_NAMEIND] = ROSH_CHODESH_INDEX;
			curEventData[INDEX_DAY] = 1;
			for (i=0; i<HebCalendar.MONTHS_PER_LEAP_YEAR; i++) {
				// 1 st of TISHRI is Rosh HaShanah and is not celebratred as RoshChodesh
				if (i != HebCalendar.TISHRI) {
					curEventData[INDEX_MONTH] = (byte) i;			
					processor.processEvent(curEventData, flags, candleFlags, false, false);
				}	
			}
		
		}

		// CustomEvents
		len = CustomEvents.size();
		
		for (i=0; i<len; i++) {
			flags = CustomEventSettings[i];
			candleFlags = CustomEventCandleLight[i];
			if ((flags & mask) != 0 &&
			    ((candleLightOnly == false) || ((candleFlags & CANDLE_MODE_MASK) != CANDLES_NONE))) {
				curEventData = (byte[]) (CustomEvents.elementAt(i));
				processor.processEvent(curEventData, flags, candleFlags, true, false);

				if (curEventData[INDEX_MONTH] == HebCalendar.ADAR2 && (flags & EventData.EVENT_KATAN) != 0)
					processor.processEvent(curEventData, flags, candleFlags, false, true);
			}
		}

		return processor.getEventList();
	}




	//====================================================================================
	// null no events
	// 0 - long, 1 - short
	public static  String getEventName(int nameIndex, final DateHolder dh, int isShort)
	{
		String text;
		
		if ((nameIndex & CUSTOM_FLAG) != 0) 
			text = getCustomEventName(nameIndex & ~CUSTOM_FLAG, isShort);
		else {	
			text = getHolidayName(nameIndex,isShort);	
			if (nameIndex == ROSH_CHODESH_INDEX) 
				text += " " + HebCalendar.getMonthName(dh.dateHebrew.month);
		}		
	
		return text;	
	}


	public String getEventName(int isShort)
	{
		return getEventName(eventData[INDEX_NAMEIND], eventDate, isShort);	
	}	

	//====================================================================================


	// Check for Rosh Chodesh entry. 
	// Welcomes any Rosh Chodesh entry, apart from AdarB in a non-leap year
//	private static boolean checkRoshChodesh(final DateHolder dHolder, byte[] event)
//	{
//		return (event[INDEX_NAMEIND] != ROSH_CHODESH_INDEX ||
//			event[INDEX_MONTH] < dHolder.hebMonthDurations.length);
//	
//	}

	public static void fixCustomEventReferences()
	{
		int len = EventData.CustomEvents.size();
		byte []evntData;
		
		for (int i=0; i<len; i++) {
			evntData = (byte[]) EventData.CustomEvents.elementAt(i);
			evntData[INDEX_NAMEIND] = (byte) (CUSTOM_FLAG | i);			
		}
	}

	// Shekalim, Zahor, Parah, HaChodesh, HaGadol
	private static final int[] ShabbatimPesach = {-43, -30, -21, -14, -1};
	private static final int[] ShabbatimTishaBAv = {0, 7};  // Hazon, Nachamu
	private static final int[] ShabbatimRoshHaShana = {7};	// Shuva

	public static final String getShabbatName(final DateHolder dateHolder, final LocationHolder locationHolder)
	{
		DateData date = dateHolder.dateHebrew;
		int[] ShabbatimRef = null;
		String[] ShabbatimNameRef = null;
		int month = date.month;
		int index = -1;
		
		
		if (month <= HebCalendar.NISSAN || month >= dateHolder.hebMonthDurations.length-1) {
			// Checking for Passover Shabatim
			ShabbatimRef = ShabbatimPesach;
			ShabbatimNameRef = MText.ShabbathPesachNames;
			index = PESACH_INDEX;
		} else
		if (month == HebCalendar.AV) {
			ShabbatimRef = ShabbatimTishaBAv;
			ShabbatimNameRef = MText.ShabbathTishaBAvNames;
			index = TISHABAV_INDEX;
		} else 
		if (month == HebCalendar.TISHRI) {
			ShabbatimRef = ShabbatimRoshHaShana;
			ShabbatimNameRef = MText.ShabbathRoshHaShanaNames;
			index = ROSHSHANA_INDEX;
		}
		
		if (ShabbatimRef == null) return null;
		
		int j;
		int len = ShabbatimRef.length;
		byte[] curEvent = getHolidayData(locationHolder)[index];
		int val;
		
		DateHolder holidayDay = new DateHolder();
		holidayDay.acceptHebrewDate(new DateData(curEvent[INDEX_DAY], curEvent[INDEX_MONTH], date.year), true);

		int difference = dateHolder.dateAbsolute - holidayDay.dateAbsolute;
		
		for ( j=0; j<len; j++) {
			val = ShabbatimRef[j];
			if (difference <= val && difference > val-HebCalendar.DAYS_PER_WEEK) 
				return MText.TitleShabbat + ShabbatimNameRef[j];
		}				
		
		return null;			

	}

	public static byte[][] getHolidayData(final LocationHolder lh)
	{
		return (lh.holidayStyle == LocationHolder.HSTYLE_ISRAEL) ? HolidaysIsrael : HolidaysDiaspora;	
	}


	public static int getHolidayCount()
	{
		return MText.HolidayNames.length;
	}

	public static String getHolidayName(int index, int longShort)
	{
		return MText.HolidayNames[index][longShort];
	}

	public static String getCustomEventName(int index, int longShort)
	{
		return ((String [])EventData.CustomEventNames.elementAt(index))[longShort];	
	}


	// Backward compatibility
	public static void setHolidayReminderToDefault()
	{
		int len = Math.min(HolidaySettings.length, DefaultFlags.length);
		for (int i=0; i<len; i++) {
			if ((DefaultFlags[i] & EVENT_REMINDER) != 0)
				HolidaySettings[i] |= EVENT_REMINDER;
		}	
	}	

	public static void setCustomEventReminderToDefault()
	{
		int len = CustomEventSettings.length;
		
		for (int i=0; i<len; i++) {
			if ((CustomEventSettings[i] & EVENT_HIGHLIGHTED) != 0)
			     CustomEventSettings[i] |= EVENT_REMINDER;
		}	
	}	
	

}

abstract class EventProcessor
{
	protected final DateHolder targetDateHolder;
	protected final LocationHolder targetLocation;
	protected Vector    eventList;

	EventProcessor(final DateHolder _targetDateHolder, final LocationHolder _targetLocation)
	{
		targetDateHolder = _targetDateHolder;
		targetLocation = _targetLocation;
		eventList = new Vector();
	}

	abstract boolean processEvent(final byte[] eventData, byte flags, byte candleFlags, boolean accomodate, boolean isKatan);

	Vector getEventList()
	{
		return eventList;
	}

	protected DateHolder acceptEventDate(int eventDay, int eventMonth, int eventYear, int variation, boolean accomodate)
	{
		DateHolder eventDateHolder = new DateHolder();

/*
		if (accomodate) {
			// Ensure that the date is accepted
			if (!eventDateHolder.acceptHebrewDate(new DateData(1, HebCalendar.TISHRI, eventYear))) return null;
			int[] monthDurations = eventDateHolder.hebMonthDurations;
			eventMonth = Math.min(eventMonth, monthDurations.length-1);
			eventDay = Math.min(eventDay, monthDurations[eventMonth]);		
		}
		
*/
		if (!eventDateHolder.acceptHebrewDate(new DateData(eventDay, eventMonth, eventYear), accomodate)) return null;

		int absDate = eventDateHolder.dateAbsolute;
		int dow = HebCalendar.getDayOfWeek(absDate);
		int increment  = 0;

		// Variate event
		switch(variation)
		{
			case EventData.VAR_SHAB_FORWARD:
				if (dow == HebCalendar.DOW_SHABBAT) increment = 1;
				break;
				
			case EventData.VAR_WEND_BACK:
				if (dow >= HebCalendar.DOW_WEEKEND) increment = -(dow-HebCalendar.DOW_WEEKEND+1);
				break;

			case EventData.VAR_PRE_WEND_BACK:
				dow++;
				if (dow >= HebCalendar.DOW_WEEKEND && dow <= HebCalendar.DOW_SHABBAT)
					increment = -(dow-HebCalendar.DOW_WEEKEND+1);
				break;
		}

		if (increment != 0)
			eventDateHolder.acceptAbsoluteDate(absDate + increment);						
		
		return eventDateHolder;
	}

}

class 	ComingEventsProcessor extends EventProcessor
{
	ComingEventsProcessor (final DateHolder _targetDateHolder, final LocationHolder _targetLocation)
	{
		super(_targetDateHolder, _targetLocation);
	}

	
	boolean processEvent(final byte[] eventData, byte flags, byte candleFlags, boolean accomodate, boolean isKatan)
	{

		int eventMonth = (int)eventData[EventData.INDEX_MONTH];
		if (isKatan)  {
			if (targetDateHolder.hebMonthDurations.length < HebCalendar.MONTHS_PER_LEAP_YEAR) return false;			
			eventMonth--;
		}	

		DateData targetDate = targetDateHolder.dateHebrew;
		int eventYear = targetDate.year;
		int eventDay = (int)eventData[EventData.INDEX_DAY];
		int targetMonth = targetDate.month;

		// Compare event date with targetDate		
		int diff = eventMonth - targetMonth;
		if (diff == 0) diff = eventDay - targetDate.day;
	
		if (diff > 0) {
			// Event date follows in the calendar
			// We increment the year only if TISHRI is in the middle
			if (targetMonth < HebCalendar.TISHRI && eventMonth >= HebCalendar.TISHRI)
				eventYear++;
		} else {
			// Event date preceeds in the calendar
			// Increment year if target Date is before TISHRI, or eventDate is after TISHRI				
			if (targetMonth < HebCalendar.TISHRI || eventMonth >= HebCalendar.TISHRI)
				eventYear++;
		}		

	//	int nameIndex = (int)eventData[EventData.INDEX_NAMEIND];
		int variation = (eventData.length > EventData.INDEX_VAR) ? eventData[EventData.INDEX_VAR] : 0;
		final DateHolder eventDateHolder = acceptEventDate(eventDay, eventMonth, eventYear, variation, accomodate);
		if (eventDateHolder == null) return false;
		insertEvent(eventData, eventDateHolder, candleFlags, isKatan);

		return true;
	}	

	private void insertEvent(final byte[] eventData, final DateHolder eventDateHolder, 
	                         byte candleFlags,  boolean isKatan)
	{
		
		EventData listElement;

		int curEventDateAbsolute = eventDateHolder.dateAbsolute;
		int index = eventList.size();

		// Find last date which is not greater than the new one
		while (--index >= 0) {
			listElement = (EventData) eventList.elementAt(index);
			if (listElement.eventDate.dateAbsolute <= curEventDateAbsolute) break;
		}
		
		listElement = new EventData(eventDateHolder, eventData, candleFlags, isKatan);
		eventList.insertElementAt(listElement, index+1);
	}	
}

		

class 	PastEventsProcessor extends EventProcessor
{
	PastEventsProcessor	(final DateHolder _targetDateHolder, final LocationHolder _targetLocation)
	{
		super(_targetDateHolder, _targetLocation);
	}	


	boolean processEvent(final byte[] eventData, byte flags, byte candleFlags, boolean accomodate, boolean isKatan)
	{
		int eventMonth = (int)eventData[EventData.INDEX_MONTH];
		if (isKatan)  {
			if (targetDateHolder.hebMonthDurations.length < HebCalendar.MONTHS_PER_LEAP_YEAR) return false;			
			eventMonth--;
		}	

		DateData targetDate = targetDateHolder.dateHebrew;

		int eventYear = targetDate.year;
		int eventDay = (int)eventData[EventData.INDEX_DAY];
		int targetMonth = targetDate.month;

		// Compare event date with targetDate		
		int diff = eventMonth - targetMonth;
		if (diff == 0) diff = eventDay - targetDate.day;
	
	
		if (diff < 0) {
			// Event date precedes in the calendar
			// We decrement year only if TISHRI is in the middle
			if (eventMonth < HebCalendar.TISHRI && targetMonth >= HebCalendar.TISHRI)
				eventYear--;
		} else {
			// Event date follows in the calendar
			// Decrement year event Date is before TISHRI, or targetDate is after TISHRI				
			if (eventMonth < HebCalendar.TISHRI || targetMonth >= HebCalendar.TISHRI)
				eventYear--;
		}		

		int nameIndex = (int)eventData[EventData.INDEX_NAMEIND];
		int variation = (eventData.length > EventData.INDEX_VAR) ? eventData[EventData.INDEX_VAR] : 0;

		DateHolder eventDateHolder = acceptEventDate(eventDay, eventMonth, eventYear, variation, accomodate);
		if (eventDateHolder == null) return false;
		insertEvent(eventData, eventDateHolder, candleFlags, isKatan);


		return true;
	}
	
	private void insertEvent(final byte[] eventData, final DateHolder eventDateHolder,
	                         byte candleFlags,  boolean isKatan)
	{
		int index = eventList.size();
		EventData listElement;
		int curEventDateAbsolute = eventDateHolder.dateAbsolute;

		// Find last date which is not less than the new one
		while (--index >= 0) {
			listElement = (EventData) eventList.elementAt(index);
			if (listElement.eventDate.dateAbsolute >= curEventDateAbsolute) break;
		}
		
		// Now insert the new date;
		listElement = new EventData(eventDateHolder, eventData, candleFlags, isKatan);
		eventList.insertElementAt(listElement, index+1);
		
	}	
}

class 	DateEventsProcessor extends EventProcessor
{
	public boolean needLightCandleEvaluation, lightCandle;

	DateEventsProcessor (final DateHolder _targetDateHolder,
			     final LocationHolder _targetLocation,
			     boolean _needLightCandleEvaluation)
	{
		super(_targetDateHolder, _targetLocation);
		needLightCandleEvaluation = _needLightCandleEvaluation;
		lightCandle = needLightCandleEvaluation 
		              ? (HebCalendar.getDayOfWeek (targetDateHolder.dateAbsolute) == HebCalendar.DOW_WEEKEND)
		              : false;
	}

	boolean processEvent(final byte[] eventData, byte flags, byte candleLightFlags, boolean accomodate, boolean isKatan)
	{
		
		int eventMonth = (int)eventData[EventData.INDEX_MONTH];
		if (isKatan)  {
			if (targetDateHolder.hebMonthDurations.length < HebCalendar.MONTHS_PER_LEAP_YEAR) return false;			
			eventMonth--;
		}	
		int eventDay = (int)eventData[EventData.INDEX_DAY];
		int eventIndex = (int)eventData[EventData.INDEX_NAMEIND];

		DateData targetDate = targetDateHolder.dateHebrew;
		int eventYear = targetDate.year;
		int targetMonth = targetDate.month;

		int eventDuration = 1;
		boolean eventIncluded = false;
		String eventName;

		if (eventData.length > EventData.INDEX_DURATION)
			eventDuration = (int)eventData[EventData.INDEX_DURATION];
		
		// So that we don't miss Erev Rosh HaShanah
		int[] monthDurations = targetDateHolder.hebMonthDurations;
		int monthCount = monthDurations.length;
		int eventType;

		// Adar B cannot refer to another year
		if (accomodate) 
			eventMonth = Math.min(eventMonth, monthCount-1);		

		int diff = eventMonth - targetMonth;
		
		// Handling roll-over
		if (diff > 1) diff -= monthCount; 
		else
		if (diff < -1) diff += monthCount; 

		if (diff > 0) {
			// Event month after target, must be 1st of next month	
			if (diff > 1 )return false;
			
			// We might have Erev
			if((eventDay > 1) || (flags & EventData.EVENT_EREV) == 0) return false;
			if (eventMonth == HebCalendar.TISHRI) eventYear++;		
		}	
		else
		if (diff < 0) {
			// Event month before target	
			if (diff < -1) // || eventDay+duration < monthDurations[eventMonth])
				return false;
			if (targetMonth >= HebCalendar.TISHRI && eventMonth < HebCalendar.TISHRI) eventYear--;		
		}			


		eventType = (eventData.length > EventData.INDEX_VAR) ? eventData[EventData.INDEX_VAR] : 0;
		DateHolder eventDateHolder = acceptEventDate(eventDay, eventMonth, eventYear, eventType, accomodate);
		if (eventDateHolder == null) return false;

		// Check for current day holiday			
		diff = targetDateHolder.dateAbsolute - eventDateHolder.dateAbsolute; 	
		if (diff < -1 && eventYear > 0) {
			eventDateHolder = acceptEventDate(eventDay, eventMonth, eventYear-1, eventType, accomodate);
			if (eventDateHolder == null) return false;
			diff = targetDateHolder.dateAbsolute - eventDateHolder.dateAbsolute; 	
		}	
		
		if (diff >= 0 && diff < eventDuration) {
			// Real holiday 
			if (isKatan) { 
				// "Small" event
				eventName = EventData.getEventName(eventIndex, eventDateHolder, 1) + MText.TitleKatan[0];
				eventType = (int) 'G';
			} else {					
				// "Full" event
				eventName = EventData.getEventName(eventIndex, eventDateHolder, 0);
				eventType = (int) 'A'; 					
			}				

			if (eventDuration > 1) eventName += MText.TxtHagDay + (diff+1);
			processEventName(flags, eventName, eventType);	// Plain
			eventIncluded = true;
		} else 				
		if (diff == -1) {
			if ((flags & EventData.EVENT_EREV) != 0) {
				// Erev (use short title)
				eventName = MText.TitleErev + EventData.getEventName(eventIndex, eventDateHolder, 1);
				eventType = (int) 'E'; 					
				if (isKatan) { eventName += MText.TitleKatan[1]; eventType = (int) 'G'; }					
				processEventName(flags, eventName, eventType);	// Erev
			}	
			eventIncluded = true;  // For candlelighting EVENT_EREV doesn't matter
		}

		// Candle lighting
		
		if (eventIncluded && needLightCandleEvaluation && 
			lightCandle == false &&
		        (candleLightFlags & EventData.CANDLE_MODE_MASK) != EventData.CANDLES_NONE &&
		         ++diff >= 0) {

			int eventCandleDuration = eventDuration;

			if (eventData.length > EventData.INDEX_CANDLELIGHT) {
				int eventCandleDuration1 = eventData[EventData.INDEX_CANDLELIGHT];
				if (eventCandleDuration1 != 0) {
					eventCandleDuration = eventCandleDuration1;
					if ( ((eventCandleDuration<<1) < eventDuration) &&					
					     ((candleLightFlags & EventData.CANDLES_FRAME) != 0)
					   ) diff %= (eventDuration-eventCandleDuration);
				}	
			}	

			if ((candleLightFlags & EventData.CANDLES_CONTINUOUS) == 0)
				lightCandle = (diff == 0);
			else
				lightCandle = (diff < eventCandleDuration);	

		}	
		
		
		return true;	
	}

	// type = 'A' - regular 'C' - katan, 'E' - erev  'G' - erev katan, 'Z' - candle light/havdalah
	void processEventName(byte flags, String eventName, int type)
	{
		if ((flags & EventData.EVENT_HIGHLIGHTED) == 0) type ++;
		char ctype = (char) type;
	
		int index = eventList.size();

		String listEventName;
		
		// Find last element with type less or equal to current
		while (--index >= 0) {
			listEventName = (String) eventList.elementAt(index);
			if (listEventName.charAt(0) <= ctype) break;
		}

		// Insert string
		eventList.insertElementAt(ctype+eventName, index+1);
	
	}

}
