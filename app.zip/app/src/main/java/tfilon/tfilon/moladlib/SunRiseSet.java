// ===========================================================
//  Molad
//  Hebrew(Jewish) calendar
//  (C) 2003-2006, Michael Glickman
//  ----------------------------------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------------
//  Sunrise / SunSet and other astronomic times  
//            CLDC 1.1 implementaion
//  ----------------------------------------------------------
//  The sunset algoritm originates from the following site:
//  NOAA Improved Sunser/Sunrise Calculation by
//  US National Oceanic and Atmospheric Administration
//  http://www.srrb.noaa.gov/highlights/sunrise/sunrise.html
//
//  The algorithm has been optimised and adapted to the
//  stucture of current application  MG
//  -----------------------------------------------------------
//  Started	28 September 2006
// ============================================================
// Modified by Ori Hollander
// Added elevation support based on KosherJava Zmanim API
// (c) 2011
package tfilon.tfilon.moladlib;

public final class SunRiseSet {

	public static boolean doublePath = true;
	public static boolean calcSolarNoon = false;
	private static final double zenithAngleSunRiseSetOfficial = 90 + 5 / 6d;
	private static double lastJD, lastLatitude,
			lastLongitude;
	private static double lastEqOfTimeNoon,
			lastSolarDecNoon;

	// *********************************************************
	//  Name:    calcTimeJulianCent
	//  Type:    Function
	//  Purpose: convert Julian Day to centuries since J2000.0.
	//  Arguments:
	//   jd : the Julian Day to convert
	//  Return value:
	//    the T value corresponding to the Julian Day
	// *********************************************************
	static private double calcTimeJulianCent(double jd) {
		return (jd - 2451545.0) / 36525.0;
	}

	// *********************************************************
	// Name:    calGeomMeanLongSun
	// Purpose: calculate the Geometric Mean Longitude of the Sun
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   the Geometric Mean Longitude of the Sun in degrees
	// *********************************************************
	static private double calcGeomMeanLongSun(double t) {
		return 280.46646 + t *
				(36000.76983 + 0.0003032 * t);
	}

	// ***********************************************************
	//  Name:    calGeomAnomalySun
	//  Purpose: calculate the Geometric Mean Anomaly of the Sun
	//  Arguments:
	//    t : number of Julian centuries since J2000.0
	//  Return value:
	//    the Geometric Mean Anomaly of the Sun in degrees
	// ************************************************************
	static private double calcGeomMeanAnomalySun(double t) {
		return 357.52911 + t *
				(35999.05029 - 0.0001537 * t);
	}

	// ************************************************************
	// Name:    calcEccentricityEarthOrbit
	// Type:    Function
	// Purpose: calculate the eccentricity of earth's orbit
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   the unitless eccentricity
	// ************************************************************
	static private double calcEccentricityEarthOrbit(double t) {
		return 0.016708634 - t *
				(0.000042037 + 0.0000001267 * t);
	}

	// *************************************************************
	// Name:    calcSunEqOfCenter
	// Purpose: calculate the equation of center for the sun
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   in degrees
	// **************************************************************
	static private double calcSunEqOfCenter(double t) {
		double m = calcGeomMeanAnomalySun(t);

		double mrad = Math.toRadians(m);
		double sinm = Math.sin(mrad);
		double sin2m = Math.sin(mrad + mrad);
		double sin3m = Math.sin(mrad + mrad + mrad);

		return sinm *
				(1.914602 - t *
						(0.004817 + 0.000014 * t)) +
				sin2m * (0.019993 - 0.000101 * t) +
				sin3m * 0.000289;
		// in degrees
	}

	// **************************************************************
	// Name:    calcSunTrueLong
	// Purpose: calculate the true longitude of the sun
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   sun's true longitude in degrees
	// **************************************************************
	static private double calcSunTrueLong(double t) {
		double l0 = calcGeomMeanLongSun(t);
		double c = calcSunEqOfCenter(t);

		return l0 + c; // in degrees
	}

	// ***************************************************************
	// Name:    calcSunTrueAnomaly
	// Purpose: calculate the true anamoly of the sun
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   sun's true anamoly in degrees
	// ***************************************************************
	static private double calcSunTrueAnomaly(double t) {
		double m = calcGeomMeanAnomalySun(t);
		double c = calcSunEqOfCenter(t);

		return m + c; // in degrees
	}

	// ****************************************************************
	// Name:    calcSunRadVector
	// Type:    Function
	// Purpose: calculate the distance to the sun in AU
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   sun radius vector in AUs
	// ****************************************************************
	static private double calcSunRadVector(double t) {
		double v = calcSunTrueAnomaly(t);
		double e = calcEccentricityEarthOrbit(t);

		return (1.000001018 * (1 - e * e)) /
				(1 + e * Math.cos(Math.toRadians(v)));
		// in AUs
	}

	// ****************************************************************
	// Name:    calcSunApparentLong
	// Type:    Function
	// Purpose: calculate the apparent longitude of the sun
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   sun's apparent longitude in degrees
	// ****************************************************************
	static private double calcSunApparentLong(double t) {
		double o = calcSunTrueLong(t);

		double omega = 125.04 - 1934.136 * t;
		return o - 0.00569 - 0.00478 *
				Math.sin(Math.toRadians(omega));
		// in degrees
	}

	// ****************************************************************
	//  Name:    calcObliquityCorrection
	//  Type:    Function
	//  Purpose: calculate the corrected obliquity of the ecliptic
	//  Arguments:
	//    t : number of Julian centuries since J2000.0
	//  Return value:
	//    corrected obliquity in degrees
	// ****************************************************************
	static private double calcObliquityCorrection(double t) {
		// Find Mean Oliquity of Ecliptics (e0)
		double seconds = 21.448 -
				t *
				(46.8150 + t *
						(0.00059 - t * (0.001813)));
		double e0 = 23.0 + (26.0 + (seconds / 60.0)) / 60.0;

		double omega = 125.04 - 1934.136 * t;
		return e0 + 0.00256 *
				Math.cos(Math.toRadians(omega)); // in degrees
	}

	// ************************************************************
	// Name:    calcSunRtAscension
	// Purpose: calculate the right ascension of the sun
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   sun's right ascension in degrees
	// *************************************************************
	//static private double calcSunRtAscension(double t)
	//{
	//	double e = calcObliquityCorrection(t);
	//	double lambda = calcSunApparentLong(t);
	//
	//	double tananum = (Math.cos(MathE.toRadians(e)) * Math.sin(Math.toRadians(lambda)));
	//	double tanadenom = (Math.cos(MathE.toRadians(lambda)));
	//	return Math.toDegrees(MathE.atan2(tananum, tanadenom)); // in degrees
	//}
	// ***************************************************************
	// Name:    calcSunDeclination
	// Type:    Function
	// Purpose: calculate the declination of the sun
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   sun's declination in radians
	//****************************************************************
	static private double calcSunDeclination(double t) {
		double e = calcObliquityCorrection(t);
		double lambda = calcSunApparentLong(t);

		double sint = Math.sin(Math.toRadians(e)) *
				Math.sin(Math.toRadians(lambda));
		return MathE.asin(sint); // in radians
	}

	//*********************************************************************
	// Name:    calcEquationOfTime
	// Purpose: calculate the difference between true solar time and mean
	//		solar time
	// Arguments:
	//   t : number of Julian centuries since J2000.0
	// Return value:
	//   equation of time in seconds of time
	// ********************************************************************
	static private double calcEquationOfTime(double t) {
		double epsilon = calcObliquityCorrection(t);
		double l0 = calcGeomMeanLongSun(t);
		double e = calcEccentricityEarthOrbit(t);
		double m = calcGeomMeanAnomalySun(t);
		double y = Math.tan(Math.toRadians(epsilon) / 2.0);
		y *= y;

		double sin2l0 = Math.sin(2.0 * Math.toRadians(l0));
		double sinm = Math.sin(Math.toRadians(m));
		double cos2l0 = Math.cos(2.0 * Math.toRadians(l0));
		double sin4l0 = Math.sin(4.0 * Math.toRadians(l0));
		double sin2m = Math.sin(2.0 * Math.toRadians(m));

		double Etime = y * sin2l0 - 2.0 * e * sinm +
				4.0 * e * y * sinm * cos2l0
				- 0.5 * y * y * sin4l0 - 1.25 * e * e *
				sin2m;

		return Math.toDegrees(Etime) * 240.0; // in seconds of time
	}

	// ********************************************************************
	//  Name:    calcSolNoonUTC
	//  Purpose: calculate the Universal Coordinated Time (UTC) of solar
	// 		noon for the given day at the given location on earth
	//  Arguments:
	//    JD : Julian Day
	//    longitude : longitude of observer in degrees
	//  Return value:
	//    time in minutes from zero Z
	//*********************************************************************

	static private double calcSolNoonUTC(double jd, double longitude) {
		// First pass uses approximate solar noon to calculate eqtime
		double tnoon = calcTimeJulianCent(jd + 0.5 +
				longitude / 360.0);
		double eqTime = calcEquationOfTime(tnoon);
		double solNoonUTC = (180. + longitude) * 240. -
				eqTime; // min

		if (doublePath) {
			double newt = calcTimeJulianCent(jd +
					solNoonUTC / 86400.0);
			eqTime = calcEquationOfTime(newt);
			// var solarNoonDec = calcSunDeclination(newt);
			solNoonUTC = (180. + longitude) * 240. -
					eqTime; // min
		}

		return solNoonUTC;
	}

	// *******************************************************************
	//  Name:    calcHourAngle
	//  Purpose: calculate the hour angle of the sun at sunrise for the
	// 			latitude
	//  Arguments:
	//    lat : latitude of observer in degrees
	//    solarDec : declination angle of sun in radians
	//    zenithAngle: angle from zenith position (M.G.)
	//    sunset:   true - calculate sunset
	//              false - calculate sunrise
	//  Return value:
	//    hour angle of sunrise in degrees
	//********************************************************************
	private static double calcHourAngle(double lat, double sdRad, double zenithAngle) {
		double HA = Double.NaN;

		if (!Double.isNaN(sdRad)) {
			double latRad = Math.toRadians(lat);

			double HAarg = Math.cos(Math.toRadians(zenithAngle)) /
					(Math.cos(latRad) * Math.cos(sdRad))
					- Math.tan(latRad) * Math.tan(sdRad);

			HA = MathE.acos(HAarg);

			if (!Double.isNaN(HA)) {
				HA = Math.toDegrees(HA);
				// For sunset, the result should be negated - M.G.
				if (zenithAngle < 0) {
					HA = -HA;
				}
			}
		}

		return HA; // in degrees
	}

	// *********************************************************************
	// Name:    calcSunRiseSetUTC
	// Type:    Function
	// Purpose: calculate the Universal Coordinated Time (UTC) of sunrise/sunset
	//			for the given day at the given location on earth
	// Arguments:
	//   JD  : julian day
	//   latSec : latitude of observer in seconds
	//   longitude : longitude of observer in seconds
	//   sunset:  true - calculate sunset
	//            false - calculate sunrise
	// Return value:
	//   time in minutes from zero Z
	// *********************************************************************
	static final public void calcSunRiseSetUTC(int dateAbsolute, int latSec, int longSec, int elevation, int[] result) {
		lastJD = dateAbsolute + 347997.0;
		lastLatitude = latSec / 3600.;
		lastLongitude = longSec / -3600.;

		//double t = calcTimeJulianCent(JD);

		// *** Find the time of solar noon at the location, and use
		//     that declination. This is better than start of the
		//     Julian day

		double tnoon;

		if (calcSolarNoon) {
			double noonmin = calcSolNoonUTC(lastJD, lastLongitude);
			tnoon = calcTimeJulianCent(lastJD + noonmin /
					86400.0);
		} else {
			tnoon = calcTimeJulianCent(lastJD + 0.5 +
					lastLongitude / 360.0);
		}

		// *** First pass to approximate sunrise (using solar noon)
		lastEqOfTimeNoon = calcEquationOfTime(tnoon);
		lastSolarDecNoon = calcSunDeclination(tnoon);

		double angle = calcHourAngle(lastLatitude, lastSolarDecNoon, getZenithForElevation(elevation));
		double timeUTC;

		if (Double.isNaN(angle)) {
			result[0] =
					result[1] = Integer.MIN_VALUE;
		} else if (doublePath) {
			double newSolarDec, newEqTime, newt, newAngle, timeDiff;

			for (int i = 0; i < 2; i++) {
				timeDiff = ((i == 0) ? lastLongitude -
						angle : lastLongitude + angle);
				timeUTC = (180. + timeDiff) * 240. -
						lastEqOfTimeNoon; // in minutes

				// *** Second pass includes fractional jday in gamma calc

				newt = calcTimeJulianCent(lastJD +
						timeUTC / 86400.);
				newEqTime = calcEquationOfTime(newt);
				newSolarDec = calcSunDeclination(newt);

				newAngle = calcHourAngle(lastLatitude, newSolarDec, getZenithForElevation(elevation));

				if (Double.isNaN(newAngle)) {
					result[i] = Integer.MIN_VALUE;
				} else {
					timeDiff = ((i == 0) ? lastLongitude -
							newAngle : lastLongitude +
							newAngle);
					timeUTC = (180. + timeDiff) * 240. -
							newEqTime; // in minutes
					result[i] = (int) timeUTC;
				}
			}
		} else {
			timeUTC = (180. + lastLongitude - angle) *
					240. - lastEqOfTimeNoon;
			result[0] = (int) timeUTC;
			result[1] = (int) (timeUTC + angle * 480.);
		}
	}

	// *********************************************************************
	// Name:    recalcZenithAngleUTC
	// Type:    Function
	// Purpose: calculate the Universal Coordinated Time (UTC) corresponding
	//	    to sun elevation specified as the angle from noon
	// Arguments:
	//   JD  : julian day
	//   latSec : latitude of observer in degrees
	//   longSec : longitude of observer in degrees
	//   zenithAngSec:  zenith angle in seconds
	//           (this is the angle between sun at noon time, and current )
	//======================================================================
	// FYI: JD, latitude and longitude are assumed to be the same as at
	//      the last call to calcSunRiseSetUTC. This is done in order to
	//      avoid recalculating EquationOfTime and SolarDeclination
	//======================================================================
	// Return value:
	//   time in minutes from zero Z
	// *********************************************************************
	static final public int recalcZenithAngleUTC(int zenithAngSec) {

		double zenithAngle = zenithAngSec / 3600.;

		//double t = calcTimeJulianCent(JD);

		// *** First pass to approximate sunrise (using solar noon)
		double angle = calcHourAngle(lastLatitude, lastSolarDecNoon, zenithAngle);
		if (Double.isNaN(angle)) {
			return Integer.MIN_VALUE;
		}

		double timeDiff = lastLongitude + angle;
		double timeUTC = (180. + timeDiff) * 240. -
				lastEqOfTimeNoon; // in seconds

		if (doublePath) {
			// *** Second pass gives a more accurate result
			double newt = calcTimeJulianCent(lastJD +
					timeUTC / 86400.);
			double newEqTime = calcEquationOfTime(newt);
			double newSolarDec = calcSunDeclination(newt);

			angle = calcHourAngle(lastLatitude, newSolarDec, zenithAngle);
			if (Double.isNaN(angle)) {
				return Integer.MIN_VALUE;
			}

			timeDiff = lastLongitude + angle;
			timeUTC = (180 + timeDiff) * 240. -
					newEqTime; // in seconds
		}

		return (int) timeUTC;
	}

	public static double getZenithForElevation(double elevation) {
		double earthRadius = 6356.9;
		double elevationAdjustment = Math.toDegrees(MathE.acos(earthRadius /
				(earthRadius + (elevation / 1000d))));
		return zenithAngleSunRiseSetOfficial +
				elevationAdjustment;
	}
}
