// =====================================================
//  Molad
//  Hebrew(Jewish) calendar
//  (C) 2003-2006, Michael Glickman
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//	------------------------------------------------------------------
//	Date Unilities
//	11 November 2003	
// ===================================================================

package tfilon.tfilon.moladlib;
import java.util.*;



//============================================================================
// Hold Hebrew, Secular and absolute dates, and some data
public class DateHolder
{

	public DateData  dateHebrew;
	public DateData  dateSecular;
	public int dateAbsolute;				// Absolute date
	
	public boolean isGregorian;
	public boolean alwaysJulian;

	public int hebNewYearAbsolute;			// Absolute date of Rosh HaShana
	public int secNewYearAbsolute;			// Absolute date of Calendar month start
//	public int minYearSecular;

	public int hebYearStartLunarDays; 
	public int hebYearStartLunarParts;

	public int hebMonthDurations[];		// Hebrew month durations

	public DateHolder()
	{
		dateHebrew = null;
		dateSecular = null;	
		hebMonthDurations = null;
		secNewYearAbsolute = 
		hebNewYearAbsolute = dateAbsolute= -1;
//		minYearSecular = SecularCalendar.MIN_YEAR_SECULAR_DEFAULT;
		isGregorian = false;
		alwaysJulian = false;
	}

	public DateHolder(DateHolder _other)
	{
		this();
		set(_other);
	}

	public void set(DateHolder other)
	{
		// That's OK because we never overwrite actual data
		dateHebrew = other.dateHebrew;		
		dateSecular = other.dateSecular;		
//		dateHebrew.set(other.dateHebrew);		
//		dateSecular.set(other.dateSecular);		

		dateAbsolute = other.dateAbsolute;
		hebNewYearAbsolute = other.hebNewYearAbsolute;
		secNewYearAbsolute = other.secNewYearAbsolute;
		isGregorian = other.isGregorian;
		alwaysJulian = other.alwaysJulian;
		hebYearStartLunarDays = other.hebYearStartLunarDays;
		hebYearStartLunarParts = other.hebYearStartLunarParts;
//		minYearSecular = other.minYearSecular;
		
		// See comment above
		hebMonthDurations = other.hebMonthDurations;
	}

	public boolean acceptCurrentDate()
	{
		Calendar clnd = Calendar.getInstance();
		clnd.setTime(new Date());
		return acceptCalendarDate(clnd);
	} 

	public boolean acceptCalendarDate(final Calendar clnd)
	{
		return acceptSecularDate(new DateData(clnd.get(Calendar.DAY_OF_MONTH),
		                      clnd.get(Calendar.MONTH), clnd.get(Calendar.YEAR)));
	
	}


/*
	boolean acceptSecularDate(DateData newDate, boolean isEndJulian)
	{
		if (isEndJulin && newDate.year < MIN_YEAR_GREGORIAN) return false;
		
		return acceptSecularDate(newDate);
	}
*/

	public boolean acceptSecularDate(DateData newDate)
	{
		boolean result = SecularCalendar.toAbsolute(this, newDate) &&
		  	         HebCalendar.fromAbsolute(this, dateAbsolute);

		// Correction for a date "between calendars"				 
		if (result && alwaysJulian==false) {
			int gregStart = EventData.gregorianStart.dateAbsolute;
			boolean consistent = (dateAbsolute > gregStart);
			if (isGregorian == false) consistent = !consistent;
			if (consistent == false) {
				if (isGregorian) gregStart++;
				result = acceptAbsoluteDate(gregStart);
			}	
		}		
				
		return result;										 

	}

	public boolean acceptHebrewDate(DateData newDate, boolean autoCorrection)
	{
		return HebCalendar.toAbsolute(this, newDate, autoCorrection) &&
			   SecularCalendar.fromAbsolute(this, dateAbsolute);
	}


	public boolean acceptAbsoluteDate(int newAbsolute)
	{
		return HebCalendar.fromAbsolute(this, newAbsolute) &&
			   SecularCalendar.fromAbsolute(this, newAbsolute);
	}	

	public boolean  incrementDay(int increm)
	{
		return acceptAbsoluteDate(dateAbsolute + increm);
	}


	// Assuming increment is +1 or -1
	public boolean  incrementHebMonth(int increm)
	{
		DateData newDateHebrew = new DateData(dateHebrew);
		int newMonth = newDateHebrew.month += increm;
		int monthCount = hebMonthDurations.length;
		int year = newDateHebrew.year;

		if (increm < 0) {
			if (newMonth == (HebCalendar.TISHRI-1))
				newDateHebrew.year--;
			else
			if (newMonth < 0) 
				newMonth = monthCount - 1;
		} else {
			if (newMonth == HebCalendar.TISHRI)
				newDateHebrew.year++;
			else
			if (newMonth >= monthCount) 
				newMonth = 0;		
		}	
		
		newDateHebrew.month = newMonth;
		return acceptHebrewDate(newDateHebrew, true);
	}	

	public boolean incrementSecMonth(int increm)
	{
		DateData newDateSecular = new DateData(dateSecular); 
		int newMonth = newDateSecular.month += increm;
		int monthCount = SecularCalendar.MONTHS_IN_YEAR;

		if (newMonth < 0) {
			newDateSecular.year--;
			newMonth = SecularCalendar.MONTHS_IN_YEAR - 1;
		} else 
		if (newMonth >= SecularCalendar.MONTHS_IN_YEAR) {
			newDateSecular.year++;
			newMonth = 0;		
		}	
		
		newDateSecular.month = newMonth;
		return acceptSecularDate(newDateSecular);
	}


	public boolean incrementHebYear(int increm)
	{
		DateData newDateHebrew = new DateData(dateHebrew); 
		newDateHebrew.year += increm;
		return acceptHebrewDate(newDateHebrew, true);
	}

	public boolean  incrementSecYear(int increm)
	{
		DateData newDateSecular = new DateData(dateSecular); 
		newDateSecular.year += increm;
		return acceptSecularDate(newDateSecular);
	}


	public boolean acceptHebYear(int newYear)
	{
		DateData newDateHebrew = new DateData(dateHebrew); 
		newDateHebrew.year = newYear;
		return acceptHebrewDate(newDateHebrew, true);
	}

	public boolean  acceptSecYear(int newYear)
	{
		DateData newDateSecular = new DateData(dateSecular); 
		newDateSecular.year = newYear;
		return acceptSecularDate(newDateSecular);
	}

	
}