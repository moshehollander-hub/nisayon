// =====================================================
//  Molad
//  Hebrew(Jewish) calendar
//  (C) 2003-2006, Michael Glickman
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ----------------------------------------------------
//  LocationHolder class 
//  Constains lacation details
//  ----------------------------------------------------
//  If the following code is used in your application, 
//  the references are expected.
//  ----------------------------------------------------
//  Started	3 October 2006 
// =====================================================
// Modified by Ori Hollander
// Added elevation support
// (c) 2011
package tfilon.tfilon.moladlib;

import java.io.*;
import java.util.*;

public class LocationHolder {

	public static final int NAME_LENGTH_MAX = 25;
	public static final int HSTYLE_ISRAEL = 0;
	public static final int HSTYLE_DIASPORA = 1;
	private static final int MINUTES_PER_DAY = 1440;
	public static final int MINUTES_PER_HOUR = 60;
	public static final int MILLISEC_PER_MINUTE = 60000;
	private static final int SECONDS_PER_DEGREE = 3600;
	private static final int SECONDS_PER_MINUTE = 60;
	private static final int SECONDS_PER_HOUR = MINUTES_PER_HOUR *
			SECONDS_PER_MINUTE;
	private static final int SECONDS_PER_DAY = MINUTES_PER_DAY *
			SECONDS_PER_MINUTE;
	private static final int DST_INCREASE = SECONDS_PER_HOUR;
	private static final int LONGITUDE_PER_TIMEZONE_RATIO = 900; // 3600*(360/1400)
	public static final int MAX_LONGITUDE_DEGREES = 180;
	public static final int MAX_LATITUDE_DEGREES = 90;
	public static final int MAX_SECONDS = 59;
	public static final int MAX_MINUTES = 59;
	private static final int TIME_ZONE_TOLERANCE_MAX = 120; // 2 hours
	private static final int TIME_ZONE_TOLERANCE_MIN = -60; // 1 hour
	public static final int DST_FIRST_IN_MONTH = 0; // DOW in month
	public static final int DST_SECOND_IN_MONTH = 1;
	public static final int DST_THIRD_IN_MONTH = 2;
	public static final int DST_FOURTH_IN_MONTH = 3;
	public static final int DST_SECOND_LAST_IN_MONTH = 4;
	public static final int DST_LAST_IN_MONTH = 5;
	public static final int DST_FIRST_AFTER = 6;
	public static final int DST_LAST_BEFORE = 7;
	public static final int DST_SPECIFIC = 8;
	public static final int DST_STARTEND_MODE_COUNT = 9;
	public static final int DST_NON_MONTHLY = DST_FIRST_AFTER;
	public static final int DST_INDEX_MODE = 0; // MODE
	public static final int DST_INDEX_DOW = 1; // DOW
	public static final int DST_INDEX_DAY = 2; // Day of month
	public static final int DST_INDEX_MONTH = 3; // Month
	public static final int DST_INDEX_CAL = 4; // Calendar type
	public static final int DST_PERIOD_SIZE = 5;
	// Daylight saving (Summner Time) constants
	public static final int DST_MODE_OFF = 0;
	public static final int DST_MODE_ON = 1;
	public static final int DST_MODE_SYSTEM = 2;
	public static final int DST_MODE_CUSTOM = 3;
	public static final int DST_MODE_COUNT = 4;
	//	private static final int MAX_LONGITUDE = MAX_LONGITUDE_DEGREES * SECONDS_PER_DEGREE;
	//	private static final int MAX_LATITUDE  = MAX_LATITUDE_DEGREES * SECONDS_PER_DEGREE;
	private static final int latitudeJerusalem = coordSecs(31, 47, 0);
	public byte holidayStyle;
	public boolean timeScale12;
	private int latitude, longitude, tmeZone = 0,
			elevation = 0;
	// Daylight Saving
	public int dstMode;
	public byte[][] DSTperiod;
	private boolean dstCurrent; // set after getSunRiseSet
	private boolean dstCurrentChanged;
	private int lastSunRiseSetDate;
	private int[] sunRiseSetTimes = null; // Sunrise, sunset
	public String name;
	// Details top index:  0-for start, 1-for end
	// Details[][0] - mode (see DST_MODE),
	// Details[][1] - day of week
	// Details[][2] - day in month,
	// Details[][3] - month
	// Details[][4] - calendar type: 0-hebrew, 1-secular
	private static final byte[][] DSTperiodDefault = { { DST_SPECIFIC, 0, 1, SecularCalendar.APRIL, 1 }, // Start : 1st April
	{ DST_FIRST_IN_MONTH, SecularCalendar.INDEX_SUNDAY, 1, HebCalendar.TISHRI, 0 }
	}; // End :1st Sunday after Rosh Ha Shana

	//----------------------------------------------------------------
	public LocationHolder() {
		holidayStyle = HSTYLE_ISRAEL;

		// Guess location from Device
		try {
			//TimeZone tz = TimeZone.getDefault();
			tmeZone = 0;
		} catch (Exception ex) {
			tmeZone = 0;
		}

		name = MText.TxtNameDefault;
		dstMode = DST_MODE_SYSTEM;
		timeScale12 = false;
		latitude = latitudeJerusalem;
		longitude = tmeZone *
				LONGITUDE_PER_TIMEZONE_RATIO;

		DSTperiod = new byte[2][DST_PERIOD_SIZE];
		acceptDSTPeriod(DSTperiodDefault);

		sunRiseSetTimes = new int[3];

		dstCurrent = false;
		dstCurrentChanged = true;
		lastSunRiseSetDate = -1;

	}

	public LocationHolder(final LocationHolder other) {
		DSTperiod = new byte[2][DST_PERIOD_SIZE];
		sunRiseSetTimes = new int[3];

		transferData(other);

		lastSunRiseSetDate = -1;
		dstCurrentChanged = true;
	}

	public void set(final LocationHolder other) {
		if (latitude != other.latitude
				|| longitude != other.longitude ||
				elevation != other.elevation) {
			invalidateSunTimes();
		}

		if (other.dstMode != dstMode) {
			dstCurrentChanged = true;
		}

		transferData(other);

	}

	private void transferData(final LocationHolder other) {
		name = new String(other.name);

		acceptDSTPeriod(other.DSTperiod);

		holidayStyle = other.holidayStyle;
		timeScale12 = other.timeScale12;

		latitude = other.latitude;
		longitude = other.longitude;
		elevation = other.elevation;
		tmeZone = other.tmeZone;

		dstMode = other.dstMode;
		dstCurrent = other.dstCurrent;
	}

	public boolean isChanged(final LocationHolder other) {
		return holidayStyle != other.holidayStyle
				||
				timeScale12 != other.timeScale12
				||
				dstMode != other.dstMode
				||
				latitude != other.latitude
				||
				longitude != other.longitude
				||
				elevation != other.elevation
				||
				tmeZone != other.tmeZone
				||
				name.compareTo(other.name) != 0
				||
				(dstMode == DST_MODE_CUSTOM && isChangedDSTPeriod(other.DSTperiod));
	}

	//----------------------------------------------------------------
	// Static methods
	private static int coordSecs(int degrees, int minutes, int seconds) {
		return degrees * SECONDS_PER_DEGREE + minutes *
				SECONDS_PER_MINUTE + seconds;
	}

	private static void coordDMS(int coord, int[] dms) {
		dms[0] = coord / SECONDS_PER_DEGREE; // degrees
		coord %= SECONDS_PER_DEGREE;
		dms[1] = coord / SECONDS_PER_MINUTE; // minutes
		dms[2] = coord % SECONDS_PER_MINUTE; // seconds
	}

	// Converts latitude to seconds
	// latDMSH: [0]-degrees, [1]-minutes, [2]-seconds, [3]-hemisphere: 0-north, 1- south
	private static int packLatitude(final int[] latDMSH) {
		int result = coordSecs(latDMSH[0], latDMSH[1], latDMSH[2]);
		if (latDMSH[3] > 0) {
			result = -result;
		}
		return result;
	}

	// Converts longitude to seconds
	// LongDMS: [0]-degrees, [1]-minutes, [2]-seconds,  [3]-hemisphere: 0-east, 1-west
	private static int packLongitude(final int[] longDMSH) {
		int result = coordSecs(longDMSH[0], longDMSH[1], longDMSH[2]);
		if (longDMSH[3] > 0 &&
				longDMSH[0] < MAX_LONGITUDE_DEGREES) {
			result = -result;
		}
		return result;
	}

	public static void unpackCoordinate(int coordValue, int[] resDMSH) {
		if (coordValue < 0) {
			resDMSH[3] = 1;
			coordValue = -coordValue;
		} else {
			resDMSH[3] = 0;
		}
		coordDMS(coordValue, resDMSH);
	}

	// tzHMD [0] - hours, [1]-minutes, [2]-direction: 0 ahead UTC, 1 - behind UTC
	private static int packTimeZone(final int[] tzHMD) {
		int result = tzHMD[0] * MINUTES_PER_HOUR +
				tzHMD[1];
		if (tzHMD[2] > 0) {
			result = -result;
		}
		return result;
	}

	// resHMD: [0]-Hours, [1]-Minutes, [2]-direction: 0-ahead UT, 1-behind UT
	private static void unpackTimeZone(int tzValue, int[] resHMD) {
		if (tzValue < 0) {
			tzValue = -tzValue;
			resHMD[2] = 1;
		} else {
			resHMD[2] = 0;
		}

		resHMD[0] = tzValue / MINUTES_PER_HOUR;
		resHMD[1] = tzValue % MINUTES_PER_HOUR;
	}

	// latDMSH: [0]-degrees, [1]-minutes, [2]-seconds, [3]-hemisphere: 0-north, 1- south
	public static boolean checkLatitude(final int[] latDMS) {
		int degrees = latDMS[0];
		int minutes = latDMS[1];
		int seconds = latDMS[2];

		// Hemisphere is actually unused ...
		return minutes >= 0 &&
				minutes <= MAX_MINUTES
				&&
				seconds >= 0 &&
				seconds <= MAX_SECONDS
				&&
				degrees >= 0
				&&
				(degrees < MAX_LATITUDE_DEGREES
				|| (degrees + minutes + seconds) == MAX_LATITUDE_DEGREES);
	}

	//----------------------------------------------------------------
	// latDMSH: [0]-degrees, [1]-minutes, [2]-seconds, [3]-hemisphere: 0-north, 1- south
	public boolean acceptLatitude(final int[] latDMS) {
		if (checkLatitude(latDMS)) {
			latitude = packLatitude(latDMS);
			invalidateSunTimes(); // Force regenerating sun rise/set times
			return true;
		}
		return false;
	}

	// Returns [0]-degrees, [1]-minutes, [2]-seconds, [3]-hemisphere: 0-north, 1-south
	public int[] getLatitude() {
		int[] latitudeDMSH = new int[4];
		unpackCoordinate(latitude, latitudeDMSH);
		return latitudeDMSH;
	}

	public boolean isSouth() {
		return (latitude < 0);
	}

	//	public int getLatitudeSeconds ()
	//	{
	//		return latitude;	
	//	}	
	//----------------------------------------------------------------
	// longDMSH: [0]-degrees, [1]-minutes, [2]-seconds
	public static boolean checkLongitude(final int[] longDMS) {
		int degrees = longDMS[0];
		int minutes = longDMS[1];
		int seconds = longDMS[2];

		// Hemisphere is actually unused ...
		return minutes >= 0 &&
				minutes <= MAX_MINUTES
				&&
				seconds >= 0 &&
				seconds <= MAX_SECONDS
				&&
				degrees >= 0
				&&
				(degrees < MAX_LONGITUDE_DEGREES
				|| (degrees + minutes + seconds) == MAX_LONGITUDE_DEGREES);
	}

	// longDMSH: [0]-degrees, [1]-minutes, [2]-seconds, [3]-hemisphere: 0-east, 1- west
	public boolean acceptLongitude(final int[] longDMS) {
		if (checkLongitude(longDMS)) {
			longitude = packLongitude(longDMS);
			invalidateSunTimes(); // Force regenerating sun rise/set times
			return true;
		}
		return false;
	}

	public int[] getLongitude() {
		int[] longitudeDMSH = new int[4];
		unpackCoordinate(longitude, longitudeDMSH);
		return longitudeDMSH;
	}

	//	public int getLongitudeSeconds ()
	//	{
	//		return longitude;	
	//	}	
	public boolean isWest() {
		return (longitude < 0);
	}

	public void acceptElevation(final int elevation) {
		this.elevation = elevation;
		invalidateSunTimes();
	}

	public int getElevation() {
		return elevation;
	}

	//----------------------------------------------------------------
	// Side 0 - UTC+  1 - UTC-
	public void acceptTimeZone(final int[] tzHMD) {
		tmeZone = packTimeZone(tzHMD);
	}

	public void acceptTimeZone(int newZone) {
		tmeZone = newZone;
	}

	// Returns time zone in minutes;
	public int getTimeZonePacked() {
		return tmeZone;
	}

	public int[] getTimeZone() {
		int[] timeZoneHMD = new int[3];
		unpackTimeZone(tmeZone, timeZoneHMD);
		return timeZoneHMD;
	}

	//----------------------------------------------------------------------
	// For internal use only
	public void acceptInternalCoordinates(int newLatitude, int newLongitude) {
		latitude = newLatitude;
		longitude = newLongitude;
		invalidateSunTimes();
	}

	public void invalidateSunTimes() {
		lastSunRiseSetDate = -1;
	}

	private void processSunDate(final DateHolder dh) {
		int dateAbsolute = dh.dateAbsolute;

		if (dateAbsolute != lastSunRiseSetDate) {
			SunRiseSet.calcSunRiseSetUTC(dateAbsolute, latitude, longitude, elevation, sunRiseSetTimes);
			lastSunRiseSetDate = dateAbsolute;
			if (dstMode == DST_MODE_CUSTOM) {
				dstCurrentChanged = true;
			}
		}

		dstCurrent = getCurrentDST(dh);
	}

	public int timeUTCtoLocal(int t) {
		if (t == Integer.MIN_VALUE) {
			return t;
		}
		t += tmeZone * SECONDS_PER_MINUTE;
		if (dstCurrent) {
			t += DST_INCREASE;
		}
		return (t < 0) ? SECONDS_PER_DAY -
				((-t) % SECONDS_PER_DAY) : t %
				SECONDS_PER_DAY;
	}

	// Returns local time in minutes from midnight
	public int getSunRiseTime(final DateHolder dh) {
		processSunDate(dh);
		return timeUTCtoLocal(sunRiseSetTimes[0]);
	}

	public int getSunSetTime(final DateHolder dh) {
		processSunDate(dh);
		return timeUTCtoLocal(sunRiseSetTimes[1]);
	}

	// Rise angle is given in seconds (1' is 1/3600 of a degree)
	public int getTimeForElevation(final DateHolder dh, int elevation) {
		processSunDate(dh);
		int timeUTC = SunRiseSet.recalcZenithAngleUTC(elevation);
		return timeUTCtoLocal(timeUTC);
	}

	public int getTimeForDayPart(final DateHolder dh, int numerator, int denominator) {
		processSunDate(dh);
		int result = sunRiseSetTimes[0];
		if (result != Integer.MIN_VALUE &&
				denominator != 0) {
			result += (sunRiseSetTimes[1] - result) *
					numerator / denominator;
		}
		return timeUTCtoLocal(result);
	}

	//-----------------------------------------------------------------
	private static int getIntrinsicTimeZonePacked(int forLongitude) {
		int sign = 1;
		if (forLongitude < 0) {
			forLongitude = -forLongitude;
			sign = -1;
		}

		forLongitude = (forLongitude + (LONGITUDE_PER_TIMEZONE_RATIO >> 1)) /
				LONGITUDE_PER_TIMEZONE_RATIO
				+ MINUTES_PER_HOUR / 2;
		return (forLongitude - forLongitude %
				MINUTES_PER_HOUR) *
				sign;
	}

	private static int getIntrinsicTimeZonePacked(final int[] forLongDMSH) {
		return getIntrinsicTimeZonePacked(packLongitude(forLongDMSH));
	}

	public static void getIntrinsicTimeZone(final int[] forLongDMSH, int[] tzHMD) {
		unpackTimeZone(getIntrinsicTimeZonePacked(forLongDMSH), tzHMD);
	}

	public static boolean checkTimeZoneLongitudeConsistency(final int[] longDMSH, final int[] tzHMD) {
		int timeZoneDifference = packTimeZone(tzHMD)
				- getIntrinsicTimeZonePacked(longDMSH);

		return (timeZoneDifference <= TIME_ZONE_TOLERANCE_MAX)
				&&
				(timeZoneDifference >= TIME_ZONE_TOLERANCE_MIN);

	}

	public boolean checkTimeZoneLongitudeConsistency() {
		int timeZoneDifference =
				tmeZone -
						getIntrinsicTimeZonePacked(longitude);

		return (timeZoneDifference <= TIME_ZONE_TOLERANCE_MAX)
				&&
				(timeZoneDifference >= TIME_ZONE_TOLERANCE_MIN);
	}

	//----------------------------------------------------------------
	// DST
	//----------------------------------------------------------------
	public boolean isChangedDSTPeriod(final byte[][] newPeriod) {
		int i, j;
		for (i = 0; i < 2; i++) {
			for (j = 0; j < DST_PERIOD_SIZE; j++) {
				if (DSTperiod[i][j] != newPeriod[i][j]) {
					return true;
				}
			}
		}
		return false;
	}

	public void acceptDSTPeriod(final byte[][] newPeriod) {
		for (int i = 0; i < 2; i++) {
			System.arraycopy(newPeriod[i], 0, DSTperiod[i], 0, DST_PERIOD_SIZE);
		}
		if (dstMode == DST_MODE_CUSTOM) {
			dstCurrentChanged = true;
		}
	}

	public byte[][] getDSTPeriod() {
		byte[][] copyPeriod = new byte[2][DST_PERIOD_SIZE];
		for (int i = 0; i < 2; i++) {
			System.arraycopy(DSTperiod[i], 0, copyPeriod[i], 0, DST_PERIOD_SIZE);
		}
		return copyPeriod;
	}

	public static boolean isDSTMonthly(final byte[] data) {
		return (data[DST_INDEX_MODE] < DST_NON_MONTHLY);
	}

	public boolean getCurrentDST(final DateHolder dh) {
		if (dstCurrentChanged) {
			dstCurrent = false;

			switch (dstMode) {
			case DST_MODE_ON:
				dstCurrent = true;
				break;

			case DST_MODE_CUSTOM:
				dstCurrent = getDSTModeFromMyself(dh);
				break;

			case DST_MODE_SYSTEM:
				dstCurrent = getDSTModeFromDevice(dh);
				break;
			}

			dstCurrentChanged = false;
		}

		return dstCurrent;
	}

	boolean getDSTModeFromDevice(final DateHolder dh) {
		int day = dh.dateSecular.day;
		int month = dh.dateSecular.month;
		int year = dh.dateSecular.year;
		int dow = HebCalendar.getDayOfWeek(dh.dateAbsolute);
		int era = 1;
		if (year < 0) {
			year = -year;
			era = 0;
		}

		try {
			TimeZone tz = TimeZone.getDefault();
			int sysOffset = tz.getOffset(era, year, month, day, dow,
					MINUTES_PER_DAY *
							MILLISEC_PER_MINUTE / 2);
			int sysRawOffset = tz.getRawOffset();

			return ((sysOffset - sysRawOffset) >= 60 * MILLISEC_PER_MINUTE);
		} catch (Exception ex) {
			return false;
		}
	}

	private boolean getDSTModeFromMyself(final DateHolder analysedDate) {
		DateHolder dh = new DateHolder();
		DateData dd = new DateData();
		byte[] data;
		int day, month, year, dow;
		int dateStart = 0, dateEnd = 0, dateInQuestion;
		int direction, cal, weeksExtra, mode;

		for (int i = 0; i < 2; i++) {
			data = DSTperiod[i];
			day = data[DST_INDEX_DAY];
			dow = data[DST_INDEX_DOW];
			month = data[DST_INDEX_MONTH];
			cal = data[DST_INDEX_CAL];
			year = (cal == 0) ? analysedDate.dateHebrew.year : analysedDate.dateSecular.year;

			weeksExtra = 0;

			switch (mode = data[DST_INDEX_MODE]) {

			case DST_FIRST_IN_MONTH:
			case DST_SECOND_IN_MONTH:
			case DST_THIRD_IN_MONTH:
			case DST_FOURTH_IN_MONTH:
				direction = 1;
				day = 1;
				weeksExtra = mode - DST_FIRST_IN_MONTH;
				break;

			case DST_SECOND_LAST_IN_MONTH:
			case DST_LAST_IN_MONTH:
				direction = -1;
				day = (cal == 0) ? HebCalendar.monthMaxDuration(month)
							: SecularCalendar.monthMaxDuration(month);
				weeksExtra = DST_LAST_IN_MONTH - mode;
				break;

			case DST_FIRST_AFTER:
				direction = 1;
				break;

			case DST_LAST_BEFORE:
				direction = -1;
				break;

			default:
				direction = 0;
			}

			dd.set(day, month, year);
			if (!((cal == 0) ? dh.acceptHebrewDate(dd, true)
					: dh.acceptSecularDate(dd))) // auto-correction by default
			{
				return false;
			}

			dateEnd = adjustDSTDate(dh.dateAbsolute, dow, direction, weeksExtra);

			if (i == 0) {
				dateStart = dateEnd;
			}
		}

		dateInQuestion = analysedDate.dateAbsolute;

		if (dateStart <= dateEnd) {
			return (dateInQuestion >= dateStart) &&
					(dateInQuestion < dateEnd);
		}

		return (dateInQuestion >= dateStart) ||
				(dateInQuestion < dateEnd);

	}

	private int adjustDSTDate(int dayAbsolute, int targetDow, int direction, int weeksExtra) {

		if (direction != 0) {
			int curDow = HebCalendar.getDayOfWeek(dayAbsolute);
			int dif = targetDow - curDow;
			dayAbsolute += dif;
			if ((dif * direction) < 0) {
				weeksExtra++;
			}
			dayAbsolute += HebCalendar.DAYS_PER_WEEK *
					direction * weeksExtra;
		}

		return dayAbsolute;
	}

	//=======================================================================
	public void save(DataOutputStream dos) throws Exception {
		int i, j;

		dos.writeUTF(name);

		dos.writeByte(holidayStyle);
		dos.writeBoolean(timeScale12);

		dos.writeInt(latitude);
		dos.writeInt(longitude);
		dos.writeInt(elevation);
		dos.writeShort((short) tmeZone);
		dos.writeByte((byte) dstMode);

		for (i = 0; i < 2; i++) {
			for (j = 0; j < DST_PERIOD_SIZE; j++) {
				dos.writeByte(DSTperiod[i][j]);
			}
		}

		for (i = 0; i < 6; i++) {
			dos.writeByte(0);
		}
	}

	public void restore(DataInputStream dis) throws Exception {
		int i, j;

		name = dis.readUTF();

		holidayStyle = (byte) (dis.readByte() & 1);
		timeScale12 = dis.readBoolean();

		latitude = dis.readInt();
		longitude = dis.readInt();
		elevation = dis.readInt();
		tmeZone = dis.readShort();
		dstMode = dis.readByte() % DST_MODE_COUNT;

		for (i = 0; i < 2; i++) {
			for (j = 0; j < LocationHolder.DST_PERIOD_SIZE; j++) {
				DSTperiod[i][j] = dis.readByte();
			}
		}

		//for (int i=0; i<6; i++) dis.readByte(0);

		dstCurrentChanged = true;
		lastSunRiseSetDate = -1;
	}
}
