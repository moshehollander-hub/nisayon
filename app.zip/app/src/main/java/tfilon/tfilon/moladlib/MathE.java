// =====================================================
//  Molad
//  Hebrew(Jewish) calendar
//  (C) 2003-2006, Michael Glickman
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//  ==========================================================
//  Math functions which are (currently) missing in standard
//  Math class for J2ME (what a shame!)
//  ----------------------------------------------------------
//  If the following code is used in your application, 
//  the references are expected.
//  ----------------------------------------------------------
//  Started	29 September 2006
// ===========================================================
package tfilon.tfilon.moladlib;
	
public final class MathE
{
	// Max number of iterations
	static private final int ITNUM = 100;
	static private final double PRECISION = 1.E-20;

	static private final double HalfPI = Math.PI/2.;
	static private final double QuarterPI = Math.PI/4.;

	// Returns atan(x) of a reasonably small argument x
	// atan(x) = x- x^3/3 + x^5/5 - x^7/7
	private static final double atanTinyArg(double x)
	{
      	double term=x;
      	double x2=x*x;			// x square
      	double res=term;		// Starting value
      	double term1;
      	boolean negTerm = false;

		for (int i=3; i<=ITNUM; i+=2) {
			term *= x2;	
			term1 = term/i;
			//if (term1 == 0) break;
			if (term1 > -PRECISION && term1 < PRECISION) break;
			negTerm = !negTerm;
			if (negTerm) res -= term1; 
			       else  res += term1;
			if (Double.isInfinite(res) || Double.isNaN(res))
				return res;
		}

		return res;		
	}	      

	// Returns arctan of argument x, where 0<=x<=1
	private static final double atanTinyArgThreshold =0.41421356237309515; // Math.sqrt(2.)-1;

	private static final double atanSmallArg(double x)
	{
		if (x <= atanTinyArgThreshold &&
			x >= -atanTinyArgThreshold)
			return  atanTinyArg(x);
		else
		if (x > 0) 
			return QuarterPI - atanTinyArg((1-x)/(1+x));
		else
			return atanTinyArg((1+x)/(1-x)) - QuarterPI;
	}

	//-------------------------------------
	// Returns arc tan of the argument
	static public final double atan(double x)
	{
		boolean complement=false;
     		
      		// though are documented there
     		if (Double.isNaN(x)) return x;
     			
	      	if( (x>1) || (x<-1) ) {
	     		x = (x==Double.POSITIVE_INFINITY || x==Double.NEGATIVE_INFINITY) 
	     		    ? 0 : 1./x;
       			complement=true;
		}
      
		double res = atanSmallArg(x);      		
      
		// inversion took place - need complementary
      		if(complement) {
      			if (x >= 0) res= HalfPI - res;
      			      else  res= -(HalfPI + res);
		}      				
      		
		return res;
	}

	//-------------------------------------------
	// Returns arc tan of (y/x)
	static public final double atan2(double y, double x)
	{
      		boolean complement=false;
		double res;
	
		if (Math.abs(y) > Math.abs(x))	{
			// I wouldn't risk XOR-ing with doubles
			res = y;
			y=x; x=res; 
			complement = true;
		}	

		// Now we have |y|<=|x|	!		
			
		// If x is zero, then y must be zero as well
		if (x==0) return Double.NaN;
			
		// if x is not zero, then |y/x| <= 1,
		// (and of course y/x is non-infinite)
		res = atanSmallArg(y/x);      		
						
      		if(complement) {
      			if (res >= 0) res= HalfPI - res;
      			        else  res= -(HalfPI + res);
		}      				
		return res;
	}	


	//-------------------------------------------
	// Returns arc sin of the argument
	static public final double asin(double x)
	{
		// We assume -PI/2 <= x <= PI/2, therefore cos(x)>=0
		if (x>1. || x<-1.) return Double.NaN;
		return atan2(x, Math.sqrt(1-x*x));
	}

	//-------------------------------------------
	// Returns arc cos of the argument
	static public final double acos(double x)
	{
		if (x>1. || x<-1.) return Double.NaN;
		return HalfPI - asin(x);
	}
}