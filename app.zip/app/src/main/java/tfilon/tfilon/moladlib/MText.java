// =====================================================
//  Molad
//  Hebrew(Jewish) calendar
//  (C) 2003-2006, Michael Glickman
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
// =====================================================
// Modified by Ori Hollander
// (c) 2010

package tfilon.tfilon.moladlib;


public class MText
{
	static final String[] MonthNamesHebrew = 
	{"Nissan", "Iyar", "Sivan", "Tammuz", "Av", "Elul", 
	 "Tishri", "Cheshvan", "Kislev", "Tevet", "Shevat", "Adar", "AdarB", "AdarA"
	}; 

	// 4 LS bits: how many initial letters are taken for the short name of month
	// 4 MS bits: number of ending letters appended
	// 0 - take whole word
	static final byte[] MonthNamesHebrewShortLength = 
	  {3, 0, 3, 3, 0, 0, 4, 4, 3, 3, 4, 0, 0x12, 0x12};
	 

	static final String[] MonthNamesSecular = 
	{"January", "February", "March", "April", "May", "June", 
	 "July", "August", "September", "October", "November", "December"
	}; 

	// How many initial letters are taken for the short name of month
	// 0 - take whole word
	static final byte[] MonthNamesSecularShortLength = 
	  {3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3};



	static final String[] DowNamesCommon = 
	{"Sunday", "Monday", "Tuesday", "Wednesday", 
	 "Thursday", "Friday", "Saturday"
	}; 

	static final String[] DowNamesHebrew = 
	{"Yom 1", "Yom 2", "Yom 3", "Yom 4", 
	 "Yom 5", "Yom 6", "Shabbat" 
	}; 
	

        // Edited by Ori Hollander
        // (c) 2010
        //#ifdef english
//#         static final String SedrotNames[] =
//# 	{"Bereshit",     "Noach",    "Lech Lecha", "Vayera",     "Chayei Sarah",
//# 	 "Toledot",  "Vayetze", "Vayishlach", "Vayeshev",   "Miketz",
//# 	 "Vyigash",     "Vaychi",  "Shemot",     "Va'era",      "Bo",
//# 	 "Beshalach",    "Yitro",    "Mishpatim",  "Teruma",    "Tetzave",
//# 	 "Ki Tisa",      "Vayakhel", "Pekudei",    "Vayikra",    "Tzav",
//# 	 "Shemini",       "Tazria",   "Metzora",    "Acharey Mot", "Kedoshim",
//# 	 "Emor",         "Behar",    "Bechukotay", "Bemidbar",   "Naso",
//# 	 "Beha'alotecha", "Shelach",  "Korach",     "Chukat",     "Balak",
//# 	 "Pinechas",      "Matot",    "Mas'ei",      "Devarim",    "Va'etchanan",
//#      	 "Ekev",        "Re'e",    "Shofetim",    "Ki Tetze", "Ki Tavo",
//#      	 "Nitzavim",     "Vayelech", "Ha'azinu"
//# 	};
        //#else
	static final String SedrotNames[] = 
	{"בראשית",     "נח",    "לך לך", "וירא",     "חיי שרה",
	 "תולדות",       "ויצא", "וישלח", "וישב",   "מקץ",
	 "ויגש",     "ויחי",  "שמות",     "וארא",      "בא",
	 "בשלח",    "יתרו",    "משפטים",  "תרומה",    "תצוה",
	 "כי תשא",      "ויקהל", "פקודי",    "ויקרא",    "צו",
	 "שמיני",       "תזריע",   "מצורע",    "אחרי מות", "קדושים",
	 "אמר",         "בהר",    "בחקתי", "במדבר",   "נשא",
	 "בהעלתך", "שלח",  "קרח",     "חקת",     "בלק",
	 "פינחס",      "מטות",    "מסעי",      "דברים",    "ואתחנן",
     	 "עקב",        "ראה",    "שפטים",    "כי תצא", "כי תבא",
     	 "נצבים",     "וילך", "האזינו"
	};
        //#endif


	static final String HolidayNames[][] =
	{
		{ "Rosh Chod.",				           "Rosh" },
		{ "Ta'annit Bechorot",                 "T'nit Bechrt"}, 
		{ "Pesach",                            "Pesach"},
		{ "Yom HaShoah",                       "Y.HaShoah"} , 
		{ "Yom HaZikaron",                     "Y.Zikaron", },
		{ "Yom HaAtzmaut",                     "Y.Atzmaut" },
		{ "L\"G BaOmer",                       "L\"G BaOmer" }, 
		{ "Yom Yerushalaim",                   "Y.Yerush'm"},
		{ "Shavuot",                           "Shavuot"},
		{ "Shiva Asar B'Tammuz",               "17 b'Tammuz"},
		{ "Tisha b'Av",                        "Tisha b'Av"}, 
		{ "T\"U b'Av",           			   "T\"U b'Av"},
		{ "Rosh HaShanah",                     "Rsh Shanah"},
		{ "Tzom Gedaliah",                     "Tzm Gdliah"},
		{ "Yom Kippur",                        "Yom Kippur"},
		{ "Sukkot",                            "Sukkot"}, 
		{ "Hoshanah Rabah",                    "Hshnah Rbah"},
		{ "Shmini Atzeret",                    "Shmini Atz't"},
		{ "Simchat Torah",                     "Smch'Torah"},
		{ "Chanukah",                          "Chanukah"},
		{ "Asarah b'Tevet",                    "10 b'Tevet"},
		{ "T\"U b'Shevat",                     "T\"U b'Shevat"},
		{ "Ta'annit Esther",                   "T'nit Esther"}, 
		{ "Purim",                             "Purim"},
		{ "Shushah Purim",                     "Shshah Purim"}
	};	

	static final String TitleShabbat = "Shabbat "; 	
	public static final String TxtUnnamed = "Unnamed";
	public static final String TxtNameDefault = "Default";

	static final String ShabbathPesachNames[] =
	{
		"Shekalim", "Zahor", "Parah", "HaChodesh", "HaGadol"
	};

	static final String ShabbathTishaBAvNames[] =
	{
		"Hazon", "Nachamu"
	};

	static final String ShabbathRoshHaShanaNames[] =
	{
		"Shuva"
	};

	public static final String TitleErev = "Erev ";
//	static final String TitleParashat = "Par. "; //  "Parashat ";
	public static final String TitleKatan[]=  {" Katan", " Ktn"};
	public static final String TxtHagDay = ",  day ";

/*
	static public final String[] ZmanimNamesLong =
	{
		"Alot HaShachar (Dawn)",
		"Eraly Talit & Tfilim",
		"HaNetz HaChama (Sunrise)",
		"SoftZman Shema Magen Avraham",
		"SoftZman Shema Gro&Baal Tanya",
		"SoftZman Tfilah Magen Avraham", 
		"SoftZman Tfilah Gro&Baal Tanya", 

		"Hatzot HaYom (Midday)",
		"Mincha Gedolah",
		"Mincha Gedolah Magen Avraham",
		"Mincha Ketana",
		"Mincha Ketana Magen Avraham",
		"Plag HaMincha",
		"Plag HaMincha Magen Avraham",

		"Candle Lighting",
		"Shkia (Sunset)",
		"Tzet HaKochvim(Dusk) Gro",
		"Tzet HaKochvim(Dusk) Gaonim",
		"Dusk  Chazon Ish",
		"Havdalah",
		"Tzet HaKochvim Rabbeinu Taam",
		"Midnight"
	};	
*/

	static public final String[] ZmanimNamesShort =
	{
		"Alot(Dawn)",
		"Early Talit",
		"Sunrise",
		"SZ Shma M A",
		"SZ Shma G\"H",
		"SZ Tfila M A",
		"SZ Tfila G\"H",

		"Midday",

		"Mincha Gdola",
		"MinGdola M A",
		"Mincha Ktana",
		"MinKtana M A",
		"Plag Mincha",
		"Plag Min.M A",

		"Candle Light",
		"Shkia(Sunset)",
		"Dusk Gro",
		"Dusk Gaonim",
		"Chazon Ish",
		"Havdalah",
		"Dusk R\"Taam",
		"Midnight"
	};	


	// Creates message line " day"  "2 days", etc
	public static String getDaysText(int days)
	{
		return  String.valueOf(days) + " " +
		        ((days == 1) ? "day" : "days");

	}

	// Creates message line "1 day"  "2 days", etc
	public static String getInNightsText(int nights)
	{
		return (nights == 1) ? "next night"
                       : "in " +  String.valueOf(nights) + " nights";
	}

}
