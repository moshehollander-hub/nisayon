//=====================================================
//	Molad
//  Hebrew(Jewish) calendar
//  (C) 2003, Michael Glickman
//	--------------------------------------------------
//	HebCalendar.java - Hebrew calendar support
//  The code is influenced by the following sources:
//  Hebcal (C) 1994-1999 Danny Sadinoff:
//       http://www.sadinoff.com/hebcal
//  Chelm.org (C) 1999 Steven Ross Weintraub: 
//       http://chelm.org/jewish/calendar/explain.html
//  ---------------------------------------------------
//  If the following code is used in your application, 
//  the references are expected.
//  ---------------------------------------------------
//  Started	08 November 2003
//=====================================================

package tfilon.tfilon.moladlib;

public class HebCalendar
{
	//--------------------------------------------------------------------------------------------
	// Universal constants
	//--------------------------------------------------------------------------------------------
	public static final int MIN_YEAR_HEBREW =  1;
	public static final int MAX_YEAR_HEBREW = 5000000;

	private static final int PARTS_PER_HOUR=1080;
	private static final int HOURS_PER_DAY=24;
	private static final int PARTS_PER_DAY=HOURS_PER_DAY*PARTS_PER_HOUR;  // 25920

	private static final int PARTS_PER_MONTH=12*PARTS_PER_HOUR+793;   // Parts per month in addition to 29 full days
	                                                   			      // 12(hours)*1080(parts/hour)+793(extra_parts)=13753;
//	private static final int PARTS_PER_MONTH=793;		// "Pure" parts per lunar month
//	private static final int HOURS_PER_MONTH=12;		// "Pure" hours per lunar month
	private static final int DAYS_PER_MONTH=29;			// Days per lunar month
	public static final int DAYS_PER_WEEK=7;					// Days per week

	private static final int MONTHS_PER_CYCLE=235;		// Lunar months per a cycle
	private static final int YEARS_PER_CYCLE=19;		// Solar years per cycle

	public static final int DOW_SHABBAT  = DAYS_PER_WEEK-1;
	public static final int DOW_WEEKEND = DOW_SHABBAT-1;
	
	private static int yearStartLunarDays;
	private static int yearStartLunarParts;
	

	//--------------------------------------------------------------------------------------------
	// Derived values
	//--------------------------------------------------------------------------------------------
	private static final int MONTHS_PER_YEAR=MONTHS_PER_CYCLE/YEARS_PER_CYCLE;	         // Astronomic moths per year: 235/19 = 12
	private static final int MONTHS_PER_YEAR_EXTRA=MONTHS_PER_CYCLE%YEARS_PER_CYCLE;	 // Numerator for month_per_cycle / year_per_cycle: 235 % 19 = 7

	public static final int MONTHS_PER_LEAP_YEAR=MONTHS_PER_YEAR+1;			         // Months per leap year

	// Non-leap year months alternate: half have 29, another half have 30 days
	private static final int DAYS_PER_YEAR_NONLEAP = MONTHS_PER_YEAR*(2*DAYS_PER_MONTH+1)/2;
	private static final int DAYS_PER_YEAR_NONLEAP_MAXIMUM = DAYS_PER_YEAR_NONLEAP + 2;
	// An extra 30 days are added in case of a leap year 
	private static final int DAYS_PER_YEAR_LEAP = DAYS_PER_YEAR_NONLEAP + DAYS_PER_MONTH + 1;	

	// Used for rough calculations in from Absolute                 				
	private static final int DAYS_PER_CYCLE_CEIL=DAYS_PER_MONTH*MONTHS_PER_CYCLE+(PARTS_PER_MONTH*MONTHS_PER_CYCLE)/PARTS_PER_DAY+1;
							// 29*235 + (13753*235)/25920 = 6939			
	                                                       		

	//--------------------------------------------------------------------------------------------
	// Special times in day (for Rosh HaShana adjustment)
	//--------------------------------------------------------------------------------------------
	private static final int NOON_TIME=18*PARTS_PER_HOUR;		// noon
	private static final int THREE_12_AM=9*PARTS_PER_HOUR+204;	// 9 hours 204 chelekim (3:12 am)
	private static final int NINE_32_AM=15*PARTS_PER_HOUR+589;	// 15 hours 589 chelekim (9:32 am)


	//--------------------------------------------------------------------------------------------
	// Parameters on the start of calendar (creation date)
	//--------------------------------------------------------------------------------------------
	private static final int BASE_MONTH_EXTRA=1;		
//	private static final int BASE_PART=204;		
//	private static final int BASE_HOUR=5;
	private static final int BASE_PART=5*PARTS_PER_HOUR+204;		
	private static final int BASE_DAY=1;
	private static final int BASE_DOW=0;		// Day of week


	//--------------------------------------------------------------------------------------------
	// Enumerators for months
	//--------------------------------------------------------------------------------------------
	public static final int NISSAN=0;
	public static final int IYAR=1;
	public static final int SIVAN=2;
	public static final int TAMMUZ=3;
	public static final int AV=4;
	public static final int ELUL=5;
	public static final int TISHRI=6;
	public static final int CHESHVAN=7;
	public static final int KISLEV=8;
	public static final int TEVET=9;
	public static final int SHEVAT=10;
	public static final int ADAR=11;
	public static final int ADAR2=12;
	// Special names
	public static final int ADAR1=13;
	public static final int ANYMONTH=14;


	//********************************************************************************************
	// Absolute number of days for current hebrew date
	// day is 1-based, month is 0-based	
	public static boolean toAbsolute (DateHolder pdate, DateData newDate, boolean autoCorrection)
	{
		int pday = newDate.day;
		int pmonth = newDate.month;
	
		if (pmonth < 0 || pday <= 0 || !getYearInfo(pdate, newDate.year))
			return false;

		int[] monthDurations = pdate.hebMonthDurations;
		int monthCount = monthDurations.length;

		// Date correction
		if (autoCorrection){
			if (pmonth >= monthCount) 
				newDate.month = pmonth = monthCount-1;
			//	pday = monthDurations[monthCount];
			//} else	
			pday = Math.min(pday, monthDurations[pmonth]);
		} else {
			if (pmonth >= monthCount ||
			    pday > monthDurations[pmonth]) return false;	
		}			

		newDate.day = pday;

		pday --;
		pday += pdate.hebNewYearAbsolute;

		int i = TISHRI;		// start of new year
		
		if (pmonth < i) {
			// Tishri is the start of new year,
			// but the middle of the calendar
			while(i<monthCount) pday += monthDurations[i++];		
			
			i = NISSAN;		// 1st calendar month
		}
		
		while (i < pmonth) pday += monthDurations[i++];
		

		pdate.dateHebrew = newDate;
		pdate.dateAbsolute = pday;  /* - 1373429; */
		return true;
	}

	// Returns array [0]-day, [1]-month, [2]-year
	public static boolean fromAbsolute (DateHolder pdate, int absDay)
	{
		// Calculate year roughly
		if (absDay < BASE_DAY) return false;
		
		int pday = (absDay-BASE_DAY) / DAYS_PER_CYCLE_CEIL;

		int pyear = pday * YEARS_PER_CYCLE;		// Starting year of the cycle

		pday = pday*DAYS_PER_CYCLE_CEIL+BASE_DAY;	// Starting day of the cycle
		
		//while (pday > 0 && pday < absDay)
		while (pday < absDay)
		{
			pday += isLeapYear(pyear) ? DAYS_PER_YEAR_LEAP : DAYS_PER_YEAR_NONLEAP;		
			pyear++;		
		}

		
		//-------------------------------------------------------
		// Now get year it precisely
		//while((pday = getNewYearAbsolute(pyear)) > 0 && pday < absDay) pyear++;
		// if (pday <= 0 || pday > absDay) pyear--;
		while((pday = getNewYearAbsolute(pyear)) < absDay) pyear++;
		if (pday > absDay) pyear--;
		
		//-------------------------------------------------------
		// We have the year - check if it is within ranges
		if (!getYearInfo(pdate, pyear)) return false;		


		// Now we are comitted to accept - let's do it 
		int[] monthDurations = 	pdate.hebMonthDurations;
		int monthCount = 	monthDurations.length;

		pday = absDay - pdate.hebNewYearAbsolute;

		int pmonth = TISHRI, mdur;

		while (pday >= (mdur=monthDurations[pmonth])) {
			pday -= mdur;
			if (++pmonth >= monthCount) pmonth = NISSAN;
		}

		pdate.dateAbsolute = absDay;
		pdate.dateHebrew = new DateData(pday+1, pmonth, pyear);
		return true;
	}

	//========================================================================================
	// Returns true if 'year' is a leap year
	public static boolean isLeapYear(int year)
	{
		// This approach is borrowed from hebcal program (Danny Sadinoff, 1994) 
		// and is based on the observation that a fraction like (7*y)/19 has 
		// wrapped over a whole number if the numerator (7*y) % 19 is less than 7.
		// 1 is a correction needed because we operate with the absolute year,
		// rather than with a year relative to start of a 19 year cycle 
	 
		return (((year*MONTHS_PER_YEAR_EXTRA + 1) % YEARS_PER_CYCLE) < 7);
	}
	//======================================================================================
	// Absolute date for the of hebrew year (Rosh HaShana)
	public static int getDayOfWeek (int dayAbsolute)
	{
		return (dayAbsolute + BASE_DOW) % DAYS_PER_WEEK;
	}

	//======================================================================================
	// Absolute date for the of hebrew year (Rosh HaShana)
	private static int getNewYearAbsolute (int pyear)
	{
		// Years elapsed
		int months = pyear - 1;		// Years elapsed

		// Cycles elapsed
		// 1 cycle is 19 solar years of 235 lunar month
		// 1 solar year = 12 7/19 lunar months
		int quotient = months / YEARS_PER_CYCLE;		// cycles elapsed

		// Year in the cycle		
		int remainder = months % YEARS_PER_CYCLE;		// year in current cycle (0-based)
		

		// Months elapsed
		months = MONTHS_PER_CYCLE * quotient +     // 235 lunar months per cycle +
		         MONTHS_PER_YEAR * remainder +	   // 12 mnths for each preceding year in the cycle +
					                               // And extra 7/19  months for each preceding year
		        (MONTHS_PER_YEAR_EXTRA * remainder + BASE_MONTH_EXTRA)/YEARS_PER_CYCLE;    

		// Convert months to days and parts.
		// A part (chelek) is 1 / 1080 of an hour
		// A lunar month is 29 days, 12 hours and 793 chelekim
		// which is same as 29 days and 13753 chelekim (13753 = 12*1080+793)

		quotient = months / PARTS_PER_DAY;
		remainder = months % PARTS_PER_DAY;

		// months = qoutient * 1080 + remainder;

		// Parts = (m_elapsed * 13753) % 1080, or (remainder * 13753) % 1080; 		
		int parts = remainder*PARTS_PER_MONTH + BASE_PART;	       // We don't normilise as yet

		// days: m_elapsed*29 + (m_elapsed*13753)/1080
		//   or: m_elapsed*29 + quotient*13753 + (remainder * 13753)/1080
		int dateAbs = months*DAYS_PER_MONTH + quotient*PARTS_PER_MONTH + parts/PARTS_PER_DAY + BASE_DAY; 

		// Now we can normalize parts
		parts %= PARTS_PER_DAY;

		// Store as astronomic data for moon phases		
		yearStartLunarDays = dateAbs; 
		yearStartLunarParts = parts;
		
		remainder = getDayOfWeek(dateAbs);    // day of week
	
		// Postpone new year a day, if molad occurs:
		   // 1) at afternoon time:
		if ((parts >= NOON_TIME) ||
		   // 2) in a non-leap year on Tuesday after 9h 204p (~3:12 am)			
		   ((remainder == 2) && (parts >= THREE_12_AM) && !(isLeapYear (pyear))) ||
		   // 3) in a year following the leap year on Monday after 15h 589p (~9:32 am)
    	   ((remainder == 1) && (parts >= NINE_32_AM) && isLeapYear (pyear - 1))) {
			dateAbs++;
			remainder = getDayOfWeek(dateAbs);    // day of week
		}

		// In addition:
		// if new year starts on Sunday, Wednesday, or Friday, postpone it a day.
		if (remainder == 0 || remainder == 3 || remainder == 5)
			dateAbs++;

	    return dateAbs;
	}


	
	private static boolean getYearInfo(DateHolder pdate, int pyear)
	{

		if (pyear < MIN_YEAR_HEBREW || pyear > MAX_YEAR_HEBREW) return false;

		DateData oldDate = pdate.dateHebrew;
		if (oldDate != null && pyear == oldDate.year) return true;

		int	newYearAbsolute = getNewYearAbsolute (pyear);
		pdate.hebYearStartLunarDays = yearStartLunarDays;
		pdate.hebYearStartLunarParts = yearStartLunarParts;


		int dayCount = getNewYearAbsolute (pyear+1) - newYearAbsolute;
		boolean isLeap = (dayCount > DAYS_PER_YEAR_NONLEAP_MAXIMUM);
		int[]  monthDurations = new int[isLeap ? MONTHS_PER_LEAP_YEAR : MONTHS_PER_YEAR];

		pdate.hebNewYearAbsolute = newYearAbsolute;
		pdate.hebMonthDurations = monthDurations;

		
		
		// Alternate durations
		for (int i=0; i<MONTHS_PER_YEAR; i += 2) {
			monthDurations[i]= 30;
			monthDurations[i+1]= 29;
		}
		
		if (isLeap) {
			monthDurations[ADAR] = 30;
			monthDurations[ADAR2] = 29;
			dayCount -= DAYS_PER_YEAR_LEAP;
		}
		else
			dayCount -= DAYS_PER_YEAR_NONLEAP;

		if (dayCount < 0)	monthDurations[KISLEV]--;
		else
		if (dayCount > 0)	monthDurations[CHESHVAN]++;

		return true;		
	}


	public static int calculateMoonPhase(DateHolder pdate)
	{
		int targetDays = pdate.dateAbsolute;

		// Get days appproximately (this will be leaa than the actial days)
		int months = (targetDays - pdate.hebYearStartLunarDays) / (DAYS_PER_MONTH+1); 
		//if (months > 0) months --;
	
		// Get lunar days and parts for the start of 'months'
		int nextParts = pdate.hebYearStartLunarParts +  PARTS_PER_MONTH*months; 
		int nextDays = pdate.hebYearStartLunarDays + DAYS_PER_MONTH*months + nextParts / PARTS_PER_DAY; 
		nextParts %= PARTS_PER_DAY;

		int days, parts, percent;

		for(;;) {
			days = nextDays;
			parts = nextParts; 
	
			nextParts += PARTS_PER_MONTH;
			nextDays += DAYS_PER_MONTH + nextParts/PARTS_PER_DAY;
			nextParts %= PARTS_PER_DAY;
			if (nextDays > targetDays) break;

			months++;
		} 
			
		// Find the percentage
		return ((targetDays - days) * 256) / (nextDays - days);  		
		
	
	}

/*
	public static String monthNameForDate(DateHolder date)
	{
		int month = date.dateHebrew.month;
		if (month == ADAR && 
			 (date.hebMonthDurations.length >= MONTHS_PER_LEAP_YEAR))
			 	month = ADAR1;
		return MText.MonthNamesHebrew[month];				
	}
*/

	public static int monthMaxDuration(int month)
	{
		switch (month)
		{
			case ADAR2:
				return 29;
	
			case CHESHVAN:
			case ADAR:
				return 30;
				
			default:
				return 30-(month & 1);
		}
	}			

	// Return -1 if outside omer
	// Sefirat HaOmer includes 49 days from 16 Nissan to 5 Sivan
	public static int getOmerDay(DateHolder dHolder)
	{
		DateData date = dHolder.dateHebrew;
		int startingDay;
		int duration;
		int mask;
		
		int month = date.month;
//		if ( /* month < NISSAN || */
//		       month > SIVAN) return -1;


		if ( /* month >= NISSAN && */
		    month <= SIVAN) {
			// Omer
			startingDay = 15;	// 15th of nissan
			duration = 49;						  
			mask = 0;
		} else 
		if (month >= TAMMUZ && month <= AV) {
			startingDay = 105; // 106;
			duration = 21;
			mask = 0x100;
		} else
			return -1;			  


		// Date from start of calendar year			   
		int day = date.day;
		int[] monthDurations = dHolder.hebMonthDurations;		
		for (int i=0; i<month; i++)	day += monthDurations[i];

		// Omer day
		day -= startingDay;
		if (day < 1 || day > duration) day = -1;
		else day |= mask;
		return day;	
	}

	public static String getDayOfWeekName(int dayOfWeek)
	{
		return MText.DowNamesHebrew[dayOfWeek];

	}

	public static String getMonthName(int monthNumber)
	{
		return MText.MonthNamesHebrew[monthNumber];
	}

	public static String getMonthNameShort(int monthNumber)
	{
		int len = MText.MonthNamesHebrewShortLength[monthNumber];
		String fullName = MText.MonthNamesHebrew[monthNumber];
		String shortName;
		if (len==0)
			shortName = fullName;
		else {
			shortName = fullName.substring(0, len & 15);
			if ((len = ((len>>4) & 15)) != 0) 
				shortName += fullName.substring(fullName.length() - len);
		}		
			
		return shortName;
	}


	public static String dateToTextShort(final DateData fromDate)
	{
		return String.valueOf(fromDate.day) + 
			   getMonthNameShort(fromDate.month) +
			   String.valueOf(fromDate.year);
	}

}


