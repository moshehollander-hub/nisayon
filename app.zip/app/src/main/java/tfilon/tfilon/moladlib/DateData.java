// =====================================================
//  Molad
//  Hebrew(Jewish) calendar
//  (C) 2003-2006, Michael Glickman
//  ---------------------------
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
// =====================================================

package tfilon.tfilon.moladlib;

// Holds day, month, tear for both Hebrew and Secular calendars 
public class DateData
{
	public int day, month, year;

	public DateData () {}

	public DateData (int _day, int _month, int _year)
	{
		this();
		set(_day, _month, _year);
	}

	public DateData (DateData _from)
	{
		this();
		set (_from);
	}

	public void set (int _day, int _month, int _year)
	{
		day = _day;
		month = _month;
		year = _year;	
	}

	public	void set (DateData _from)
	{
		day = _from.day;
		month = _from.month;
		year = _from.year;	
	}

	// Returns sign between current and other dates
	public int compare(DateData other)
	{
		int dif = year - other.year;
		if (dif != 0) return dif;

		dif = month - other.month;
		if (dif != 0) return dif;
		
		return day - other.day;
	}	
}
